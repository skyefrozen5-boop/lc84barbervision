import { useState, useMemo, useEffect, useRef } from "react";
import { supabase } from "./supabaseClient";
import { registerPushForBarber, listenForegroundPush, registerPushForClient } from "./firebaseMessaging";
import logoIcon from './assets/logo-icon.jpg';

// ─── THEME ───────────────────────────────────────────────────────────────────
const T = {
  bg:"#000000", surface:"#0c0c0c", card:"#141414", border:"#222", muted:"#2a2a2a",
  silver:"#8a8a8a", mid:"#b3b3b3", light:"#ddd", white:"#f3f3f3",
  gold:"#b8955a", goldLo:"rgba(184,149,90,0.12)", goldMid:"rgba(184,149,90,0.25)",
  red:"#9e4040", redLo:"rgba(158,64,64,0.12)",
  green:"#4a8a5f", greenLo:"rgba(74,138,95,0.12)",
  orange:"#c07830", orangeLo:"rgba(192,120,48,0.12)",
  blue:"#4a6a9e", blueLo:"rgba(74,106,158,0.12)",
};

const GS = `
  @import url('https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;0,700;1,400&family=Josefin+Sans:wght@300;400;600;700&display=swap');
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0;}
  html,body,#root{background:${T.bg};min-height:100%;width:100%;}
  body{background:${T.bg};}
  ::-webkit-scrollbar{width:3px;height:3px;}
  ::-webkit-scrollbar-thumb{background:${T.border};border-radius:2px;}
  input,select,textarea,button{font-family:inherit;}
  input[type=date]::-webkit-calendar-picker-indicator{filter:invert(0.4);}
  .tap:active{opacity:0.7;}
  .slot-h:hover{border-color:${T.gold}!important;color:${T.gold}!important;}
  .row-h:hover{background:rgba(255,255,255,0.02)!important;}
  .row-h{user-select:none;-webkit-user-select:none;}
  @media print{body{background:white!important;color:black!important;}.no-print{display:none!important;}}
  @media (min-width:900px){.app-shell{max-width:900px!important;}}
  @media (min-width:1300px){.app-shell{max-width:1100px!important;}}
`;

// ─── LANGUAGES ───────────────────────────────────────────────────────────────
const LANGS = {
  pt:{ flag:"🇵🇹", name:"Português",
    months:["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"],
    wdays:["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"],
    wdaysF:["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"],
    pay:["Dinheiro","MB Way","Multibanco","Transferência","Outro"],
    t:{
      client:"Sou Cliente", bookCta:"Marcar Corte", clientSub:"Marcar serviços, consultar marcações e ver produtos", myBookingsLabel:"Ver as minhas marcações", phonePlaceholder:"O teu telemóvel", ourTeam:"A nossa equipa", barberLabel:"Barbeiro", priceLabel:"Valor", nameLabel:"Nome", namePlaceholder:"O teu nome", noBookingsFound:"Sem marcações encontradas",
      barber:"Sou Barbeiro", barberSub:"Gerir agenda, atendimentos e clientes autorizados", ownerBtnSub:"Registar e gerir a minha barbearia",
      platform:"A tua plataforma de barbearia",
      accessCode:"Código de Acesso", enter:"Entrar", wrongPin:"Código incorreto",
      hide:"Ocultar", show:"Ver",
      barberArea:"Área do Barbeiro", clientArea:"Área do Cliente",
      today:"Hoje", tomorrow:"Amanhã", yesterday:"Ontem",
      bookings:"marcações", concluded:"concluídas", toConfirm:"Confirmar",
      week:"Semana", revenue:"Receita Hoje", pendingRev:"por receber",
      nextBookings:"Próximas marcações", noFuture:"Sem marcações futuras",
      agenda:"Agenda", dashboard:"Início", notifications:"Alertas",
      clients:"Clientes", reports:"Receita", schedule:"Horário", profile:"Perfil",
      newBooking:"+ Novo", block:"🔒 Bloquear", addBooking:"Nova Marcação",
      editBooking:"Editar Marcação", save:"Guardar", delete:"Eliminar", close:"Fechar",
      clientName:"Nome do Cliente", fullName:"Nome completo", phone:"Telemóvel",
      date:"Data", time:"Hora", service:"Serviço", payment:"Pago", payMethod:"— método —",
      notes:"Notas", observations:"Observações…", back:"← Voltar", next:"Continuar →",
      confirmed:"Confirmado", done:"Concluído", cancelled:"Cancelado", blocked:"Bloqueado", selected:"Selecionado", noShow:"Falta",
      freeSlots:"Horários livres", dayBlocked:"Dia inteiro bloqueado", unblock:"Desbloquear",
      blockSlot:"Horário", blockDay:"Dia inteiro", blockPeriod:"Período", blockHours:"Ausência",
      blockSlotTitle:"Escolhe o horário a bloquear", blockDayTitle:"Bloquear dia inteiro",blockHoursTitle:"Bloquear horas de ausência",
      blockPeriodTitle:"Bloquear período (ex: férias)", blockDays:"dias bloqueados",
      noBookings:"Sem marcações — toque em + Novo", holiday:"Folga neste dia",
      searchClient:"Pesquisar nome ou telemóvel…", visits:"visita", totalSpent:"gasto total",
      barberNotes:"Notas do barbeiro", noNotes:"Sem notas — clique em Editar para adicionar",
      edit:"Editar", cancel:"Cancelar", upcoming:"Próximas marcações", history:"Histórico de visitas",
      noHistory:"Sem histórico", favorite:"Favorito",
      confirmedRev:"✓ Receita Confirmada", pendingPayment:"⚠ Por Receber", scheduled:"Agendado",
      payConfirm:"Confirmar Pagamento", confirmReceipt:"✓ Confirmar Recebimento de",
      printToday:"Relatório Hoje", printMonth:"Relatório Mês",
      byMethod:"Por método de pagamento", byService:"Por serviço", last7:"Receita confirmada — 7 dias",
      records:"Registos", total:"total", services:"Serviços",
      workDays:"Dias de trabalho", startHour:"Início", endHour:"Fim", generatedSlots:"Horários gerados",
      saveSchedule:"Guardar Horário", barbershop:"Barbearia", barberName:"Nome do Barbeiro",
      address:"Morada", bio:"Bio", newPin:"Novo PIN", keepPin:"Deixar vazio para manter",
      logout:"Sair", chooseBarber:"1. Escolha o barbeiro", chooseService:"2. Escolha o serviço",
      chooseDate:"3. Escolha a data", yourData:"4. Os teus dados", confirm:"Confirmar Marcação",
      bookingConfirmed:"Confirmado!", newBookingBtn:"Nova Marcação", myBookings:"Ver Marcações",
      myBookingsTitle:"As minhas marcações", cancelBooking:"Cancelar",
      trialDays:"d trial", active:"✓ ATIVO", subscribeTitle:"Escolhe o teu plano",
      subscribeSubtitle:"Sem compromisso. Cancela quando quiseres.",
      trialStatus:"Estado do Trial", daysLeft:"dias restantes", trialExpired:"Trial expirado",
      solo:"Solo", team:"Equipa", subscribeNow:"Subscrever Agora",
      expiredTitle:"Trial expirado", expiredSub:"Os teus dados estão guardados.\nSubscreve para continuar.",
      seePlans:"Ver Planos a partir de €9,99/mês", readMore:"Saber mais",
      markAllRead:"Marcar lidas", clearAllBtn:"Limpar", noNotifications:"Sem notificações",
      pendingOpen:"em aberto",
      clientWord:"cliente", bookedBadge:"MARCADO", lastVisitLabel:"Última",
      notePlaceholder:"Notas sobre o cliente (preferências, alergias, etc.)…", saveNoteBtn:"Guardar Nota",
      statVisitsLabel:"Visitas", statSpentLabel:"Gasto", statNoShowsLabel:"Faltas", noShowWarning:"⚠ Já faltou {n}x sem avisar", markNoShowBtn:"Falta",
      noBookingCanBeMade:"Nenhum cliente poderá marcar neste dia.", fromDate:"De", toDate:"Até",
      noBookingsShort:"Sem marcações", blockedSlotLabel:"Horário bloqueado",
      all:"Tudo", servicesUnconfirmed:"sem pagamento confirmado", paidConfirmedCount:"pagos e confirmados",
      unconfirmedCount:"sem confirmação", scheduledLabel:"Agendado", futureCount:"futuras",
      paidAndConfirmed:"Pagos e Confirmados", serviceDonePaymentPending:"Serviço Feito — Pagamento Por Confirmar",
      scheduledCount:"Agendados", noRecordsPeriod:"Sem registos para este período",
      role:"Função",
      paymentMethod:"Método de Pagamento", confirmAmountBtn:"✓ Confirmar",
      reportLabel:"Relatório", issuedOn:"Emitido em", billed:"Faturado", paidServices:"Serviços Pagos",
      unconfirmedPayment:"Sem Pagamento Confirmado", printBtn:"Imprimir",
      adminOverview:"Geral", adminBarbersTab:"Barbeiros", totalBilled:"Total Faturado", barbersLabel:"Barbeiros", todayAllLabel:"Hoje (todos)", totalBookingsLabel:"Total Marcações", teamToday:"Equipa hoje", bookingsTodayCount:"marcações hoje", barbersCountSuffix:"barbeiros", addNew:"+ Novo", activeLabel:"Ativo", offLabel:"Off", editBarberTitle:"Editar Barbeiro", newBarberTitle:"Novo Barbeiro", pinLabel:"PIN", colorLabel:"Cor", adminPinLabel:"PIN Admin", shopPhoto:"Foto da barbearia", uploading:"A enviar...", changePhoto:"Trocar foto", choosePhoto:"Escolher foto", dangerZone:"Zona de perigo", deleteShopWarning:"Apagar a barbearia remove definitivamente todos os dados (marcações, barbeiros, serviços). Esta ação não pode ser desfeita.", deleteShopBtn:"Apagar barbearia", deleteShopConfirmPre:"Esta ação é permanente. Para confirmar, escreve o nome exato da barbearia (", deleteShopConfirmPost:") e a tua password.", shopNameLabel:"Nome da barbearia", passwordLabel:"Password", deleting:"A apagar...", deletePermanently:"Apagar definitivamente",
      servicesCountSuffix:"serviços", editServiceTitle:"Editar Serviço", newServiceTitle:"Novo Serviço", durationLabel:"Duração (min)", servicePriceLabel:"Preço (€)",
      trialExpiredShort:"Trial expirado", subscribeToContinue:"— subscreve para continuar", trialDaysRemaining:"{n} dia(s) de trial restante(s)", tapSeePlans:"Toca para ver planos a partir de €{price}/mês", seeArrow:"VER →",
      subscriptionLabel:"Subscrição", freeTrialOfDays:"Trial gratuito de {days} dias", dayWord:"Dia", availablePlans:"Planos disponíveis", soloDesc:"1 barbeiro independente", perMonth:"/mês", soloFeatures:["Agenda completa","Clientes e histórico","Contabilidade","Relatórios e impressão","Notificações"], teamDesc:"Barbearia com colaboradores", perBarberMonth:"/barbeiro/mês", teamFeatures:["Tudo do plano Solo","Múltiplos barbeiros","Painel de administrador","Gestão de colaboradores","Métricas por barbeiro"], popularBadge:"POPULAR", teamCalcLabel:"Calculadora de equipa", activeBarbersCount:"{n} barbeiro(s) ativos", teamCalcFormula:"{n} × €{price} = €{total}/mês", savingsVsSolo:"poupas €{amount} vs Solo individual", planWord:"Plano", monthlyRenewal:"Renovação mensal automática", securePayment:"Pagamento seguro · Cancela a qualquer momento", demoNote:"Demo: clica para simular subscrição", faqTitle:"Perguntas frequentes", faqItems:[["Posso cancelar?","Sim, a qualquer momento. Sem penalizações."],["Como adiciono colaboradores?","No painel Admin crias o perfil de cada barbeiro. No plano Equipa cada um paga €7,99/mês."],["O que acontece após o trial?","A app bloqueia o acesso à agenda até subscreveres. Os dados ficam guardados."],["Existem custos ocultos?","Não. O preço é fixo por barbeiro por mês."]],
      expiredFull:"Os teus 15 dias gratuitos terminaram.\nOs teus dados estão guardados.\nSubscreve para continuar a usar a app.", noCommitmentFooter:"Sem compromisso · Cancela quando quiseres",
      photoTooLarge:"A imagem é demasiado grande (máx. 5MB).", uploadFailed:"Não foi possível enviar a imagem.", changeProfilePhoto:"Trocar foto de perfil",
      cutHistoryTitle:"Histórico de cortes", addCutBtn:"+ Adicionar corte", tapCamera:"📷 Ligar câmara", tapGallery:"🖼️ Carregar ficheiro",
      cutNotesPlaceholder:"Notas técnicas (ex: máquina nº2 nas laterais, tesoura em cima)", saveCutBtn:"Guardar corte", noCutsYet:"Ainda não há cortes registados por ti para este cliente.",
      deleteCutBtn:"Apagar corte",
      purchaseHistoryTitle:"Histórico de compras", addPurchaseBtn:"+ Adicionar compra", purchaseTextPlaceholder:"Descrição do produto (ex: Pomada matte)", savePurchaseBtn:"Guardar compra", noPurchasesYet:"Ainda não há compras registadas para este cliente.", deletePurchaseBtn:"Apagar compra", purchaseRecordTitle:"Compra", addPurchaseErr:"Escreve uma descrição ou adiciona uma foto.",
      cutRecordTitle:"Corte", addCutPhotoErr:"Adiciona uma foto do corte.", addClientBtn:"+ Adicionar cliente", nameRequiredErr:"O nome é obrigatório.",
      navHome:"Início", navAgenda:"Agenda", navAlerts:"Alertas", navClients:"Clientes", navReports:"Receita", navSchedule:"Horário", navProfile:"Perfil", navShop:"Loja", todaySuffix:"hoje", activeSubBadge:"ATIVO",
      blockedDayName:"Dia Bloqueado", blockedPeriodName:"Período Bloqueado", breakStartLabel:"Início da pausa", breakEndLabel:"Fim da pausa", noBreakOption:"Sem pausa", deleteClientBtn:"Apagar cliente", deleteClientWarning:"Isto remove definitivamente o histórico, notas e cortes registados para {name}. Esta ação não pode ser desfeita.",
      notifTodayTitle:"Marcações de hoje", notifTodayBody:"Tens {n} marcações hoje. A primeira às 09:00.",
      notifCancelTitleDemo:"Marcação cancelada", notifCancelBodyDemo:"João Costa cancelou a marcação de hoje às 14:00.",
      notifNewDemoTitle:"Nova marcação", notifNewDemoBody:"Miguel Ferreira marcou Corte Clássico para amanhã às 10:00.",
      notifGoodMorning:"Bom dia, {name}!", notifTodaySummary:"Tens {n} marcação(ões) hoje. Primeira às {time}h.",
      notifNewBookingTitle:"Nova marcação adicionada", notifBookingDeletedTitle:"Marcação eliminada", notifBookingDeletedBody:"{name} — {date} às {time}h foi removida.",
      notifCancelTitle:"Marcação cancelada", notifCancelBody:"{name} cancelou — {date} às {time}h.",
      notifSubActivatedTitle:"Subscrição ativada", notifSubActivatedBody:"Plano {plan} ativo. Obrigado, {owner}!", absenceName:"Ausência", yesterdaySummaryTitle:"Resumo de ontem", yesterdaySummaryBody:"Concluíste {n} serviços. Receita: €{amount}.",
      portalTitle:"Área do Proprietário", portalSubtitle:"Entra ou cria a tua barbearia", haveAccountTab:"Já tenho conta", createShopTab:"Criar barbearia",
      emailLabel:"Email", placeholderEmail:"o-teu-email@exemplo.com", placeholderPass:"••••••••", loginBtn:"Entrar", loggingIn:"A entrar...",
      yourNameLabel:"O teu nome", placeholderFullName:"Nome completo", placeholderShopName:"Ex: Barbearia do Zé", phoneOptionalLabel:"Telefone (opcional)",
      placeholderPhone:"+351 9xx xxx xxx", placeholderCreatePass:"Cria uma password", createShopBtn:"Criar a minha barbearia", creatingBtn:"A criar...",
      fillEmailPass:"Preenche o email e a password.", fillAllFields:"Preenche todos os campos.", shopAlreadyExists:"Já existe uma barbearia registada com esse email.",
      wrongCredentials:"Email ou password incorretos.", lastOwnerErr:"Não é possível apagar o único Proprietário da loja. Torna outro colaborador Proprietário primeiro, ou edita este perfil em vez de o apagar.", createShopFailed:"Não foi possível criar a barbearia. Tenta outra vez.",
      loadingText:"A CARREGAR...", shopNotFoundTitle:"Barbearia não encontrada", shopNotFoundBody:"O link que usaste não corresponde a nenhuma barbearia registada.", goToOwnerPortal:"Ir para a Área do Proprietário",
      chatBtn:"💬 Mensagens", chatTitle:"Chat", chatEmpty:"Ainda não há mensagens. Diz olá!", chatPlaceholder:"Escreve uma mensagem…",
      chatWithBarberCta:"💬 Falar com o barbeiro", chatPickBarber:"Escolhe com quem falar", chatNoBarbers:"Ainda não tens marcações com nenhum barbeiro.",
      notifNewMsgTitle:"Nova mensagem", notifNewMsgBody:"{name} enviou-te uma mensagem.",
      ordersTabLabel:"Encomendas", ordersAddPlaceholder:"Ex: shampoo, lâminas...", ordersAddBtn:"Adicionar", ordersEmpty:"Nenhum produto na lista.", ordersPhotoAttached:"Foto anexada",
      catalogTabLabel:"Catálogo", catalogNamePlaceholder:"Nome do produto", catalogPricePlaceholder:"Preço", catalogAddBtn:"Adicionar produto", catalogEmpty:"Ainda não há produtos no catálogo.", catalogUnavailable:"Indisponível", catalogMarkAvailable:"Marcar disponível", catalogMarkUnavailable:"Marcar indisponível", catalogClientCta:"Ver produtos",
      joinAsNew:"Sou novo colaborador, quero juntar-me →", yourNameShort:"O teu nome", fullNamePlaceholder:"Nome completo", createAccessCode:"Cria o teu código de acesso (4-6 números)",
      phoneOptional:"Telefone (opcional)", joinTeamBtn:"Juntar-me à equipa", alreadyHaveCode:"← Já tenho código de acesso",
      writeYourName:"Escreve o teu nome.", codeLength:"O código deve ter entre 4 e 6 números.", codeInUse:"Esse código já está a ser usado. Escolhe outro.",
    }
  },
  en:{ flag:"🇬🇧", name:"English",
    months:["January","February","March","April","May","June","July","August","September","October","November","December"],
    wdays:["Sun","Mon","Tue","Wed","Thu","Fri","Sat"],
    wdaysF:["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
    pay:["Cash","MB Way","Debit Card","Transfer","Other"],
    t:{
      client:"I'm a Client", bookCta:"Book Appointment", clientSub:"Book services, view appointments and browse products", myBookingsLabel:"View My Bookings", phonePlaceholder:"Your phone number", ourTeam:"Our Team", barberLabel:"Barber", priceLabel:"Price", nameLabel:"Name", namePlaceholder:"Your name", noBookingsFound:"No bookings found",
      barber:"I'm a Barber", barberSub:"Manage schedule, appointments and authorised clients", ownerBtnSub:"Register and manage my barbershop",
      platform:"Your barbershop platform",
      accessCode:"Access Code", enter:"Enter", wrongPin:"Incorrect code",
      hide:"Hide", show:"Show",
      barberArea:"Barber Area", clientArea:"Client Area",
      today:"Today", tomorrow:"Tomorrow", yesterday:"Yesterday",
      bookings:"bookings", concluded:"completed", toConfirm:"Confirm",
      week:"Week", revenue:"Today's Revenue", pendingRev:"pending",
      nextBookings:"Upcoming bookings", noFuture:"No upcoming bookings",
      agenda:"Agenda", dashboard:"Home", notifications:"Alerts",
      clients:"Clients", reports:"Revenue", schedule:"Schedule", profile:"Profile",
      newBooking:"+ New", block:"🔒 Block", addBooking:"New Booking",
      editBooking:"Edit Booking", save:"Save", delete:"Delete", close:"Close",
      clientName:"Client Name", fullName:"Full name", phone:"Phone",
      date:"Date", time:"Time", service:"Service", payment:"Paid", payMethod:"— method —",
      notes:"Notes", observations:"Observations…", back:"← Back", next:"Continue →",
      confirmed:"Confirmed", done:"Completed", cancelled:"Cancelled", blocked:"Blocked", selected:"Selected", noShow:"No-show",
      freeSlots:"Available slots", dayBlocked:"Full day blocked", unblock:"Unblock",
      blockSlot:"Time slot", blockDay:"Full day", blockPeriod:"Period", blockHours:"Absence",
      blockSlotTitle:"Choose slot to block", blockDayTitle:"Block full day", blockHoursTitle:"Block absence hours",
      blockPeriodTitle:"Block period (e.g. holidays)", blockDays:"days blocked",
      noBookings:"No bookings — tap + New to add", holiday:"Day off",
      searchClient:"Search name or phone…", visits:"visit", totalSpent:"total spent",
      barberNotes:"Barber notes", noNotes:"No notes — click Edit to add",
      edit:"Edit", cancel:"Cancel", upcoming:"Upcoming bookings", history:"Visit history",
      noHistory:"No history", favorite:"Favourite",
      confirmedRev:"✓ Confirmed Revenue", pendingPayment:"⚠ Pending Payment", scheduled:"Scheduled",
      payConfirm:"Confirm Payment", confirmReceipt:"✓ Confirm Receipt of",
      printToday:"Today's Report", printMonth:"Monthly Report",
      byMethod:"By payment method", byService:"By service", last7:"Confirmed revenue — 7 days",
      records:"Records", total:"total", services:"Services",
      workDays:"Work days", startHour:"Start", endHour:"End", generatedSlots:"Generated slots",
      saveSchedule:"Save Schedule", barbershop:"Barbershop", barberName:"Barber Name",
      address:"Address", bio:"Bio", newPin:"New PIN", keepPin:"Leave empty to keep current",
      logout:"Sign out", chooseBarber:"1. Choose barber", chooseService:"2. Choose service",
      chooseDate:"3. Choose date", yourData:"4. Your details", confirm:"Confirm Booking",
      bookingConfirmed:"Confirmed!", newBookingBtn:"New Booking", myBookings:"My Bookings",
      myBookingsTitle:"My bookings", cancelBooking:"Cancel",
      trialDays:"d trial", active:"✓ ACTIVE", subscribeTitle:"Choose your plan",
      subscribeSubtitle:"No commitment. Cancel anytime.",
      trialStatus:"Trial Status", daysLeft:"days remaining", trialExpired:"Trial expired",
      solo:"Solo", team:"Team", subscribeNow:"Subscribe Now",
      expiredTitle:"Trial expired", expiredSub:"Your data is saved.\nSubscribe to continue.",
      seePlans:"See Plans from €9.99/month", readMore:"Learn more",
      markAllRead:"Mark read", clearAllBtn:"Clear", noNotifications:"No notifications",
      pendingOpen:"pending",
      clientWord:"client", bookedBadge:"BOOKED", lastVisitLabel:"Last",
      notePlaceholder:"Notes about the client (preferences, allergies, etc.)…", saveNoteBtn:"Save Note",
      statVisitsLabel:"Visits", statSpentLabel:"Spent", statNoShowsLabel:"No-shows", noShowWarning:"⚠ No-showed {n}x before", markNoShowBtn:"No-show",
      noBookingCanBeMade:"No client will be able to book on this day.", fromDate:"From", toDate:"To",
      noBookingsShort:"No bookings", blockedSlotLabel:"Blocked time slot",
      all:"All", servicesUnconfirmed:"unconfirmed payment", paidConfirmedCount:"paid and confirmed",
      unconfirmedCount:"unconfirmed", scheduledLabel:"Scheduled", futureCount:"upcoming",
      paidAndConfirmed:"Paid and Confirmed", serviceDonePaymentPending:"Service Done — Payment Pending",
      scheduledCount:"Scheduled", noRecordsPeriod:"No records for this period",
      role:"Role",
      paymentMethod:"Payment Method", confirmAmountBtn:"✓ Confirm",
      reportLabel:"Report", issuedOn:"Issued on", billed:"Billed", paidServices:"Paid Services",
      unconfirmedPayment:"Unconfirmed Payment", printBtn:"Print",
      adminOverview:"Overview", adminBarbersTab:"Barbers", totalBilled:"Total Billed", barbersLabel:"Barbers", todayAllLabel:"Today (all)", totalBookingsLabel:"Total Bookings", teamToday:"Team today", bookingsTodayCount:"bookings today", barbersCountSuffix:"barbers", addNew:"+ New", activeLabel:"Active", offLabel:"Off", editBarberTitle:"Edit Barber", newBarberTitle:"New Barber", pinLabel:"PIN", colorLabel:"Color", adminPinLabel:"Admin PIN", shopPhoto:"Barbershop photo", uploading:"Uploading...", changePhoto:"Change photo", choosePhoto:"Choose photo", dangerZone:"Danger zone", deleteShopWarning:"Deleting the barbershop permanently removes all data (bookings, barbers, services). This action cannot be undone.", deleteShopBtn:"Delete barbershop", deleteShopConfirmPre:"This action is permanent. To confirm, type the exact barbershop name (", deleteShopConfirmPost:") and your password.", shopNameLabel:"Barbershop name", passwordLabel:"Password", deleting:"Deleting...", deletePermanently:"Delete permanently",
      servicesCountSuffix:"services", editServiceTitle:"Edit Service", newServiceTitle:"New Service", durationLabel:"Duration (min)", servicePriceLabel:"Price (€)",
      trialExpiredShort:"Trial expired", subscribeToContinue:"— subscribe to continue", trialDaysRemaining:"{n} day(s) left in trial", tapSeePlans:"Tap to see plans from €{price}/month", seeArrow:"SEE →",
      subscriptionLabel:"Subscription", freeTrialOfDays:"Free {days}-day trial", dayWord:"Day", availablePlans:"Available plans", soloDesc:"1 independent barber", perMonth:"/month", soloFeatures:["Full agenda","Clients and history","Accounting","Reports and printing","Notifications"], teamDesc:"Barbershop with collaborators", perBarberMonth:"/barber/month", teamFeatures:["Everything in Solo","Multiple barbers","Admin panel","Collaborator management","Per-barber metrics"], popularBadge:"POPULAR", teamCalcLabel:"Team calculator", activeBarbersCount:"{n} active barber(s)", teamCalcFormula:"{n} × €{price} = €{total}/month", savingsVsSolo:"you save €{amount} vs individual Solo", planWord:"Plan", monthlyRenewal:"Automatic monthly renewal", securePayment:"Secure payment · Cancel anytime", demoNote:"Demo: click to simulate subscription", faqTitle:"Frequently asked questions", faqItems:[["Can I cancel?","Yes, at any time. No penalties."],["How do I add collaborators?","In the Admin panel you create each barber's profile. On the Team plan each one costs €7.99/month."],["What happens after the trial?","The app blocks access to the agenda until you subscribe. Your data stays saved."],["Are there hidden costs?","No. The price is fixed per barber per month."]],
      expiredFull:"Your 15 free days have ended.\nYour data is saved.\nSubscribe to keep using the app.", noCommitmentFooter:"No commitment · Cancel anytime",
      photoTooLarge:"The image is too large (max 5MB).", uploadFailed:"Could not upload the image.", changeProfilePhoto:"Change profile photo",
      cutHistoryTitle:"Cut history", addCutBtn:"+ Add cut", tapCamera:"📷 Open camera", tapGallery:"🖼️ Upload file",
      cutNotesPlaceholder:"Technical notes (e.g. clipper guard #2 on the sides, scissors on top)", saveCutBtn:"Save cut", noCutsYet:"You haven't recorded any cuts for this client yet.",
      deleteCutBtn:"Delete cut",
      purchaseHistoryTitle:"Purchase history", addPurchaseBtn:"+ Add purchase", purchaseTextPlaceholder:"Product description (e.g. Matte pomade)", savePurchaseBtn:"Save purchase", noPurchasesYet:"No purchases recorded for this client yet.", deletePurchaseBtn:"Delete purchase", purchaseRecordTitle:"Purchase", addPurchaseErr:"Write a description or add a photo.",
      cutRecordTitle:"Cut", addCutPhotoErr:"Add a photo of the cut.", addClientBtn:"+ Add client", nameRequiredErr:"Name is required.",
      navHome:"Home", navAgenda:"Agenda", navAlerts:"Alerts", navClients:"Clients", navReports:"Revenue", navSchedule:"Schedule", navProfile:"Profile", navShop:"Shop", todaySuffix:"today", activeSubBadge:"ACTIVE",
      blockedDayName:"Blocked Day", blockedPeriodName:"Blocked Period", breakStartLabel:"Break start", breakEndLabel:"Break end", noBreakOption:"No break", deleteClientBtn:"Delete client", deleteClientWarning:"This permanently removes the history, notes, and recorded cuts for {name}. This action cannot be undone.",
      notifTodayTitle:"Today's bookings", notifTodayBody:"You have {n} bookings today. First at 09:00.",
      notifCancelTitleDemo:"Booking cancelled", notifCancelBodyDemo:"João Costa cancelled today's 14:00 booking.",
      notifNewDemoTitle:"New booking", notifNewDemoBody:"Miguel Ferreira booked a Classic Cut for tomorrow at 10:00.",
      notifGoodMorning:"Good morning, {name}!", notifTodaySummary:"You have {n} booking(s) today. First at {time}h.",
      notifNewBookingTitle:"New booking added", notifBookingDeletedTitle:"Booking deleted", notifBookingDeletedBody:"{name} — {date} at {time}h was removed.",
      notifCancelTitle:"Booking cancelled", notifCancelBody:"{name} cancelled — {date} at {time}h.",
      notifSubActivatedTitle:"Subscription activated", notifSubActivatedBody:"{plan} plan active. Thanks, {owner}!", absenceName:"Absence", yesterdaySummaryTitle:"Yesterday's summary", yesterdaySummaryBody:"You completed {n} services. Revenue: €{amount}.",
      portalTitle:"Owner Portal", portalSubtitle:"Log in or create your barbershop", haveAccountTab:"I have an account", createShopTab:"Create barbershop",
      emailLabel:"Email", placeholderEmail:"your-email@example.com", placeholderPass:"••••••••", loginBtn:"Log in", loggingIn:"Logging in...",
      yourNameLabel:"Your name", placeholderFullName:"Full name", placeholderShopName:"E.g.: Joe's Barbershop", phoneOptionalLabel:"Phone (optional)",
      placeholderPhone:"+1 xxx xxx xxxx", placeholderCreatePass:"Create a password", createShopBtn:"Create my barbershop", creatingBtn:"Creating...",
      fillEmailPass:"Fill in the email and password.", fillAllFields:"Fill in all fields.", shopAlreadyExists:"A barbershop is already registered with that email.",
      wrongCredentials:"Wrong email or password.", lastOwnerErr:"You cannot delete the shop's only Owner. Make another staff member Owner first, or edit this profile instead of deleting it.", createShopFailed:"Could not create the barbershop. Try again.",
      loadingText:"LOADING...", shopNotFoundTitle:"Barbershop not found", shopNotFoundBody:"The link you used doesn't match any registered barbershop.", goToOwnerPortal:"Go to Owner Portal",
      chatBtn:"💬 Messages", chatTitle:"Chat", chatEmpty:"No messages yet. Say hi!", chatPlaceholder:"Write a message…",
      chatWithBarberCta:"💬 Message your barber", chatPickBarber:"Choose who to talk to", chatNoBarbers:"You don't have bookings with any barber yet.",
      notifNewMsgTitle:"New message", notifNewMsgBody:"{name} sent you a message.",
      ordersTabLabel:"Restock", ordersAddPlaceholder:"e.g. shampoo, razors...", ordersAddBtn:"Add", ordersEmpty:"No products on the list.", ordersPhotoAttached:"Photo attached",
      catalogTabLabel:"Catalog", catalogNamePlaceholder:"Product name", catalogPricePlaceholder:"Price", catalogAddBtn:"Add product", catalogEmpty:"No products in the catalog yet.", catalogUnavailable:"Unavailable", catalogMarkAvailable:"Mark available", catalogMarkUnavailable:"Mark unavailable", catalogClientCta:"View products",
      joinAsNew:"I'm a new collaborator, I want to join →", yourNameShort:"Your name", fullNamePlaceholder:"Full name", createAccessCode:"Create your access code (4-6 digits)",
      phoneOptional:"Phone (optional)", joinTeamBtn:"Join the team", alreadyHaveCode:"← I already have an access code",
      writeYourName:"Write your name.", codeLength:"The code must be 4 to 6 digits.", codeInUse:"That code is already in use. Choose another.",
    }
  },
  es:{ flag:"🇪🇸", name:"Español",
    months:["Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre"],
    wdays:["Dom","Lun","Mar","Mié","Jue","Vie","Sáb"],
    wdaysF:["Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"],
    pay:["Efectivo","MB Way","Tarjeta","Transferencia","Otro"],
    t:{
      client:"Soy Cliente", bookCta:"Reservar Cita", clientSub:"Reservar servicios, consultar citas y ver productos", myBookingsLabel:"Ver Mis Citas", phonePlaceholder:"Su teléfono", ourTeam:"Nuestro Equipo", barberLabel:"Barbero", priceLabel:"Precio", nameLabel:"Nombre", namePlaceholder:"Su nombre", noBookingsFound:"No se encontraron citas",
      barber:"Soy Barbero", barberSub:"Gestionar agenda, atenciones y clientes autorizados", ownerBtnSub:"Registrar y gestionar mi barbería",
      platform:"Tu plataforma de barbería",
      accessCode:"Código de Acceso", enter:"Entrar", wrongPin:"Código incorrecto",
      hide:"Ocultar", show:"Ver",
      barberArea:"Área del Barbero", clientArea:"Área del Cliente",
      today:"Hoy", tomorrow:"Mañana", yesterday:"Ayer",
      bookings:"citas", concluded:"completadas", toConfirm:"Confirmar",
      week:"Semana", revenue:"Ingresos Hoy", pendingRev:"pendiente",
      nextBookings:"Próximas citas", noFuture:"Sin citas futuras",
      agenda:"Agenda", dashboard:"Inicio", notifications:"Alertas",
      clients:"Clientes", reports:"Ingresos", schedule:"Horario", profile:"Perfil",
      newBooking:"+ Nuevo", block:"🔒 Bloquear", addBooking:"Nueva Cita",
      editBooking:"Editar Cita", save:"Guardar", delete:"Eliminar", close:"Cerrar",
      clientName:"Nombre del Cliente", fullName:"Nombre completo", phone:"Teléfono",
      date:"Fecha", time:"Hora", service:"Servicio", payment:"Pagado", payMethod:"— método —",
      notes:"Notas", observations:"Observaciones…", back:"← Volver", next:"Continuar →",
      confirmed:"Confirmado", done:"Completado", cancelled:"Cancelado", blocked:"Bloqueado", selected:"Seleccionado", noShow:"Falta",
      freeSlots:"Horarios libres", dayBlocked:"Día completo bloqueado", unblock:"Desbloquear",
      blockSlot:"Horario", blockDay:"Día completo", blockPeriod:"Período", blockHours:"Ausencia",
      blockSlotTitle:"Elige el horario a bloquear", blockDayTitle:"Bloquear día completo", blockHoursTitle:"Bloquear horas de ausencia",
      blockPeriodTitle:"Bloquear período (ej. vacaciones)", blockDays:"días bloqueados",
      noBookings:"Sin citas — toca + Nuevo", holiday:"Día libre",
      searchClient:"Buscar nombre o teléfono…", visits:"visita", totalSpent:"total gastado",
      barberNotes:"Notas del barbero", noNotes:"Sin notas — haz clic en Editar",
      edit:"Editar", cancel:"Cancelar", upcoming:"Próximas citas", history:"Historial de visitas",
      noHistory:"Sin historial", favorite:"Favorito",
      confirmedRev:"✓ Ingresos Confirmados", pendingPayment:"⚠ Por Cobrar", scheduled:"Programado",
      payConfirm:"Confirmar Pago", confirmReceipt:"✓ Confirmar Cobro de",
      printToday:"Informe Hoy", printMonth:"Informe Mes",
      byMethod:"Por método de pago", byService:"Por servicio", last7:"Ingresos confirmados — 7 días",
      records:"Registros", total:"total", services:"Servicios",
      workDays:"Días de trabajo", startHour:"Inicio", endHour:"Fin", generatedSlots:"Horarios generados",
      saveSchedule:"Guardar Horario", barbershop:"Barbería", barberName:"Nombre del Barbero",
      address:"Dirección", bio:"Bio", newPin:"Nuevo PIN", keepPin:"Dejar vacío para mantener",
      logout:"Salir", chooseBarber:"1. Elige el barbero", chooseService:"2. Elige el servicio",
      chooseDate:"3. Elige la fecha", yourData:"4. Tus datos", confirm:"Confirmar Reserva",
      bookingConfirmed:"¡Confirmado!", newBookingBtn:"Nueva Reserva", myBookings:"Mis Reservas",
      myBookingsTitle:"Mis reservas", cancelBooking:"Cancelar",
      trialDays:"d prueba", active:"✓ ACTIVO", subscribeTitle:"Elige tu plan",
      subscribeSubtitle:"Sin compromiso. Cancela cuando quieras.",
      trialStatus:"Estado de Prueba", daysLeft:"días restantes", trialExpired:"Prueba expirada",
      solo:"Solo", team:"Equipo", subscribeNow:"Suscribirse Ahora",
      expiredTitle:"Prueba expirada", expiredSub:"Tus datos están guardados.\nSuscríbete para continuar.",
      seePlans:"Ver Planes desde €9,99/mes", readMore:"Saber más",
      markAllRead:"Marcar leídas", clearAllBtn:"Borrar", noNotifications:"Sin notificaciones",
      pendingOpen:"pendiente",
      clientWord:"cliente", bookedBadge:"RESERVADO", lastVisitLabel:"Última",
      notePlaceholder:"Notas sobre el cliente (preferencias, alergias, etc.)…", saveNoteBtn:"Guardar Nota",
      statVisitsLabel:"Visitas", statSpentLabel:"Gastado", statNoShowsLabel:"Faltas", noShowWarning:"⚠ Ya faltó {n}x sin avisar", markNoShowBtn:"Falta",
      noBookingCanBeMade:"Ningún cliente podrá reservar este día.", fromDate:"Desde", toDate:"Hasta",
      noBookingsShort:"Sin reservas", blockedSlotLabel:"Horario bloqueado",
      all:"Todo", servicesUnconfirmed:"sin pago confirmado", paidConfirmedCount:"pagados y confirmados",
      unconfirmedCount:"sin confirmar", scheduledLabel:"Programado", futureCount:"futuras",
      paidAndConfirmed:"Pagados y Confirmados", serviceDonePaymentPending:"Servicio Hecho — Pago Pendiente",
      scheduledCount:"Programados", noRecordsPeriod:"Sin registros para este período",
      role:"Función",
      paymentMethod:"Método de Pago", confirmAmountBtn:"✓ Confirmar",
      reportLabel:"Informe", issuedOn:"Emitido el", billed:"Facturado", paidServices:"Servicios Pagados",
      unconfirmedPayment:"Pago No Confirmado", printBtn:"Imprimir",
      adminOverview:"General", adminBarbersTab:"Barberos", totalBilled:"Total Facturado", barbersLabel:"Barberos", todayAllLabel:"Hoy (todos)", totalBookingsLabel:"Total de Citas", teamToday:"Equipo hoy", bookingsTodayCount:"citas hoy", barbersCountSuffix:"barberos", addNew:"+ Nuevo", activeLabel:"Activo", offLabel:"Off", editBarberTitle:"Editar Barbero", newBarberTitle:"Nuevo Barbero", pinLabel:"PIN", colorLabel:"Color", adminPinLabel:"PIN Admin", shopPhoto:"Foto de la barbería", uploading:"Subiendo...", changePhoto:"Cambiar foto", choosePhoto:"Elegir foto", dangerZone:"Zona de peligro", deleteShopWarning:"Eliminar la barbería borra definitivamente todos los datos (citas, barberos, servicios). Esta acción no se puede deshacer.", deleteShopBtn:"Eliminar barbería", deleteShopConfirmPre:"Esta acción es permanente. Para confirmar, escribe el nombre exacto de la barbería (", deleteShopConfirmPost:") y tu contraseña.", shopNameLabel:"Nombre de la barbería", passwordLabel:"Contraseña", deleting:"Eliminando...", deletePermanently:"Eliminar definitivamente",
      servicesCountSuffix:"servicios", editServiceTitle:"Editar Servicio", newServiceTitle:"Nuevo Servicio", durationLabel:"Duración (min)", servicePriceLabel:"Precio (€)",
      trialExpiredShort:"Prueba caducada", subscribeToContinue:"— suscríbete para continuar", trialDaysRemaining:"{n} día(s) de prueba restante(s)", tapSeePlans:"Toca para ver planes desde €{price}/mes", seeArrow:"VER →",
      subscriptionLabel:"Suscripción", freeTrialOfDays:"Prueba gratuita de {days} días", dayWord:"Día", availablePlans:"Planes disponibles", soloDesc:"1 barbero independiente", perMonth:"/mes", soloFeatures:["Agenda completa","Clientes e historial","Contabilidad","Informes e impresión","Notificaciones"], teamDesc:"Barbería con colaboradores", perBarberMonth:"/barbero/mes", teamFeatures:["Todo del plan Solo","Múltiples barberos","Panel de administrador","Gestión de colaboradores","Métricas por barbero"], popularBadge:"POPULAR", teamCalcLabel:"Calculadora de equipo", activeBarbersCount:"{n} barbero(s) activo(s)", teamCalcFormula:"{n} × €{price} = €{total}/mes", savingsVsSolo:"ahorras €{amount} vs Solo individual", planWord:"Plan", monthlyRenewal:"Renovación mensual automática", securePayment:"Pago seguro · Cancela cuando quieras", demoNote:"Demo: haz clic para simular la suscripción", faqTitle:"Preguntas frecuentes", faqItems:[["¿Puedo cancelar?","Sí, en cualquier momento. Sin penalizaciones."],["¿Cómo añado colaboradores?","En el panel Admin creas el perfil de cada barbero. En el plan Equipo cada uno paga €7,99/mes."],["¿Qué pasa después de la prueba?","La app bloquea el acceso a la agenda hasta que te suscribas. Tus datos quedan guardados."],["¿Hay costes ocultos?","No. El precio es fijo por barbero al mes."]],
      expiredFull:"Tus 15 días gratis han terminado.\nTus datos están guardados.\nSuscríbete para seguir usando la app.", noCommitmentFooter:"Sin compromiso · Cancela cuando quieras",
      photoTooLarge:"La imagen es demasiado grande (máx. 5MB).", uploadFailed:"No se pudo subir la imagen.", changeProfilePhoto:"Cambiar foto de perfil",
      cutHistoryTitle:"Historial de cortes", addCutBtn:"+ Añadir corte", tapCamera:"📷 Abrir cámara", tapGallery:"🖼️ Subir archivo",
      cutNotesPlaceholder:"Notas técnicas (ej: cuchilla nº2 en los laterales, tijera arriba)", saveCutBtn:"Guardar corte", noCutsYet:"Aún no has registrado cortes para este cliente.",
      deleteCutBtn:"Eliminar corte",
      purchaseHistoryTitle:"Historial de compras", addPurchaseBtn:"+ Añadir compra", purchaseTextPlaceholder:"Descripción del producto (ej: Pomada mate)", savePurchaseBtn:"Guardar compra", noPurchasesYet:"Aún no hay compras registradas para este cliente.", deletePurchaseBtn:"Eliminar compra", purchaseRecordTitle:"Compra", addPurchaseErr:"Escribe una descripción o añade una foto.",
      cutRecordTitle:"Corte", addCutPhotoErr:"Añade una foto del corte.", addClientBtn:"+ Añadir cliente", nameRequiredErr:"El nombre es obligatorio.",
      navHome:"Inicio", navAgenda:"Agenda", navAlerts:"Alertas", navClients:"Clientes", navReports:"Ingresos", navSchedule:"Horario", navProfile:"Perfil", navShop:"Tienda", todaySuffix:"hoy", activeSubBadge:"ACTIVO",
      blockedDayName:"Día Bloqueado", blockedPeriodName:"Período Bloqueado", breakStartLabel:"Inicio de la pausa", breakEndLabel:"Fin de la pausa", noBreakOption:"Sin pausa", deleteClientBtn:"Eliminar cliente", deleteClientWarning:"Esto elimina definitivamente el historial, notas y cortes registrados de {name}. Esta acción no se puede deshacer.",
      notifTodayTitle:"Citas de hoy", notifTodayBody:"Tienes {n} citas hoy. La primera a las 09:00.",
      notifCancelTitleDemo:"Cita cancelada", notifCancelBodyDemo:"João Costa canceló la cita de hoy a las 14:00.",
      notifNewDemoTitle:"Nueva cita", notifNewDemoBody:"Miguel Ferreira reservó un Corte Clásico para mañana a las 10:00.",
      notifGoodMorning:"Buenos días, {name}!", notifTodaySummary:"Tienes {n} cita(s) hoy. La primera a las {time}h.",
      notifNewBookingTitle:"Nueva cita añadida", notifBookingDeletedTitle:"Cita eliminada", notifBookingDeletedBody:"{name} — {date} a las {time}h fue eliminada.",
      notifCancelTitle:"Cita cancelada", notifCancelBody:"{name} canceló — {date} a las {time}h.",
      notifSubActivatedTitle:"Suscripción activada", notifSubActivatedBody:"Plan {plan} activo. ¡Gracias, {owner}!", absenceName:"Ausencia", yesterdaySummaryTitle:"Resumen de ayer", yesterdaySummaryBody:"Completaste {n} servicios. Ingresos: €{amount}.",
      portalTitle:"Portal del Dueño", portalSubtitle:"Entra o crea tu barbería", haveAccountTab:"Ya tengo cuenta", createShopTab:"Crear barbería",
      emailLabel:"Email", placeholderEmail:"tu-email@ejemplo.com", placeholderPass:"••••••••", loginBtn:"Entrar", loggingIn:"Entrando...",
      yourNameLabel:"Tu nombre", placeholderFullName:"Nombre completo", placeholderShopName:"Ej: Barbería de José", phoneOptionalLabel:"Teléfono (opcional)",
      placeholderPhone:"+34 6xx xxx xxx", placeholderCreatePass:"Crea una contraseña", createShopBtn:"Crear mi barbería", creatingBtn:"Creando...",
      fillEmailPass:"Rellena el email y la contraseña.", fillAllFields:"Rellena todos los campos.", shopAlreadyExists:"Ya existe una barbería registrada con ese email.",
      wrongCredentials:"Email o contraseña incorrectos.", lastOwnerErr:"No puedes eliminar al único Propietario de la barbería. Haz Propietario a otro colaborador primero, o edita este perfil en vez de eliminarlo.", createShopFailed:"No se pudo crear la barbería. Inténtalo de nuevo.",
      loadingText:"CARGANDO...", shopNotFoundTitle:"Barbería no encontrada", shopNotFoundBody:"El enlace que usaste no corresponde a ninguna barbería registrada.", goToOwnerPortal:"Ir al Portal del Dueño",
      chatBtn:"💬 Mensajes", chatTitle:"Chat", chatEmpty:"Aún no hay mensajes. ¡Saluda!", chatPlaceholder:"Escribe un mensaje…",
      chatWithBarberCta:"💬 Hablar con el barbero", chatPickBarber:"Elige con quién hablar", chatNoBarbers:"Aún no tienes reservas con ningún barbero.",
      notifNewMsgTitle:"Nuevo mensaje", notifNewMsgBody:"{name} te envió un mensaje.",
      ordersTabLabel:"Pedidos", ordersAddPlaceholder:"Ej: champú, cuchillas...", ordersAddBtn:"Añadir", ordersEmpty:"Ningún producto en la lista.", ordersPhotoAttached:"Foto adjunta",
      catalogTabLabel:"Catálogo", catalogNamePlaceholder:"Nombre del producto", catalogPricePlaceholder:"Precio", catalogAddBtn:"Añadir producto", catalogEmpty:"Aún no hay productos en el catálogo.", catalogUnavailable:"No disponible", catalogMarkAvailable:"Marcar disponible", catalogMarkUnavailable:"Marcar no disponible", catalogClientCta:"Ver productos",
      joinAsNew:"Soy nuevo colaborador, quiero unirme →", yourNameShort:"Tu nombre", fullNamePlaceholder:"Nombre completo", createAccessCode:"Crea tu código de acceso (4-6 números)",
      phoneOptional:"Teléfono (opcional)", joinTeamBtn:"Unirme al equipo", alreadyHaveCode:"← Ya tengo código de acceso",
      writeYourName:"Escribe tu nombre.", codeLength:"El código debe tener entre 4 y 6 números.", codeInUse:"Ese código ya está en uso. Elige otro.",
    }
  },
  fr:{ flag:"🇫🇷", name:"Français",
    months:["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"],
    wdays:["Dim","Lun","Mar","Mer","Jeu","Ven","Sam"],
    wdaysF:["Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"],
    pay:["Espèces","MB Way","Carte","Virement","Autre"],
    t:{
      client:"Je suis Client", bookCta:"Prendre RDV", clientSub:"Réserver des services, consulter mes rendez-vous et voir les produits", myBookingsLabel:"Voir Mes Rendez-vous", phonePlaceholder:"Votre téléphone", ourTeam:"Notre Équipe", barberLabel:"Coiffeur", priceLabel:"Prix", nameLabel:"Nom", namePlaceholder:"Votre nom", noBookingsFound:"Aucun rendez-vous trouvé",
      barber:"Je suis Barbier", barberSub:"Gérer l'agenda, les prestations et les clients autorisés", ownerBtnSub:"Enregistrer et gérer mon salon",
      platform:"Votre plateforme de barbier",
      accessCode:"Code d'Accès", enter:"Entrer", wrongPin:"Code incorrect",
      hide:"Masquer", show:"Voir",
      barberArea:"Espace Barbier", clientArea:"Espace Client",
      today:"Aujourd'hui", tomorrow:"Demain", yesterday:"Hier",
      bookings:"rendez-vous", concluded:"terminés", toConfirm:"Confirmer",
      week:"Semaine", revenue:"Revenus Aujourd'hui", pendingRev:"en attente",
      nextBookings:"Prochains rendez-vous", noFuture:"Aucun rendez-vous à venir",
      agenda:"Agenda", dashboard:"Accueil", notifications:"Alertes",
      clients:"Clients", reports:"Revenus", schedule:"Horaires", profile:"Profil",
      newBooking:"+ Nouveau", block:"🔒 Bloquer", addBooking:"Nouveau Rendez-vous",
      editBooking:"Modifier Rendez-vous", save:"Enregistrer", delete:"Supprimer", close:"Fermer",
      clientName:"Nom du Client", fullName:"Nom complet", phone:"Téléphone",
      date:"Date", time:"Heure", service:"Service", payment:"Payé", payMethod:"— méthode —",
      notes:"Notes", observations:"Observations…", back:"← Retour", next:"Continuer →",
      confirmed:"Confirmé", done:"Terminé", cancelled:"Annulé", blocked:"Bloqué", selected:"Sélectionné", noShow:"Absence",
      freeSlots:"Créneaux disponibles", dayBlocked:"Journée entière bloquée", unblock:"Débloquer",
      blockSlot:"Créneau", blockDay:"Journée entière", blockPeriod:"Période", blockHours:"Absence",
      blockSlotTitle:"Choisir le créneau à bloquer", blockDayTitle:"Bloquer la journée entière", blockHoursTitle:"Bloquer les heures d'absence",
      blockPeriodTitle:"Bloquer une période (ex. vacances)", blockDays:"jours bloqués",
      noBookings:"Aucun rendez-vous — appuyer sur + Nouveau", holiday:"Jour de repos",
      searchClient:"Rechercher nom ou téléphone…", visits:"visite", totalSpent:"total dépensé",
      barberNotes:"Notes du barbier", noNotes:"Aucune note — cliquer sur Modifier",
      edit:"Modifier", cancel:"Annuler", upcoming:"Prochains rendez-vous", history:"Historique des visites",
      noHistory:"Aucun historique", favorite:"Favori",
      confirmedRev:"✓ Revenus Confirmés", pendingPayment:"⚠ À Encaisser", scheduled:"Planifié",
      payConfirm:"Confirmer le Paiement", confirmReceipt:"✓ Confirmer l'encaissement de",
      printToday:"Rapport Aujourd'hui", printMonth:"Rapport Mensuel",
      byMethod:"Par méthode de paiement", byService:"Par service", last7:"Revenus confirmés — 7 jours",
      records:"Registres", total:"total", services:"Services",
      workDays:"Jours de travail", startHour:"Début", endHour:"Fin", generatedSlots:"Créneaux générés",
      saveSchedule:"Enregistrer les Horaires", barbershop:"Salon de coiffure", barberName:"Nom du Barbier",
      address:"Adresse", bio:"Bio", newPin:"Nouveau PIN", keepPin:"Laisser vide pour conserver",
      logout:"Déconnexion", chooseBarber:"1. Choisir le barbier", chooseService:"2. Choisir le service",
      chooseDate:"3. Choisir la date", yourData:"4. Vos coordonnées", confirm:"Confirmer la Réservation",
      bookingConfirmed:"Confirmé!", newBookingBtn:"Nouvelle Réservation", myBookings:"Mes Réservations",
      myBookingsTitle:"Mes réservations", cancelBooking:"Annuler",
      trialDays:"j essai", active:"✓ ACTIF", subscribeTitle:"Choisissez votre plan",
      subscribeSubtitle:"Sans engagement. Annulez quand vous voulez.",
      trialStatus:"Statut d'Essai", daysLeft:"jours restants", trialExpired:"Essai expiré",
      solo:"Solo", team:"Équipe", subscribeNow:"S'abonner Maintenant",
      expiredTitle:"Essai expiré", expiredSub:"Vos données sont sauvegardées.\nAbonnez-vous pour continuer.",
      seePlans:"Voir les Plans à partir de 9,99€/mois", readMore:"En savoir plus",
      markAllRead:"Marquer comme lu", clearAllBtn:"Effacer", noNotifications:"Aucune notification",
      pendingOpen:"en attente",
      clientWord:"client", bookedBadge:"RÉSERVÉ", lastVisitLabel:"Dernière",
      notePlaceholder:"Notes sur le client (préférences, allergies, etc.)…", saveNoteBtn:"Enregistrer la Note",
      statVisitsLabel:"Visites", statSpentLabel:"Dépensé", statNoShowsLabel:"Absences", noShowWarning:"⚠ Déjà absent {n}x sans prévenir", markNoShowBtn:"Absence",
      noBookingCanBeMade:"Aucun client ne pourra réserver ce jour.", fromDate:"Du", toDate:"Au",
      noBookingsShort:"Aucune réservation", blockedSlotLabel:"Créneau bloqué",
      all:"Tout", servicesUnconfirmed:"paiement non confirmé", paidConfirmedCount:"payés et confirmés",
      unconfirmedCount:"non confirmé", scheduledLabel:"Programmé", futureCount:"à venir",
      paidAndConfirmed:"Payés et Confirmés", serviceDonePaymentPending:"Service Effectué — Paiement en Attente",
      scheduledCount:"Programmés", noRecordsPeriod:"Aucun enregistrement pour cette période",
      role:"Fonction",
      paymentMethod:"Mode de Paiement", confirmAmountBtn:"✓ Confirmer",
      reportLabel:"Rapport", issuedOn:"Émis le", billed:"Facturé", paidServices:"Services Payés",
      unconfirmedPayment:"Paiement Non Confirmé", printBtn:"Imprimer",
      adminOverview:"Général", adminBarbersTab:"Barbiers", totalBilled:"Total Facturé", barbersLabel:"Barbiers", todayAllLabel:"Aujourd'hui (tous)", totalBookingsLabel:"Total des Réservations", teamToday:"Équipe aujourd'hui", bookingsTodayCount:"réservations aujourd'hui", barbersCountSuffix:"barbiers", addNew:"+ Nouveau", activeLabel:"Actif", offLabel:"Off", editBarberTitle:"Modifier le Barbier", newBarberTitle:"Nouveau Barbier", pinLabel:"PIN", colorLabel:"Couleur", adminPinLabel:"PIN Admin", shopPhoto:"Photo du salon", uploading:"Envoi...", changePhoto:"Changer la photo", choosePhoto:"Choisir une photo", dangerZone:"Zone de danger", deleteShopWarning:"Supprimer le salon efface définitivement toutes les données (réservations, barbiers, services). Cette action est irréversible.", deleteShopBtn:"Supprimer le salon", deleteShopConfirmPre:"Cette action est permanente. Pour confirmer, tape le nom exact du salon (", deleteShopConfirmPost:") et ton mot de passe.", shopNameLabel:"Nom du salon", passwordLabel:"Mot de passe", deleting:"Suppression...", deletePermanently:"Supprimer définitivement",
      servicesCountSuffix:"services", editServiceTitle:"Modifier le Service", newServiceTitle:"Nouveau Service", durationLabel:"Durée (min)", servicePriceLabel:"Prix (€)",
      trialExpiredShort:"Essai expiré", subscribeToContinue:"— abonne-toi pour continuer", trialDaysRemaining:"{n} jour(s) d'essai restant(s)", tapSeePlans:"Touche pour voir les plans dès €{price}/mois", seeArrow:"VOIR →",
      subscriptionLabel:"Abonnement", freeTrialOfDays:"Essai gratuit de {days} jours", dayWord:"Jour", availablePlans:"Plans disponibles", soloDesc:"1 barbier indépendant", perMonth:"/mois", soloFeatures:["Agenda complet","Clients et historique","Comptabilité","Rapports et impression","Notifications"], teamDesc:"Salon avec collaborateurs", perBarberMonth:"/barbier/mois", teamFeatures:["Tout du plan Solo","Plusieurs barbiers","Panneau d'administration","Gestion des collaborateurs","Statistiques par barbier"], popularBadge:"POPULAIRE", teamCalcLabel:"Calculateur d'équipe", activeBarbersCount:"{n} barbier(s) actif(s)", teamCalcFormula:"{n} × €{price} = €{total}/mois", savingsVsSolo:"tu économises €{amount} vs Solo individuel", planWord:"Plan", monthlyRenewal:"Renouvellement mensuel automatique", securePayment:"Paiement sécurisé · Annule à tout moment", demoNote:"Démo : clique pour simuler l'abonnement", faqTitle:"Questions fréquentes", faqItems:[["Puis-je annuler ?","Oui, à tout moment. Sans pénalités."],["Comment ajouter des collaborateurs ?","Dans le panneau Admin tu crées le profil de chaque barbier. Sur le plan Équipe chacun paie €7,99/mois."],["Que se passe-t-il après l'essai ?","L'app bloque l'accès à l'agenda jusqu'à ton abonnement. Tes données restent sauvegardées."],["Y a-t-il des coûts cachés ?","Non. Le prix est fixe par barbier et par mois."]],
      expiredFull:"Tes 15 jours gratuits sont terminés.\nTes données sont sauvegardées.\nAbonne-toi pour continuer à utiliser l'app.", noCommitmentFooter:"Sans engagement · Annule quand tu veux",
      photoTooLarge:"L'image est trop grande (max 5 Mo).", uploadFailed:"Impossible d'envoyer l'image.", changeProfilePhoto:"Changer la photo de profil",
      cutHistoryTitle:"Historique des coupes", addCutBtn:"+ Ajouter une coupe", tapCamera:"📷 Ouvrir la caméra", tapGallery:"🖼️ Importer un fichier",
      cutNotesPlaceholder:"Notes techniques (ex : tondeuse n°2 sur les côtés, ciseaux dessus)", saveCutBtn:"Enregistrer la coupe", noCutsYet:"Tu n'as pas encore enregistré de coupe pour ce client.",
      deleteCutBtn:"Supprimer la coupe",
      purchaseHistoryTitle:"Historique des achats", addPurchaseBtn:"+ Ajouter un achat", purchaseTextPlaceholder:"Description du produit (ex: Pommade mate)", savePurchaseBtn:"Enregistrer l'achat", noPurchasesYet:"Aucun achat enregistré pour ce client pour l'instant.", deletePurchaseBtn:"Supprimer l'achat", purchaseRecordTitle:"Achat", addPurchaseErr:"Écris une description ou ajoute une photo.",
      cutRecordTitle:"Coupe", addCutPhotoErr:"Ajoute une photo de la coupe.", addClientBtn:"+ Ajouter un client", nameRequiredErr:"Le nom est obligatoire.",
      navHome:"Accueil", navAgenda:"Agenda", navAlerts:"Alertes", navClients:"Clients", navReports:"Revenus", navSchedule:"Horaire", navProfile:"Profil", navShop:"Salon", todaySuffix:"aujourd'hui", activeSubBadge:"ACTIF",
      blockedDayName:"Jour Bloqué", blockedPeriodName:"Période Bloquée", breakStartLabel:"Début de la pause", breakEndLabel:"Fin de la pause", noBreakOption:"Sans pause", deleteClientBtn:"Supprimer le client", deleteClientWarning:"Cela supprime définitivement l'historique, les notes et les coupes enregistrées pour {name}. Cette action est irréversible.",
      notifTodayTitle:"Réservations du jour", notifTodayBody:"Tu as {n} réservations aujourd'hui. La première à 09:00.",
      notifCancelTitleDemo:"Réservation annulée", notifCancelBodyDemo:"João Costa a annulé la réservation de 14:00 aujourd'hui.",
      notifNewDemoTitle:"Nouvelle réservation", notifNewDemoBody:"Miguel Ferreira a réservé une Coupe Classique pour demain à 10:00.",
      notifGoodMorning:"Bonjour, {name} !", notifTodaySummary:"Tu as {n} réservation(s) aujourd'hui. La première à {time}h.",
      notifNewBookingTitle:"Nouvelle réservation ajoutée", notifBookingDeletedTitle:"Réservation supprimée", notifBookingDeletedBody:"{name} — {date} à {time}h a été supprimée.",
      notifCancelTitle:"Réservation annulée", notifCancelBody:"{name} a annulé — {date} à {time}h.",
      notifSubActivatedTitle:"Abonnement activé", notifSubActivatedBody:"Plan {plan} actif. Merci, {owner} !", absenceName:"Absence", yesterdaySummaryTitle:"Résumé d'hier", yesterdaySummaryBody:"Tu as réalisé {n} services. Revenus : €{amount}.",
      portalTitle:"Portail Propriétaire", portalSubtitle:"Connecte-toi ou crée ton salon", haveAccountTab:"J'ai déjà un compte", createShopTab:"Créer un salon",
      emailLabel:"Email", placeholderEmail:"ton-email@exemple.com", placeholderPass:"••••••••", loginBtn:"Se connecter", loggingIn:"Connexion...",
      yourNameLabel:"Ton nom", placeholderFullName:"Nom complet", placeholderShopName:"Ex : Salon de Jean", phoneOptionalLabel:"Téléphone (optionnel)",
      placeholderPhone:"+33 6 xx xx xx xx", placeholderCreatePass:"Crée un mot de passe", createShopBtn:"Créer mon salon", creatingBtn:"Création...",
      fillEmailPass:"Remplis l'email et le mot de passe.", fillAllFields:"Remplis tous les champs.", shopAlreadyExists:"Un salon est déjà enregistré avec cet email.",
      wrongCredentials:"Email ou mot de passe incorrect.", lastOwnerErr:"Impossible de supprimer l'unique Propriétaire du salon. Fais d'abord d'un autre collaborateur le Propriétaire, ou modifie ce profil au lieu de le supprimer.", createShopFailed:"Impossible de créer le salon. Réessaie.",
      loadingText:"CHARGEMENT...", shopNotFoundTitle:"Salon introuvable", shopNotFoundBody:"Le lien que tu as utilisé ne correspond à aucun salon enregistré.", goToOwnerPortal:"Aller au Portail Propriétaire",
      chatBtn:"💬 Messages", chatTitle:"Chat", chatEmpty:"Pas encore de messages. Dis bonjour !", chatPlaceholder:"Écris un message…",
      chatWithBarberCta:"💬 Parler au barbier", chatPickBarber:"Choisis avec qui parler", chatNoBarbers:"Tu n'as pas encore de réservation avec un barbier.",
      notifNewMsgTitle:"Nouveau message", notifNewMsgBody:"{name} t'a envoyé un message.",
      ordersTabLabel:"Commandes", ordersAddPlaceholder:"Ex : shampoing, lames...", ordersAddBtn:"Ajouter", ordersEmpty:"Aucun produit dans la liste.", ordersPhotoAttached:"Photo jointe",
      catalogTabLabel:"Catalogue", catalogNamePlaceholder:"Nom du produit", catalogPricePlaceholder:"Prix", catalogAddBtn:"Ajouter un produit", catalogEmpty:"Aucun produit dans le catalogue.", catalogUnavailable:"Indisponible", catalogMarkAvailable:"Marquer disponible", catalogMarkUnavailable:"Marquer indisponible", catalogClientCta:"Voir les produits",
      joinAsNew:"Je suis un nouveau collaborateur, je veux rejoindre →", yourNameShort:"Ton nom", fullNamePlaceholder:"Nom complet", createAccessCode:"Crée ton code d'accès (4-6 chiffres)",
      phoneOptional:"Téléphone (optionnel)", joinTeamBtn:"Rejoindre l'équipe", alreadyHaveCode:"← J'ai déjà un code d'accès",
      writeYourName:"Écris ton nom.", codeLength:"Le code doit comporter entre 4 et 6 chiffres.", codeInUse:"Ce code est déjà utilisé. Choisis-en un autre.",
    }
  },
  de:{ flag:"🇩🇪", name:"Deutsch",
    months:["Januar","Februar","März","April","Mai","Juni","Juli","August","September","Oktober","November","Dezember"],
    wdays:["So","Mo","Di","Mi","Do","Fr","Sa"],
    wdaysF:["Sonntag","Montag","Dienstag","Mittwoch","Donnerstag","Freitag","Samstag"],
    pay:["Bargeld","MB Way","Karte","Überweisung","Sonstiges"],
    t:{
      client:"Ich bin Kunde", bookCta:"Termin buchen", clientSub:"Leistungen buchen, Termine ansehen und Produkte entdecken", myBookingsLabel:"Meine Termine ansehen", phonePlaceholder:"Ihre Telefonnummer", ourTeam:"Unser Team", barberLabel:"Friseur", priceLabel:"Preis", nameLabel:"Name", namePlaceholder:"Ihr Name", noBookingsFound:"Keine Termine gefunden",
      barber:"Ich bin Friseur", barberSub:"Kalender, Termine und autorisierte Kunden verwalten", ownerBtnSub:"Meinen Salon registrieren und verwalten",
      platform:"Ihre Barbershop-Plattform",
      accessCode:"Zugangscode", enter:"Einloggen", wrongPin:"Falscher Code",
      hide:"Verbergen", show:"Anzeigen",
      barberArea:"Friseurbereich", clientArea:"Kundenbereich",
      today:"Heute", tomorrow:"Morgen", yesterday:"Gestern",
      bookings:"Termine", concluded:"abgeschlossen", toConfirm:"Bestätigen",
      week:"Woche", revenue:"Heutiger Umsatz", pendingRev:"ausstehend",
      nextBookings:"Nächste Termine", noFuture:"Keine bevorstehenden Termine",
      agenda:"Kalender", dashboard:"Startseite", notifications:"Benachrichtigungen",
      clients:"Kunden", reports:"Umsatz", schedule:"Arbeitszeiten", profile:"Profil",
      newBooking:"+ Neu", block:"🔒 Sperren", addBooking:"Neuer Termin",
      editBooking:"Termin bearbeiten", save:"Speichern", delete:"Löschen", close:"Schließen",
      clientName:"Kundenname", fullName:"Vollständiger Name", phone:"Telefon",
      date:"Datum", time:"Uhrzeit", service:"Leistung", payment:"Bezahlt", payMethod:"— Methode —",
      notes:"Notizen", observations:"Anmerkungen…", back:"← Zurück", next:"Weiter →",
      confirmed:"Bestätigt", done:"Abgeschlossen", cancelled:"Storniert", blocked:"Gesperrt", selected:"Ausgewählt", noShow:"Nicht erschienen",
      freeSlots:"Freie Slots", dayBlocked:"Ganzer Tag gesperrt", unblock:"Entsperren",
      blockSlot:"Zeitslot", blockDay:"Ganzer Tag", blockPeriod:"Zeitraum", blockHours:"Abwesenheit",
      blockSlotTitle:"Zeitslot zum Sperren wählen", blockDayTitle:"Ganzen Tag sperren", blockHoursTitle:"Abwesenheitsstunden sperren",
      blockPeriodTitle:"Zeitraum sperren (z.B. Urlaub)", blockDays:"Tage gesperrt",
      noBookings:"Keine Termine — + Neu tippen", holiday:"Freier Tag",
      searchClient:"Name oder Telefon suchen…", visits:"Besuch", totalSpent:"gesamt ausgegeben",
      barberNotes:"Friseur-Notizen", noNotes:"Keine Notizen — auf Bearbeiten klicken",
      edit:"Bearbeiten", cancel:"Abbrechen", upcoming:"Bevorstehende Termine", history:"Besuchshistorie",
      noHistory:"Keine Historie", favorite:"Favorit",
      confirmedRev:"✓ Bestätigter Umsatz", pendingPayment:"⚠ Ausstehend", scheduled:"Geplant",
      payConfirm:"Zahlung bestätigen", confirmReceipt:"✓ Eingang bestätigen von",
      printToday:"Tagesbericht", printMonth:"Monatsbericht",
      byMethod:"Nach Zahlungsmethode", byService:"Nach Leistung", last7:"Bestätigter Umsatz — 7 Tage",
      records:"Aufzeichnungen", total:"gesamt", services:"Leistungen",
      workDays:"Arbeitstage", startHour:"Beginn", endHour:"Ende", generatedSlots:"Generierte Slots",
      saveSchedule:"Arbeitszeiten speichern", barbershop:"Friseursalon", barberName:"Friseurname",
      address:"Adresse", bio:"Bio", newPin:"Neuer PIN", keepPin:"Leer lassen zum Beibehalten",
      logout:"Abmelden", chooseBarber:"1. Friseur wählen", chooseService:"2. Leistung wählen",
      chooseDate:"3. Datum wählen", yourData:"4. Ihre Daten", confirm:"Buchung bestätigen",
      bookingConfirmed:"Bestätigt!", newBookingBtn:"Neue Buchung", myBookings:"Meine Buchungen",
      myBookingsTitle:"Meine Buchungen", cancelBooking:"Stornieren",
      trialDays:"T Testphase", active:"✓ AKTIV", subscribeTitle:"Plan wählen",
      subscribeSubtitle:"Keine Bindung. Jederzeit kündbar.",
      trialStatus:"Teststatus", daysLeft:"Tage verbleibend", trialExpired:"Testphase abgelaufen",
      solo:"Solo", team:"Team", subscribeNow:"Jetzt abonnieren",
      expiredTitle:"Testphase abgelaufen", expiredSub:"Ihre Daten sind gespeichert.\nAbonnieren Sie, um fortzufahren.",
      seePlans:"Pläne ab 9,99€/Monat", readMore:"Mehr erfahren",
      markAllRead:"Als gelesen markieren", clearAllBtn:"Löschen", noNotifications:"Keine Benachrichtigungen",
      pendingOpen:"ausstehend",
      clientWord:"Kunde", bookedBadge:"GEBUCHT", lastVisitLabel:"Letzter",
      notePlaceholder:"Notizen zum Kunden (Vorlieben, Allergien usw.)…", saveNoteBtn:"Notiz Speichern",
      statVisitsLabel:"Besuche", statSpentLabel:"Ausgegeben", statNoShowsLabel:"Nichterscheinen", noShowWarning:"⚠ Schon {n}x unentschuldigt gefehlt", markNoShowBtn:"Nicht erschienen",
      noBookingCanBeMade:"An diesem Tag kann kein Kunde buchen.", fromDate:"Von", toDate:"Bis",
      noBookingsShort:"Keine Termine", blockedSlotLabel:"Blockierter Termin",
      all:"Alle", servicesUnconfirmed:"unbestätigte Zahlung", paidConfirmedCount:"bezahlt und bestätigt",
      unconfirmedCount:"unbestätigt", scheduledLabel:"Geplant", futureCount:"bevorstehend",
      paidAndConfirmed:"Bezahlt und Bestätigt", serviceDonePaymentPending:"Service Erledigt — Zahlung Ausstehend",
      scheduledCount:"Geplant", noRecordsPeriod:"Keine Einträge für diesen Zeitraum",
      role:"Funktion",
      paymentMethod:"Zahlungsmethode", confirmAmountBtn:"✓ Bestätigen",
      reportLabel:"Bericht", issuedOn:"Ausgestellt am", billed:"Abgerechnet", paidServices:"Bezahlte Leistungen",
      unconfirmedPayment:"Unbestätigte Zahlung", printBtn:"Drucken",
      adminOverview:"Übersicht", adminBarbersTab:"Barbiere", totalBilled:"Gesamtumsatz", barbersLabel:"Barbiere", todayAllLabel:"Heute (alle)", totalBookingsLabel:"Gesamte Buchungen", teamToday:"Team heute", bookingsTodayCount:"Buchungen heute", barbersCountSuffix:"Barbiere", addNew:"+ Neu", activeLabel:"Aktiv", offLabel:"Aus", editBarberTitle:"Barbier Bearbeiten", newBarberTitle:"Neuer Barbier", pinLabel:"PIN", colorLabel:"Farbe", adminPinLabel:"Admin-PIN", shopPhoto:"Foto des Salons", uploading:"Wird hochgeladen...", changePhoto:"Foto ändern", choosePhoto:"Foto wählen", dangerZone:"Gefahrenzone", deleteShopWarning:"Das Löschen des Salons entfernt alle Daten dauerhaft (Buchungen, Barbiere, Dienstleistungen). Diese Aktion kann nicht rückgängig gemacht werden.", deleteShopBtn:"Salon löschen", deleteShopConfirmPre:"Diese Aktion ist endgültig. Gib zur Bestätigung den genauen Namen des Salons ein (", deleteShopConfirmPost:") und dein Passwort.", shopNameLabel:"Name des Salons", passwordLabel:"Passwort", deleting:"Wird gelöscht...", deletePermanently:"Endgültig löschen",
      servicesCountSuffix:"Dienstleistungen", editServiceTitle:"Dienstleistung Bearbeiten", newServiceTitle:"Neue Dienstleistung", durationLabel:"Dauer (Min)", servicePriceLabel:"Preis (€)",
      trialExpiredShort:"Testphase abgelaufen", subscribeToContinue:"— abonniere, um fortzufahren", trialDaysRemaining:"{n} Tag(e) der Testphase verbleibend", tapSeePlans:"Tippen, um Pläne ab €{price}/Monat zu sehen", seeArrow:"ANSEHEN →",
      subscriptionLabel:"Abonnement", freeTrialOfDays:"{days} Tage kostenlose Testphase", dayWord:"Tag", availablePlans:"Verfügbare Pläne", soloDesc:"1 unabhängiger Barbier", perMonth:"/Monat", soloFeatures:["Vollständiger Kalender","Kunden und Verlauf","Buchhaltung","Berichte und Druck","Benachrichtigungen"], teamDesc:"Salon mit Mitarbeitern", perBarberMonth:"/Barbier/Monat", teamFeatures:["Alles aus Solo","Mehrere Barbiere","Admin-Panel","Mitarbeiterverwaltung","Statistiken pro Barbier"], popularBadge:"BELIEBT", teamCalcLabel:"Team-Rechner", activeBarbersCount:"{n} aktive(r) Barbier(e)", teamCalcFormula:"{n} × €{price} = €{total}/Monat", savingsVsSolo:"du sparst €{amount} vs. Solo einzeln", planWord:"Plan", monthlyRenewal:"Automatische monatliche Verlängerung", securePayment:"Sichere Zahlung · Jederzeit kündbar", demoNote:"Demo: klicken, um das Abonnement zu simulieren", faqTitle:"Häufige Fragen", faqItems:[["Kann ich kündigen?","Ja, jederzeit. Ohne Strafgebühren."],["Wie füge ich Mitarbeiter hinzu?","Im Admin-Panel erstellst du das Profil jedes Barbiers. Im Team-Plan zahlt jeder €7,99/Monat."],["Was passiert nach der Testphase?","Die App blockiert den Zugriff auf den Kalender, bis du abonnierst. Deine Daten bleiben gespeichert."],["Gibt es versteckte Kosten?","Nein. Der Preis ist pro Barbier und Monat fest."]],
      expiredFull:"Deine 15 kostenlosen Tage sind abgelaufen.\nDeine Daten sind gespeichert.\nAbonniere, um die App weiter zu nutzen.", noCommitmentFooter:"Unverbindlich · Jederzeit kündbar",
      photoTooLarge:"Das Bild ist zu groß (max. 5MB).", uploadFailed:"Das Bild konnte nicht hochgeladen werden.", changeProfilePhoto:"Profilfoto ändern",
      cutHistoryTitle:"Schnitt-Verlauf", addCutBtn:"+ Schnitt hinzufügen", tapCamera:"📷 Kamera öffnen", tapGallery:"🖼️ Datei hochladen",
      cutNotesPlaceholder:"Technische Notizen (z. B. Aufsatz Nr. 2 an den Seiten, Schere oben)", saveCutBtn:"Schnitt speichern", noCutsYet:"Du hast noch keine Schnitte für diesen Kunden erfasst.",
      deleteCutBtn:"Schnitt löschen",
      purchaseHistoryTitle:"Kaufverlauf", addPurchaseBtn:"+ Kauf hinzufügen", purchaseTextPlaceholder:"Produktbeschreibung (z.B. Matte Pomade)", savePurchaseBtn:"Kauf speichern", noPurchasesYet:"Für diesen Kunden wurden noch keine Käufe erfasst.", deletePurchaseBtn:"Kauf löschen", purchaseRecordTitle:"Kauf", addPurchaseErr:"Schreibe eine Beschreibung oder füge ein Foto hinzu.",
      cutRecordTitle:"Schnitt", addCutPhotoErr:"Füge ein Foto des Schnitts hinzu.", addClientBtn:"+ Kunde hinzufügen", nameRequiredErr:"Der Name ist erforderlich.",
      navHome:"Start", navAgenda:"Kalender", navAlerts:"Hinweise", navClients:"Kunden", navReports:"Umsatz", navSchedule:"Zeitplan", navProfile:"Profil", navShop:"Salon", todaySuffix:"heute", activeSubBadge:"AKTIV",
      blockedDayName:"Gesperrter Tag", blockedPeriodName:"Gesperrter Zeitraum", breakStartLabel:"Pausenbeginn", breakEndLabel:"Pausenende", noBreakOption:"Keine Pause", deleteClientBtn:"Kunde löschen", deleteClientWarning:"Dadurch werden Verlauf, Notizen und erfasste Schnitte für {name} dauerhaft entfernt. Diese Aktion kann nicht rückgängig gemacht werden.",
      notifTodayTitle:"Heutige Termine", notifTodayBody:"Du hast heute {n} Termine. Der erste um 09:00.",
      notifCancelTitleDemo:"Termin storniert", notifCancelBodyDemo:"João Costa hat den heutigen 14:00-Termin storniert.",
      notifNewDemoTitle:"Neuer Termin", notifNewDemoBody:"Miguel Ferreira hat einen Klassischen Schnitt für morgen um 10:00 gebucht.",
      notifGoodMorning:"Guten Morgen, {name}!", notifTodaySummary:"Du hast heute {n} Termin(e). Der erste um {time} Uhr.",
      notifNewBookingTitle:"Neuer Termin hinzugefügt", notifBookingDeletedTitle:"Termin gelöscht", notifBookingDeletedBody:"{name} — {date} um {time} Uhr wurde entfernt.",
      notifCancelTitle:"Termin storniert", notifCancelBody:"{name} hat storniert — {date} um {time} Uhr.",
      notifSubActivatedTitle:"Abonnement aktiviert", notifSubActivatedBody:"Plan {plan} aktiv. Danke, {owner}!", absenceName:"Abwesenheit", yesterdaySummaryTitle:"Zusammenfassung von gestern", yesterdaySummaryBody:"Du hast {n} Leistungen abgeschlossen. Umsatz: €{amount}.",
      portalTitle:"Inhaber-Portal", portalSubtitle:"Melde dich an oder erstelle deinen Salon", haveAccountTab:"Ich habe schon ein Konto", createShopTab:"Salon erstellen",
      emailLabel:"E-Mail", placeholderEmail:"deine-email@beispiel.com", placeholderPass:"••••••••", loginBtn:"Anmelden", loggingIn:"Anmeldung...",
      yourNameLabel:"Dein Name", placeholderFullName:"Vollständiger Name", placeholderShopName:"Z. B.: Salon Müller", phoneOptionalLabel:"Telefon (optional)",
      placeholderPhone:"+49 1xx xxxxxxx", placeholderCreatePass:"Erstelle ein Passwort", createShopBtn:"Meinen Salon erstellen", creatingBtn:"Wird erstellt...",
      fillEmailPass:"Fülle E-Mail und Passwort aus.", fillAllFields:"Fülle alle Felder aus.", shopAlreadyExists:"Ein Salon mit dieser E-Mail ist bereits registriert.",
      wrongCredentials:"Falsche E-Mail oder Passwort.", lastOwnerErr:"Der einzige Inhaber des Salons kann nicht gelöscht werden. Mache zuerst ein anderes Teammitglied zum Inhaber, oder bearbeite dieses Profil, statt es zu löschen.", createShopFailed:"Der Salon konnte nicht erstellt werden. Versuche es erneut.",
      loadingText:"WIRD GELADEN...", shopNotFoundTitle:"Salon nicht gefunden", shopNotFoundBody:"Der verwendete Link entspricht keinem registrierten Salon.", goToOwnerPortal:"Zum Inhaber-Portal",
      chatBtn:"💬 Nachrichten", chatTitle:"Chat", chatEmpty:"Noch keine Nachrichten. Sag Hallo!", chatPlaceholder:"Nachricht schreiben…",
      chatWithBarberCta:"💬 Mit dem Barbier schreiben", chatPickBarber:"Wähle, mit wem du sprichst", chatNoBarbers:"Du hast noch keine Termine bei einem Barbier.",
      notifNewMsgTitle:"Neue Nachricht", notifNewMsgBody:"{name} hat dir eine Nachricht geschickt.",
      ordersTabLabel:"Bestellungen", ordersAddPlaceholder:"z.B. Shampoo, Klingen...", ordersAddBtn:"Hinzufügen", ordersEmpty:"Keine Produkte in der Liste.", ordersPhotoAttached:"Foto angehängt",
      catalogTabLabel:"Katalog", catalogNamePlaceholder:"Produktname", catalogPricePlaceholder:"Preis", catalogAddBtn:"Produkt hinzufügen", catalogEmpty:"Noch keine Produkte im Katalog.", catalogUnavailable:"Nicht verfügbar", catalogMarkAvailable:"Als verfügbar markieren", catalogMarkUnavailable:"Als nicht verfügbar markieren", catalogClientCta:"Produkte ansehen",
      joinAsNew:"Ich bin neuer Mitarbeiter, ich möchte beitreten →", yourNameShort:"Dein Name", fullNamePlaceholder:"Vollständiger Name", createAccessCode:"Erstelle deinen Zugangscode (4-6 Ziffern)",
      phoneOptional:"Telefon (optional)", joinTeamBtn:"Dem Team beitreten", alreadyHaveCode:"← Ich habe bereits einen Zugangscode",
      writeYourName:"Gib deinen Namen ein.", codeLength:"Der Code muss 4 bis 6 Ziffern haben.", codeInUse:"Dieser Code wird bereits verwendet. Wähle einen anderen.",
    }
  },
};

// Código ISO do país de cada bandeira (para imagem real, em vez de emoji — o Windows não renderiza bem emojis de bandeira)
const FLAG_CC = { pt:"pt", en:"gb", es:"es", fr:"fr", de:"de" };

// ─── CONSTANTS ───────────────────────────────────────────────────────────────
const ALL_HOURS = ["06:00","06:30","07:00","07:30","08:00","08:30","09:00","09:30","10:00","10:30","11:00","11:30","12:00","12:30",
                   "13:00","13:30","14:00","14:30","15:00","15:30","16:00","16:30","17:00","17:30","18:00","18:30","19:00",
                   "19:30","20:00","20:30","21:00","21:30","22:00","22:30","23:00","23:30"];
const MONTHS  = ["Janeiro","Fevereiro","Março","Abril","Maio","Junho","Julho","Agosto","Setembro","Outubro","Novembro","Dezembro"];
const WDAYS   = ["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"];
const WDAYS_F = ["Domingo","Segunda","Terça","Quarta","Quinta","Sexta","Sábado"];
const PAY     = ["Dinheiro","MB Way","Multibanco","Transferência","Outro"];

const mkId  = () => Math.random().toString(36).slice(2,9);

// Reduz o tamanho/qualidade de uma foto (tirada pela câmara, normalmente
// muito grande) antes de a enviar — evita fotos de vários MB que depois
// deixam a app lenta/"a tremer" ao carregar galerias com muitas fotos
// acumuladas (histórico de cortes, compras, etc.). Se algo correr mal,
// devolve o ficheiro original sem alterações, para nunca bloquear o envio.
async function resizeImageFile(file,maxDim=1280,quality=0.8){
  try{
    if(!file||!file.type?.startsWith("image/"))return file;
    const bitmap=await new Promise((resolve,reject)=>{
      const img=new Image();
      const url=URL.createObjectURL(file);
      img.onload=()=>{URL.revokeObjectURL(url);resolve(img);};
      img.onerror=e=>{URL.revokeObjectURL(url);reject(e);};
      img.src=url;
    });
    let{width,height}=bitmap;
    if(width>maxDim||height>maxDim){
      if(width>height){height=Math.round(height*maxDim/width);width=maxDim;}
      else{width=Math.round(width*maxDim/height);height=maxDim;}
    }
    const canvas=document.createElement("canvas");
    canvas.width=width;canvas.height=height;
    canvas.getContext("2d").drawImage(bitmap,0,0,width,height);
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,"image/jpeg",quality));
    if(!blob)return file;
    return new File([blob],(file.name||"foto").replace(/\.\w+$/,"")+".jpg",{type:"image/jpeg"});
  }catch{
    return file;
  }
}

const normName=s=>(s||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().trim();
const ensureOwner=list=>{
  if(!list||list.length===0)return list;
  if(list.some(b=>b.isOwner))return list;
  const idx=list.findIndex(b=>normName(b.name)==="luis correia");
  const ownerIdx=idx>=0?idx:0;
  return list.map((b,i)=>i===ownerIdx?{...b,isOwner:true}:b);
};
const fmt   = d  => d.toISOString().split("T")[0];
const TODAY = fmt(new Date());
const NOW   = new Date();

function dateLabel(str,lang='pt') {
  if(!str)return LANGS[lang].t.noHistory;
  const d=new Date(str+"T12:00:00"), diff=Math.round((d-new Date(TODAY+"T12:00:00"))/86400000);
  const L=LANGS[lang].t;
  if(diff===0)return L.today; if(diff===1)return L.tomorrow; if(diff===-1)return L.yesterday;
  return `${d.getDate()} ${LANGS[lang].months[d.getMonth()].slice(0,3)}`;
}
function timeAgo(ts) {
  const diff=Math.round((Date.now()-ts)/60000);
  if(diff<1)return"agora"; if(diff<60)return`${diff}m`; if(diff<1440)return`${Math.round(diff/60)}h`;
  return`${Math.round(diff/1440)}d`;
}

// ─── SEED ────────────────────────────────────────────────────────────────────
const INIT_SERVICES = [
  {id:"s1",name:"Corte Clássico",    duration:30,price:15,active:true,
    names:{pt:"Corte Clássico",en:"Classic Cut",es:"Corte Clásico",fr:"Coupe Classique",de:"Klassischer Schnitt"}},
  {id:"s2",name:"Corte + Barba",     duration:50,price:25,active:true,
    names:{pt:"Corte + Barba",en:"Cut + Beard",es:"Corte + Barba",fr:"Coupe + Barbe",de:"Schnitt + Bart"}},
  {id:"s3",name:"Barba Completa",    duration:25,price:12,active:true,
    names:{pt:"Barba Completa",en:"Full Beard",es:"Barba Completa",fr:"Barbe Complète",de:"Komplette Bartpflege"}},
  {id:"s4",name:"Degradê",           duration:40,price:18,active:true,
    names:{pt:"Degradê",en:"Fade",es:"Degradado",fr:"Dégradé",de:"Fade Cut"}},
  {id:"s5",name:"Tratamento Capilar",duration:45,price:22,active:true,
    names:{pt:"Tratamento Capilar",en:"Hair Treatment",es:"Tratamiento Capilar",fr:"Soin Capillaire",de:"Haarbehandlung"}},
];
const INIT_BARBERS = [
  {id:"b1",name:"Luis Correia",role:"Barbeiro Sênior",pin:"1984",phone:"+351 912 345 678",bio:"Especialista em cortes clássicos e barba.",avatar:"LC",color:"#b8955a",schedule:{workDays:[1,2,3,4,5],startHour:"09:00",endHour:"18:00",breakStart:"12:00",breakEnd:"13:00"},active:true},
  {id:"b2",name:"André Silva",role:"Barbeiro",pin:"2000",phone:"+351 913 000 111",bio:"Especialista em degradê e cortes modernos.",avatar:"AS",color:"#6a9eb8",schedule:{workDays:[2,3,4,5,6],startHour:"10:00",endHour:"19:00",breakStart:"13:00",breakEnd:"14:00"},active:true},
  {id:"b3",name:"Rui Mendes",role:"Barbeiro Junior",pin:"1111",phone:"+351 914 111 222",bio:"Cortes rápidos e modernos.",avatar:"RM",color:"#9e6a4a",schedule:{workDays:[1,3,5,6],startHour:"09:00",endHour:"17:00",breakStart:"",breakEnd:""},active:true},
];
const INIT_SHOP = {name:"LC.84 Barber Vision",address:"Rua do Comércio, 84 — Lisboa",phone:"+351 912 345 678",bio:"Barbearia de luxo com mais de 10 anos de experiência.",adminPin:"admin"};

// seed client notes
const INIT_CLIENT_NOTES = {};

// ─── MULTI-SHOP HELPERS ──────────────────────────────────────────────────────
function slugify(str){
  return (str||"")
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g,"") // remove accents
    .replace(/[^a-z0-9]+/g,"-")
    .replace(/(^-|-$)/g,"")
    .slice(0,30) || "loja";
}
async function generateUniqueSlug(base){
  let slug = slugify(base);
  let attempt = slug;
  let n = 2;
  while(true){
    const {data} = await supabase.from("shops").select("id").eq("slug",attempt).maybeSingle();
    if(!data) return attempt;
    attempt = `${slug}-${n}`;
    n++;
  }
}

function seedBookings(barbers) {
  const names  = ["Miguel Ferreira","João Costa","Rafael Santos","André Pinto","Carlos Mendes","Bruno Sousa","Tiago Lopes","Pedro Nunes","Rui Alves","Diogo Vieira","Marco Silva","Nuno Rodrigues"];
  const phones = ["912111001","913222002","914333003","915444004","916555005","917666006","918777007","919888008","910999009","911000010","912000011","913000012"];
  const days   = [fmt(new Date(Date.now()-2*86400000)),fmt(new Date(Date.now()-86400000)),TODAY,fmt(new Date(Date.now()+86400000)),fmt(new Date(Date.now()+2*86400000))];
  const slots  = [["09:00","s1"],["10:00","s2"],["11:00","s4"],["14:00","s3"],["15:30","s2"],["16:30","s1"]];
  const out = [];
  barbers.forEach((barber,bi)=>{
    days.forEach((date,di)=>{
      slots.slice(0,2+Math.min(di,3)).forEach(([time,sid],i)=>{
        const isPast=date<TODAY;
        out.push({id:mkId(),barberId:barber.id,date,time,serviceId:sid,
          name:names[(bi*20+di*5+i)%names.length],phone:phones[(bi*20+di*5+i)%phones.length],
          status:isPast?"concluído":di===2&&i===0?"concluído":"confirmado",
          paid:isPast,payMethod:isPast?"Dinheiro":"",notes:"",blocked:false});
      });
    });
  });
  return out;
}

function seedNotifications(barbers, lang="pt") {
  const L=LANGS[lang].t;
  const now = Date.now();
  const out = [];
  barbers.forEach(b=>{
    const n=3+Math.floor(Math.random()*3);
    out.push({id:mkId(),barberId:b.id,type:"reminder",title:L.notifTodayTitle,body:L.notifTodayBody.replace("{n}",n),ts:now-5*60000,read:false});
    out.push({id:mkId(),barberId:b.id,type:"new",title:L.notifNewDemoTitle,body:L.notifNewDemoBody,ts:now-32*60000,read:false});
    out.push({id:mkId(),barberId:b.id,type:"cancel",title:L.notifCancelTitleDemo,body:L.notifCancelBodyDemo,ts:now-2*3600000,read:true});
    out.push({id:mkId(),barberId:b.id,type:"reminder",title:L.yesterdaySummaryTitle,body:L.yesterdaySummaryBody.replace("{n}",4).replace("{amount}",72),ts:now-26*3600000,read:true});
  });
  return out;
}

// ─── PRIMITIVES ──────────────────────────────────────────────────────────────
const Lbl = ({children,style}) => <div style={{fontSize:"0.57rem",letterSpacing:"0.25em",color:T.silver,textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",marginBottom:6,...style}}>{children}</div>;
const Inp = ({style,...p}) => <input {...p} style={{width:"100%",background:T.card,border:`1px solid ${T.border}`,borderRadius:4,padding:"10px 12px",color:T.white,fontSize:"0.95rem",outline:"none",...style}} onFocus={e=>e.target.style.borderColor=T.gold} onBlur={e=>e.target.style.borderColor=T.border}/>;
const Sel = ({style,children,...p}) => <select {...p} style={{width:"100%",background:T.card,border:`1px solid ${T.border}`,borderRadius:4,padding:"10px 12px",color:T.white,fontSize:"0.95rem",outline:"none",colorScheme:"dark",...style}}>{children}</select>;
const Txta = ({style,...p}) => <textarea {...p} style={{width:"100%",background:T.card,border:`1px solid ${T.border}`,borderRadius:4,padding:"10px 12px",color:T.white,fontSize:"0.9rem",outline:"none",resize:"none",...style}} onFocus={e=>e.target.style.borderColor=T.gold} onBlur={e=>e.target.style.borderColor=T.border}/>;
const Btn = ({children,variant="gold",style,...p}) => {
  const V={gold:{background:T.gold,color:"#000",border:`1px solid ${T.gold}`},ghost:{background:"transparent",color:T.mid,border:`1px solid ${T.border}`},danger:{background:T.redLo,color:T.red,border:`1px solid ${T.red}`},success:{background:T.greenLo,color:T.green,border:`1px solid ${T.green}`},blue:{background:T.blueLo,color:T.blue,border:`1px solid ${T.blue}`}};
  return <button className="tap" {...p} style={{padding:"11px 18px",borderRadius:4,cursor:"pointer",fontSize:"0.68rem",letterSpacing:"0.2em",textTransform:"uppercase",fontWeight:700,fontFamily:"'Josefin Sans',sans-serif",...V[variant],...style}}>{children}</button>;
};
const Tag = ({status}) => {
  const C={confirmado:{bg:T.goldLo,c:T.gold,l:"Confirmado"},concluído:{bg:T.greenLo,c:T.green,l:"Concluído"},cancelado:{bg:T.redLo,c:T.red,l:"Cancelado"},falta:{bg:T.orangeLo,c:T.orange,l:"Falta"},bloqueado:{bg:T.muted,c:T.silver,l:"Bloqueado"}};
  const cfg=C[status]||C.confirmado;
  return <span style={{fontSize:"0.55rem",letterSpacing:"0.12em",textTransform:"uppercase",padding:"2px 7px",borderRadius:3,background:cfg.bg,color:cfg.c,border:`1px solid ${cfg.c}`,fontFamily:"'Josefin Sans',sans-serif",whiteSpace:"nowrap"}}>{cfg.l}</span>;
};
const Hr = ({style}) => <div style={{height:1,background:T.border,...style}}/>;
const Avatar = ({barber,size=36}) => barber.photoUrl ? <img src={barber.photoUrl} style={{width:size,height:size,borderRadius:"50%",objectFit:"cover",border:`2px solid ${barber.color}`,flexShrink:0}}/> : <div style={{width:size,height:size,borderRadius:"50%",background:`${barber.color}22`,border:`2px solid ${barber.color}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:size*0.32,fontWeight:700,color:barber.color,flexShrink:0,fontFamily:"'Josefin Sans',sans-serif"}}>{barber.avatar}</div>;

function Modal({onClose,title,children}){
  return(
    <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.82)",display:"flex",alignItems:"flex-end",justifyContent:"center",zIndex:300}}>
      <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:520,background:T.surface,borderRadius:"14px 14px 0 0",border:`1px solid ${T.border}`,borderBottom:"none",padding:"20px 20px 48px",maxHeight:"90vh",overflowY:"auto"}}>
        <div style={{width:36,height:3,background:T.muted,borderRadius:2,margin:"0 auto 18px"}}/>
        {title&&<div style={{fontSize:"1.2rem",color:T.white,fontWeight:600,marginBottom:18}}>{title}</div>}
        {children}
      </div>
    </div>
  );
}

// ─── CHAT (cliente ↔ barbeiro, tempo real via Supabase Realtime) ──────────────
function useChatThread(shopId,barberId,clientKey,sender){
  const [messages,setMessages]=useState([]);
  const [loading,setLoading]=useState(true);
  useEffect(()=>{
    if(!shopId||!barberId||!clientKey)return;
    let active=true;
    setLoading(true);
    (async()=>{
      const{data}=await supabase.from("messages").select("*")
        .eq("shop_id",shopId).eq("barber_id",barberId).eq("client_key",clientKey)
        .order("created_at",{ascending:true});
      if(active){setMessages(data||[]);setLoading(false);}
    })();
    const ch=supabase.channel(`chat-${shopId}-${barberId}-${clientKey}`)
      .on("postgres_changes",{event:"INSERT",schema:"public",table:"messages",filter:`shop_id=eq.${shopId}`},payload=>{
        const m=payload.new;
        if(m.barber_id!==barberId||m.client_key!==clientKey)return;
        setMessages(p=>p.find(x=>x.id===m.id)?p:[...p,m]);
      })
      .subscribe();
    return()=>{active=false;supabase.removeChannel(ch);};
  },[shopId,barberId,clientKey]);
  const send=async(text)=>{
    const clean=text.trim();
    if(!clean)return;
    const{data,error}=await supabase.from("messages").insert({shop_id:shopId,barber_id:barberId,client_key:clientKey,sender,text:clean}).select().single();
    if(!error&&data)setMessages(p=>p.find(x=>x.id===data.id)?p:[...p,data]);
  };
  const markRead=async()=>{
    const field=sender==="barber"?"read_barber":"read_client";
    const other=sender==="barber"?"client":"barber";
    await supabase.from("messages").update({[field]:true})
      .eq("shop_id",shopId).eq("barber_id",barberId).eq("client_key",clientKey).eq("sender",other).eq(field,false);
  };
  return{messages,loading,send,markRead};
}

function useBarberUnreadMap(shopId,barberId){
  const [map,setMap]=useState({});
  useEffect(()=>{
    if(!shopId||!barberId)return;
    let active=true;
    const load=async()=>{
      const{data}=await supabase.from("messages").select("client_key")
        .eq("shop_id",shopId).eq("barber_id",barberId).eq("sender","client").eq("read_barber",false);
      if(!active)return;
      const m={};(data||[]).forEach(r=>{m[r.client_key]=(m[r.client_key]||0)+1;});
      setMap(m);
    };
    load();
    const ch=supabase.channel(`unread-b-${shopId}-${barberId}`)
      .on("postgres_changes",{event:"*",schema:"public",table:"messages",filter:`shop_id=eq.${shopId}`},load)
      .subscribe();
    return()=>{active=false;supabase.removeChannel(ch);};
  },[shopId,barberId]);
  return map;
}

function useClientUnreadMap(shopId,clientKey){
  const [map,setMap]=useState({});
  useEffect(()=>{
    if(!shopId||!clientKey)return;
    let active=true;
    const load=async()=>{
      const{data}=await supabase.from("messages").select("barber_id")
        .eq("shop_id",shopId).eq("client_key",clientKey).eq("sender","barber").eq("read_client",false);
      if(!active)return;
      const m={};(data||[]).forEach(r=>{m[r.barber_id]=(m[r.barber_id]||0)+1;});
      setMap(m);
    };
    load();
    const ch=supabase.channel(`unread-c-${shopId}-${clientKey}`)
      .on("postgres_changes",{event:"*",schema:"public",table:"messages",filter:`shop_id=eq.${shopId}`},load)
      .subscribe();
    return()=>{active=false;supabase.removeChannel(ch);};
  },[shopId,clientKey]);
  return map;
}

function ChatThread({shopId,barberId,clientKey,sender,lang,onSent}){
  const L=LANGS[lang].t;
  const{messages,loading,send,markRead}=useChatThread(shopId,barberId,clientKey,sender);
  const [text,setText]=useState("");
  const endRef=useRef(null);
  useEffect(()=>{endRef.current?.scrollIntoView({block:"end"});},[messages.length]);
  useEffect(()=>{if(messages.length)markRead();},[messages.length]);
  const onSend=()=>{
    const clean=text.trim();
    if(!clean)return;
    send(clean);
    setText("");
    onSent&&onSent(clean);
  };
  return(
    <div style={{display:"flex",flexDirection:"column",height:"55vh",minHeight:320}}>
      <div style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:7,padding:"2px 2px 8px"}}>
        {loading?(
          <div style={{color:T.silver,fontSize:"0.78rem",textAlign:"center",padding:"24px 0"}}>{L.loadingText}</div>
        ):messages.length===0?(
          <div style={{color:T.silver,fontSize:"0.78rem",textAlign:"center",padding:"24px 0"}}>{L.chatEmpty}</div>
        ):messages.map(m=>{
          const mine=m.sender===sender;
          return(
            <div key={m.id} style={{alignSelf:mine?"flex-end":"flex-start",maxWidth:"78%",background:mine?T.goldLo:T.card,border:`1px solid ${mine?T.gold:T.border}`,borderRadius:mine?"11px 11px 2px 11px":"11px 11px 11px 2px",padding:"8px 11px"}}>
              <div style={{fontSize:"0.85rem",color:T.white,whiteSpace:"pre-wrap",wordBreak:"break-word",lineHeight:1.4}}>{m.text}</div>
              <div style={{fontSize:"0.55rem",color:T.silver,marginTop:4,textAlign:"right"}}>{new Date(m.created_at).toLocaleTimeString(lang==="pt"?"pt-PT":"en-GB",{hour:"2-digit",minute:"2-digit"})}</div>
            </div>
          );
        })}
        <div ref={endRef}/>
      </div>
      <div style={{display:"flex",gap:7,paddingTop:9,borderTop:`1px solid ${T.border}`}}>
        <Inp value={text} onChange={e=>setText(e.target.value)} placeholder={L.chatPlaceholder} onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();onSend();}}} style={{flex:1}}/>
        <Btn variant="gold" style={{padding:"9px 15px"}} onClick={onSend}>➤</Btn>
      </div>
    </div>
  );
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function getBarberHours(barber){
  const{startHour,endHour,breakStart,breakEnd}=barber.schedule;
  return ALL_HOURS.filter(h=>{
    if(h<startHour||h>=endHour)return false;
    if(breakStart&&breakEnd&&h>=breakStart&&h<breakEnd)return false;
    return true;
  });
}
// Converte "HH:MM" em minutos desde a meia-noite, para comparar durações.
function timeToMin(t){const[h,m]=String(t).split(":").map(Number);return h*60+(m||0);}
// Verifica se dois intervalos [inicio, inicio+duração) se sobrepõem —
// usado para detetar conflitos de marcação tendo em conta a duração
// real de cada serviço (que pode ser editada pelo barbeiro).
function slotsOverlap(startA,durA,startB,durB){
  const sA=timeToMin(startA),eA=sA+(durA||30);
  const sB=timeToMin(startB),eB=sB+(durB||30);
  return sA<eB&&sB<eA;
}
const SERVICE_NAME_TRANSLATIONS = {
  "Corte Clássico":    {pt:"Corte Clássico",en:"Classic Cut",es:"Corte Clásico",fr:"Coupe Classique",de:"Klassischer Schnitt"},
  "Corte + Barba":     {pt:"Corte + Barba",en:"Cut + Beard",es:"Corte + Barba",fr:"Coupe + Barbe",de:"Schnitt + Bart"},
  "Barba Completa":    {pt:"Barba Completa",en:"Full Beard",es:"Barba Completa",fr:"Barbe Complète",de:"Komplette Bartpflege"},
  "Degradê":           {pt:"Degradê",en:"Fade",es:"Degradado",fr:"Dégradé",de:"Fade Cut"},
  "Tratamento Capilar":{pt:"Tratamento Capilar",en:"Hair Treatment",es:"Tratamiento Capilar",fr:"Soin Capillaire",de:"Haarbehandlung"},
};
function svcName(s,lang){
  if(!s)return"";
  if(s.names?.[lang])return s.names[lang];
  const fallback=SERVICE_NAME_TRANSLATIONS[s.name];
  if(fallback?.[lang])return fallback[lang];
  return s.name||"";
}
function barberWorksOnDate(barber,dateStr){return barber.schedule.workDays.includes(new Date(dateStr+"T12:00:00").getDay());}

// ─── BOOKING FORM ─────────────────────────────────────────────────────────────
function BookingForm({initial,services,barbers,bookings,onSave,onDelete,onClose,fixedBarberId,lang}){
  const L=LANGS[lang].t;
  const [f,setF]=useState(initial);
  const u=k=>v=>setF(p=>({...p,[k]:v}));
  const ok=f.name.trim()&&f.time&&f.date;
  const hrs=f.barberId?getBarberHours(barbers.find(b=>b.id===f.barberId)||barbers[0]):ALL_HOURS;
  const statusLabel={confirmado:L.confirmed,concluído:L.done,cancelado:L.cancelled,falta:L.noShow};
  const noShowCount=useMemo(()=>{
    if(!bookings||!(f.phone||f.name))return 0;
    return bookings.filter(b=>b.status==="falta"&&(f.phone?b.phone===f.phone:b.name===f.name)).length;
  },[bookings,f.phone,f.name]);
  // Aviso (não bloqueio) de sobreposição com outra marcação do mesmo barbeiro,
  // tendo em conta a duração real de cada serviço — o barbeiro pode decidir
  // avançar mesmo assim (ex: encaixe manual de um cliente).
  const conflictBooking=useMemo(()=>{
    if(!f.date||!f.time||!f.barberId)return null;
    const thisDur=services.find(s=>s.id===f.serviceId)?.duration||30;
    return (bookings||[]).find(b=>b.id!==f.id&&b.barberId===f.barberId&&b.date===f.date&&!b.blocked&&b.status!=="cancelado"&&slotsOverlap(f.time,thisDur,b.time,services.find(s=>s.id===b.serviceId)?.duration||30));
  },[bookings,f.date,f.time,f.barberId,f.serviceId,f.id,services]);
  return(
    <>
      {noShowCount>0&&<div style={{background:T.orangeLo,border:`1px solid ${T.orange}`,borderRadius:6,padding:"9px 12px",marginBottom:14,color:T.orange,fontSize:"0.74rem"}}>{L.noShowWarning.replace("{n}",noShowCount)}</div>}
      {conflictBooking&&<div style={{background:T.orangeLo,border:`1px solid ${T.orange}`,borderRadius:6,padding:"9px 12px",marginBottom:14,color:T.orange,fontSize:"0.74rem"}}>⚠ Sobrepõe-se à marcação de {conflictBooking.name} às {conflictBooking.time}.</div>}
      <div style={{display:"flex",gap:6,marginBottom:16}}>
        {["confirmado","concluído","cancelado","falta"].map(st=>(
          <button key={st} onClick={()=>u("status")(st)} style={{flex:1,padding:"7px 4px",borderRadius:4,cursor:"pointer",fontSize:"0.58rem",letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",background:f.status===st?(st==="concluído"?T.greenLo:st==="cancelado"?T.redLo:st==="falta"?T.orangeLo:T.goldLo):"transparent",color:f.status===st?(st==="concluído"?T.green:st==="cancelado"?T.red:st==="falta"?T.orange:T.gold):T.silver,border:`1px solid ${f.status===st?(st==="concluído"?T.green:st==="cancelado"?T.red:st==="falta"?T.orange:T.gold):T.border}`}}>{statusLabel[st]}</button>
        ))}
      </div>
      {!fixedBarberId&&<div style={{marginBottom:11}}><Lbl>{L.barberLabel}</Lbl><Sel value={f.barberId} onChange={e=>u("barberId")(e.target.value)}>{barbers.filter(b=>b.active).map(b=><option key={b.id} value={b.id}>{b.name}</option>)}</Sel></div>}
      <div style={{marginBottom:11}}><Lbl>{L.clientName}</Lbl><Inp placeholder={L.fullName} value={f.name} onChange={e=>u("name")(e.target.value)}/></div>
      <div style={{marginBottom:11}}><Lbl>{L.phone}</Lbl><Inp placeholder="+351 9XX XXX XXX" value={f.phone} onChange={e=>u("phone")(e.target.value)}/></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:11}}>
        <div><Lbl>{L.date}</Lbl><Inp type="date" value={f.date} onChange={e=>u("date")(e.target.value)}/></div>
        <div><Lbl>{L.time}</Lbl><Sel value={f.time} onChange={e=>u("time")(e.target.value)}><option value="">— {L.time} —</option>{hrs.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
      </div>
      <div style={{marginBottom:11}}><Lbl>{L.service}</Lbl><Sel value={f.serviceId} onChange={e=>u("serviceId")(e.target.value)}>{services.filter(s=>s.active).map(s=><option key={s.id} value={s.id}>{svcName(s,lang)} — €{s.price} ({s.duration}min)</option>)}</Sel></div>
      <div style={{marginBottom:14}}>
        <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:6}}>
          <label style={{display:"flex",alignItems:"center",gap:6,cursor:"pointer",fontSize:"0.85rem",color:f.paid?T.green:T.mid}}><input type="checkbox" checked={f.paid} onChange={e=>u("paid")(e.target.checked)} style={{accentColor:T.green}}/> {L.payment}</label>
          {f.paid&&<Sel value={f.payMethod} onChange={e=>u("payMethod")(e.target.value)} style={{flex:1,padding:"6px 10px",fontSize:"0.82rem"}}><option value="">{L.payMethod}</option>{LANGS[lang].pay.map(p=><option key={p} value={p}>{p}</option>)}</Sel>}
        </div>
      </div>
      <div style={{marginBottom:16}}><Lbl>{L.notes}</Lbl><Txta rows={2} placeholder={L.observations} value={f.notes} onChange={e=>u("notes")(e.target.value)}/></div>
      <div style={{display:"flex",gap:8}}>
        <Btn variant="gold" style={{flex:1}} onClick={()=>ok&&onSave(f)}>{L.save}</Btn>
        {onDelete&&<Btn variant="danger" onClick={onDelete}>{L.delete}</Btn>}
        <Btn variant="ghost" onClick={onClose}>{L.close}</Btn>
      </div>
    </>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// 🔔 NOTIFICATIONS SCREEN
// ══════════════════════════════════════════════════════════════════════════════
function BNotifications({notifications,setNotifications,barber,lang,onOpenLink}){
  const L=LANGS[lang].t;
  const myNotifs=notifications.filter(n=>n.barberId===barber.id).sort((a,b)=>b.ts-a.ts);
  const unread=myNotifs.filter(n=>!n.read).length;

  const markAll=()=>setNotifications(p=>p.map(n=>n.barberId===barber.id?{...n,read:true}:n));
  const markOne=id=>setNotifications(p=>p.map(n=>n.id===id?{...n,read:true}:n));
  const delOne=id=>setNotifications(p=>p.filter(n=>n.id!==id));
  const clearAll=()=>setNotifications(p=>p.filter(n=>n.barberId!==barber.id));

  const typeIcon={reminder:"🔔",new:"✂",cancel:"✕",info:"ℹ",message:"💬"};
  const typeColor={reminder:T.gold,new:T.green,cancel:T.red,info:T.blue,message:T.blue};

  return(
    <div style={{padding:"0 20px"}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
        <div>
          <span style={{fontSize:"1.1rem",color:T.white,fontWeight:600}}>{L.notifications}</span>
          {unread>0&&<span style={{marginLeft:8,background:T.red,color:"#fff",borderRadius:10,padding:"1px 7px",fontSize:"0.62rem",fontFamily:"'Josefin Sans',sans-serif"}}>{unread}</span>}
        </div>
        <div style={{display:"flex",gap:6}}>
          {unread>0&&<Btn variant="ghost" style={{padding:"5px 10px",fontSize:"0.58rem"}} onClick={markAll}>{L.markAllRead}</Btn>}
          {myNotifs.length>0&&<Btn variant="danger" style={{padding:"5px 10px",fontSize:"0.58rem"}} onClick={clearAll}>{L.clearAllBtn}</Btn>}
        </div>
      </div>

      {myNotifs.length===0?(
        <div style={{textAlign:"center",padding:"50px 0",color:T.silver}}>
          <div style={{fontSize:"2rem",opacity:.2,marginBottom:8}}>🔔</div>
          {L.noNotifications}
        </div>
      ):myNotifs.map(n=>(
        <div key={n.id} className="row-h" onClick={()=>{markOne(n.id);if(n.link)onOpenLink?.(n.link);}} style={{display:"flex",gap:12,padding:"13px 14px",marginBottom:7,background:n.read?T.card:`${typeColor[n.type]}0a`,border:`1px solid ${n.read?T.border:typeColor[n.type]+"44"}`,borderRadius:7,cursor:"pointer",position:"relative"}}>
          {!n.read&&<div style={{position:"absolute",top:12,right:12,width:7,height:7,borderRadius:"50%",background:typeColor[n.type]}}/>}
          <div style={{fontSize:"1.1rem",flexShrink:0,marginTop:2}}>{typeIcon[n.type]||"🔔"}</div>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:"0.9rem",color:n.read?T.light:T.white,fontWeight:n.read?400:600,marginBottom:3}}>{n.title}</div>
            <div style={{fontSize:"0.78rem",color:T.silver,lineHeight:1.5}}>{n.body}</div>
            <div style={{fontSize:"0.62rem",color:T.silver,marginTop:5,fontFamily:"'Josefin Sans',sans-serif"}}>{timeAgo(n.ts)}</div>
          </div>
          <button onClick={e=>{e.stopPropagation();delOne(n.id);}} style={{background:"none",border:"none",color:T.muted,cursor:"pointer",fontSize:"0.8rem",alignSelf:"flex-start",padding:"2px 4px"}}>✕</button>
        </div>
      ))}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// 👥 CLIENTS HISTORY SCREEN
// ══════════════════════════════════════════════════════════════════════════════
function BClients({bookings,setBookings,services,barber,clientNotes,setClientNotes,cutRecords,setCutRecords,purchaseHistory,setPurchaseHistory,manualClients,setManualClients,shopId,lang,autoOpenChatKey,onAutoOpenChatDone,autoOpenProfileKey,onAutoOpenProfileDone}){
  const L=LANGS[lang].t;
  const [search,setSearch]=useState("");
  const [openClient,setOpenClient]=useState(null);
  const [editNote,setEditNote]=useState(false);
  const [noteText,setNoteText]=useState("");
  const [addingCut,setAddingCut]=useState(false);
  const [cutPhoto,setCutPhoto]=useState(null);
  const [cutNotes,setCutNotes]=useState("");
  const [cutBusy,setCutBusy]=useState(false);
  const [cutErr,setCutErr]=useState("");
  const [viewPhoto,setViewPhoto]=useState(null);
  const [addingPurchase,setAddingPurchase]=useState(false);
  const [purchasePhoto,setPurchasePhoto]=useState(null);
  const [purchaseText,setPurchaseText]=useState("");
  const [purchaseBusy,setPurchaseBusy]=useState(false);
  const [purchaseErr,setPurchaseErr]=useState("");
  const [viewPurchase,setViewPurchase]=useState(null);
  const [delClientOpen,setDelClientOpen]=useState(false);
  const [addClientOpen,setAddClientOpen]=useState(false);
  const [newClientName,setNewClientName]=useState("");
  const [newClientPhone,setNewClientPhone]=useState("");
  const [newClientErr,setNewClientErr]=useState("");
  const [chatClient,setChatClient]=useState(null);
  const unreadMap=useBarberUnreadMap(shopId,barber.id);
  const svc=id=>services.find(s=>s.id===id);

  // Build client map from this barber's bookings
  const clientMap=useMemo(()=>{
    const map={};
    bookings.filter(b=>b.barberId===barber.id&&!b.blocked).forEach(b=>{
      const key=b.phone||b.name;
      if(!map[key])map[key]={name:b.name,phone:b.phone,visits:[],totalSpent:0,lastVisit:"",firstVisit:""};
      map[key].visits.push(b);
      if(b.paid)map[key].totalSpent+=svc(b.serviceId)?.price||0;
      if(!map[key].lastVisit||b.date>map[key].lastVisit)map[key].lastVisit=b.date;
      if(!map[key].firstVisit||b.date<map[key].firstVisit)map[key].firstVisit=b.date;
    });
    Object.entries(manualClients).forEach(([mk,mc])=>{
      if(!mk.startsWith(`${barber.id}::`))return;
      const key=mc.phone||mc.name;
      if(!map[key])map[key]={name:mc.name,phone:mc.phone,visits:[],totalSpent:0,lastVisit:"",firstVisit:""};
    });
    return map;
  },[bookings,barber,manualClients]);

  const clients=Object.values(clientMap).sort((a,b)=>b.visits.length-a.visits.length);
  const filtered=search.trim().length>1?clients.filter(c=>c.name.toLowerCase().includes(search.toLowerCase())||c.phone.includes(search)):clients;

  // Chegou aqui a partir de uma notificação push -> abre já a conversa certa
  useEffect(()=>{
    if(!autoOpenChatKey)return;
    const match=clientMap[autoOpenChatKey]||Object.values(clientMap).find(c=>c.phone===autoOpenChatKey);
    if(match){
      setChatClient(match);
      onAutoOpenChatDone?.();
    }
  },[autoOpenChatKey,clientMap]);

  const openProfile=c=>{
    setOpenClient(c);
    setNoteText(clientNotes[c.phone||c.name]||"");
    setEditNote(false);
    setAddingCut(false);setCutPhoto(null);setCutNotes("");setCutErr("");
    setAddingPurchase(false);setPurchasePhoto(null);setPurchaseText("");setPurchaseErr("");
    setDelClientOpen(false);
  };

  // Chegou aqui a partir de uma notificação de marcação -> abre já o perfil do cliente
  useEffect(()=>{
    if(!autoOpenProfileKey)return;
    const match=clientMap[autoOpenProfileKey]||Object.values(clientMap).find(c=>c.phone===autoOpenProfileKey);
    if(match){
      openProfile(match);
      onAutoOpenProfileDone?.();
    }
  },[autoOpenProfileKey,clientMap]);

  const deleteClient=()=>{
    const key=openClient.phone||openClient.name;
    setBookings(p=>p.filter(b=>!(b.barberId===barber.id&&(b.phone||b.name)===key&&!b.blocked)));
    setClientNotes(p=>{const n={...p};delete n[key];return n;});
    setCutRecords(p=>{const n={...p};delete n[cutKey(openClient)];return n;});
    setPurchaseHistory(p=>{const n={...p};delete n[purchaseKey(openClient)];return n;});
    setManualClients(p=>{const n={...p};delete n[`${barber.id}::${key}`];return n;});
    setOpenClient(null);
    setDelClientOpen(false);
  };
  const saveNewClient=()=>{
    if(!newClientName.trim()){setNewClientErr(L.nameRequiredErr);return;}
    const key=newClientPhone.trim()||newClientName.trim();
    setManualClients(p=>({...p,[`${barber.id}::${key}`]:{name:newClientName.trim(),phone:newClientPhone.trim(),addedAt:TODAY}}));
    setAddClientOpen(false);
  };
  const saveNote=()=>{
    const key=openClient.phone||openClient.name;
    setClientNotes(p=>({...p,[key]:noteText}));
    setEditNote(false);
  };

  // Histórico de cortes — isolado por barbeiro: só este barbeiro vê os cortes que ele próprio registou
  const cutKey=c=>`${barber.id}::${c.phone||c.name}`;
  const myCuts=c=>(cutRecords[cutKey(c)]||[]).slice().sort((a,b)=>b.date.localeCompare(a.date));
  const uploadCutPhoto=async(file)=>{
    if(!file||!shopId)return;
    if(file.size>5*1024*1024){setCutErr(L.photoTooLarge);return;}
    setCutBusy(true);setCutErr("");
    const resized=await resizeImageFile(file);
    const ext=resized.name.split(".").pop();
    const path=`${shopId}/cortes/${barber.id}-${Date.now()}.${ext}`;
    const{error}=await supabase.storage.from("salon-photos").upload(path,resized,{upsert:true});
    if(error){setCutBusy(false);setCutErr(L.uploadFailed);return;}
    const{data}=supabase.storage.from("salon-photos").getPublicUrl(path);
    setCutPhoto(data.publicUrl);
    setCutBusy(false);
  };
  const saveCutRecord=()=>{
    if(!cutPhoto){setCutErr(L.addCutPhotoErr);return;}
    const key=cutKey(openClient);
    const rec={id:Date.now().toString(36),date:TODAY,photoUrl:cutPhoto,notes:cutNotes.trim()};
    setCutRecords(p=>({...p,[key]:[...(p[key]||[]),rec]}));
    setAddingCut(false);setCutPhoto(null);setCutNotes("");setCutErr("");
  };
  const deleteCutRecord=recId=>{
    const key=cutKey(openClient);
    setCutRecords(p=>({...p,[key]:(p[key]||[]).filter(r=>r.id!==recId)}));
  };

  // Histórico de compras — não isolado por barbeiro: todos os barbeiros da loja veem as mesmas compras
  const purchaseKey=c=>c.phone||c.name;
  const myPurchases=c=>(purchaseHistory[purchaseKey(c)]||[]).slice().sort((a,b)=>b.date.localeCompare(a.date));
  const uploadPurchasePhoto=async(file)=>{
    if(!file||!shopId)return;
    if(file.size>5*1024*1024){setPurchaseErr(L.photoTooLarge);return;}
    setPurchaseBusy(true);setPurchaseErr("");
    const resized=await resizeImageFile(file);
    const ext=resized.name.split(".").pop();
    const path=`${shopId}/compras/${Date.now()}.${ext}`;
    const{error}=await supabase.storage.from("salon-photos").upload(path,resized,{upsert:true});
    if(error){setPurchaseBusy(false);setPurchaseErr(L.uploadFailed);return;}
    const{data}=supabase.storage.from("salon-photos").getPublicUrl(path);
    setPurchasePhoto(data.publicUrl);
    setPurchaseBusy(false);
  };
  const savePurchaseRecord=()=>{
    if(!purchaseText.trim()&&!purchasePhoto){setPurchaseErr(L.addPurchaseErr);return;}
    const key=purchaseKey(openClient);
    const rec={id:Date.now().toString(36),date:TODAY,text:purchaseText.trim(),photoUrl:purchasePhoto};
    setPurchaseHistory(p=>({...p,[key]:[...(p[key]||[]),rec]}));
    setAddingPurchase(false);setPurchasePhoto(null);setPurchaseText("");setPurchaseErr("");
  };
  const deletePurchaseRecord=recId=>{
    const key=purchaseKey(openClient);
    setPurchaseHistory(p=>({...p,[key]:(p[key]||[]).filter(r=>r.id!==recId)}));
  };

  // fav service
  const favService=c=>{
    const map={};
    c.visits.forEach(v=>{const s=svc(v.serviceId);if(s){const n=svcName(s,lang);map[n]=(map[n]||0)+1;}});
    return Object.entries(map).sort((a,b)=>b[1]-a[1])[0]?.[0]||"—";
  };

  return(
    <div style={{padding:"0 20px"}}>
      <Inp placeholder={L.searchClient} value={search} onChange={e=>setSearch(e.target.value)} style={{marginBottom:10}}/>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}>
        <Lbl style={{margin:0}}>{filtered.length} {L.clientWord}{filtered.length!==1?"s":""}</Lbl>
        <button onClick={()=>{setAddClientOpen(true);setNewClientName("");setNewClientPhone("");setNewClientErr("");}} style={{background:"none",border:"none",color:T.gold,cursor:"pointer",fontSize:"0.65rem",letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif"}}>{L.addClientBtn}</button>
      </div>

      {addClientOpen&&(
        <Modal onClose={()=>setAddClientOpen(false)} title={L.addClientBtn}>
          <div style={{marginBottom:11}}><Lbl>{L.nameLabel}</Lbl><Inp value={newClientName} onChange={e=>setNewClientName(e.target.value)}/></div>
          <div style={{marginBottom:11}}><Lbl>{L.phone}</Lbl><Inp type="tel" value={newClientPhone} onChange={e=>setNewClientPhone(e.target.value)}/></div>
          {newClientErr&&<div style={{color:T.red,fontSize:"0.72rem",marginBottom:10}}>{newClientErr}</div>}
          <div style={{display:"flex",gap:8}}>
            <Btn variant="gold" style={{flex:1}} onClick={saveNewClient}>{L.save}</Btn>
            <Btn variant="ghost" onClick={()=>setAddClientOpen(false)}>{L.cancel}</Btn>
          </div>
        </Modal>
      )}

      {filtered.map(c=>{
        const key=c.phone||c.name;
        const note=clientNotes[key];
        const upcoming=c.visits.filter(v=>v.date>=TODAY&&v.status==="confirmado").sort((a,b)=>a.date.localeCompare(a.date));
        return(
          <div key={key} className="row-h" onClick={()=>openProfile(c)} style={{padding:"13px 14px",marginBottom:7,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,cursor:"pointer"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
              <div style={{flex:1,minWidth:0}}>
                <div style={{display:"flex",alignItems:"center",gap:8}}>
                  <div style={{fontSize:"1rem",color:T.white,fontWeight:500}}>{c.name}</div>
                  {upcoming.length>0&&<span style={{fontSize:"0.55rem",background:T.goldLo,color:T.gold,border:`1px solid ${T.gold}`,padding:"1px 6px",borderRadius:3,fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.1em"}}>{L.bookedBadge}</span>}
                  {unreadMap[key]>0&&<span style={{fontSize:"0.55rem",background:T.red,color:"#fff",borderRadius:"50%",width:16,height:16,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Josefin Sans',sans-serif"}}>{unreadMap[key]>9?"9+":unreadMap[key]}</span>}
                </div>
                <div style={{fontSize:"0.7rem",color:T.silver,marginTop:2}}>{c.phone} · {c.visits.length} {L.visits}{c.visits.length!==1?"s":""}</div>
                <div style={{fontSize:"0.66rem",color:T.silver,marginTop:1}}>{L.lastVisitLabel}: {dateLabel(c.lastVisit,lang)} · {L.favorite}: {favService(c)}</div>
                {note&&<div style={{fontSize:"0.68rem",color:T.mid,marginTop:4,fontStyle:"italic",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>📝 {note}</div>}
              </div>
              <div style={{textAlign:"right",flexShrink:0,marginLeft:12}}>
                <div style={{fontSize:"1rem",color:T.gold,fontWeight:600}}>€{c.totalSpent}</div>
                <div style={{fontSize:"0.6rem",color:T.silver}}>{L.totalSpent}</div>
              </div>
            </div>
          </div>
        );
      })}

      {/* Client Profile Modal */}
      {openClient&&(()=>{
        const c=openClient;
        const key=c.phone||c.name;
        const note=clientNotes[key]||"";
        const sorted=c.visits.sort((a,b)=>b.date.localeCompare(a.date));
        const upcoming=sorted.filter(v=>v.date>=TODAY&&v.status==="confirmado");
        const past=sorted.filter(v=>v.date<TODAY||v.status==="concluído"||v.status==="cancelado");
        return(
          <Modal onClose={()=>setOpenClient(null)}>
            {/* Profile header */}
            <div style={{display:"flex",alignItems:"center",gap:14,marginBottom:20,paddingBottom:16,borderBottom:`1px solid ${T.border}`}}>
              <div style={{width:52,height:52,borderRadius:"50%",background:T.goldLo,border:`2px solid ${T.gold}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:"1.2rem",color:T.gold,fontWeight:700,fontFamily:"'Josefin Sans',sans-serif",flexShrink:0}}>
                {c.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase()}
              </div>
              <div style={{flex:1}}>
                <div style={{fontSize:"1.2rem",color:T.white,fontWeight:600}}>{c.name}</div>
                <div style={{fontSize:"0.75rem",color:T.silver,marginTop:2}}>{c.phone}</div>
              </div>
              <button onClick={()=>setChatClient(c)} style={{position:"relative",background:T.goldLo,border:`1px solid ${T.gold}`,color:T.gold,padding:"7px 11px",borderRadius:6,cursor:"pointer",fontSize:"0.68rem",fontFamily:"'Josefin Sans',sans-serif",flexShrink:0}}>
                {L.chatBtn}
                {unreadMap[key]>0&&<span style={{position:"absolute",top:-5,right:-5,background:T.red,color:"#fff",borderRadius:"50%",width:16,height:16,fontSize:"0.55rem",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Josefin Sans',sans-serif"}}>{unreadMap[key]>9?"9+":unreadMap[key]}</span>}
              </button>
            </div>

            {/* Stats */}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr 1fr",gap:7,marginBottom:18}}>
              {[{l:L.statVisitsLabel,v:c.visits.length},{l:L.statSpentLabel,v:`€${c.totalSpent}`},{l:L.statNoShowsLabel,v:c.visits.filter(v=>v.status==="falta").length,warn:c.visits.filter(v=>v.status==="falta").length>0},{l:L.favorite,v:favService(c).split(" ")[0]}].map(s=>(
                <div key={s.l} style={{background:T.card,border:`1px solid ${s.warn?T.orange:T.border}`,borderRadius:6,padding:"10px 10px",textAlign:"center"}}>
                  <Lbl style={{marginBottom:4,textAlign:"center"}}>{s.l}</Lbl>
                  <div style={{fontSize:"0.92rem",color:s.warn?T.orange:T.white,fontWeight:600}}>{s.v}</div>
                </div>
              ))}
            </div>
            {c.visits.filter(v=>v.status==="falta").length>0&&(
              <div style={{background:T.orangeLo,border:`1px solid ${T.orange}`,borderRadius:6,padding:"9px 12px",marginBottom:16,color:T.orange,fontSize:"0.74rem"}}>
                {L.noShowWarning.replace("{n}",c.visits.filter(v=>v.status==="falta").length)}
              </div>
            )}

            {/* Notes */}
            <div style={{marginBottom:18}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                <Lbl style={{margin:0}}>{L.barberNotes}</Lbl>
                <button onClick={()=>setEditNote(e=>!e)} style={{background:"none",border:"none",color:T.gold,cursor:"pointer",fontSize:"0.7rem",fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.1em"}}>
                  {editNote?L.cancel:`✏ ${L.edit}`}
                </button>
              </div>
              {editNote?(
                <>
                  <Txta rows={3} value={noteText} onChange={e=>setNoteText(e.target.value)} placeholder={L.notePlaceholder}/>
                  <Btn variant="gold" style={{width:"100%",marginTop:8,padding:"8px"}} onClick={saveNote}>{L.saveNoteBtn}</Btn>
                </>
              ):(
                <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:5,padding:"10px 12px",fontSize:"0.82rem",color:note?T.mid:T.silver,fontStyle:note?"italic":"normal",minHeight:42}}>
                  {note||L.noNotes}
                </div>
              )}
            </div>

            {/* Histórico de cortes (fotos) — só visível para este barbeiro */}
            <div style={{marginBottom:18}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                <Lbl style={{margin:0}}>{L.cutHistoryTitle}</Lbl>
                {!addingCut&&<button onClick={()=>{setAddingCut(true);setCutPhoto(null);setCutNotes("");setCutErr("");}} style={{background:"none",border:"none",color:T.gold,cursor:"pointer",fontSize:"0.7rem",fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.1em"}}>{L.addCutBtn}</button>}
              </div>
              {addingCut&&(
                <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:6,padding:12,marginBottom:10}}>
                  {cutPhoto?(
                    <img src={cutPhoto} alt="" style={{width:"100%",maxHeight:160,objectFit:"cover",borderRadius:5,marginBottom:8}}/>
                  ):(
                    <div style={{display:"flex",gap:8,marginBottom:8}}>
                      <label style={{flex:1}}>
                        <input type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>uploadCutPhoto(e.target.files?.[0])}/>
                        <div style={{padding:"14px 8px",textAlign:"center",background:T.surface,border:`1px dashed ${T.border}`,borderRadius:5,color:T.silver,fontSize:"0.72rem",cursor:"pointer"}}>
                          {cutBusy?L.uploading:L.tapCamera}
                        </div>
                      </label>
                      <label style={{flex:1}}>
                        <input type="file" accept="image/*" style={{display:"none"}} onChange={e=>uploadCutPhoto(e.target.files?.[0])}/>
                        <div style={{padding:"14px 8px",textAlign:"center",background:T.surface,border:`1px dashed ${T.border}`,borderRadius:5,color:T.silver,fontSize:"0.72rem",cursor:"pointer"}}>
                          {cutBusy?L.uploading:L.tapGallery}
                        </div>
                      </label>
                    </div>
                  )}
                  <Txta rows={2} placeholder={L.cutNotesPlaceholder} value={cutNotes} onChange={e=>setCutNotes(e.target.value)} style={{marginBottom:8}}/>
                  {cutErr&&<div style={{color:T.red,fontSize:"0.7rem",marginBottom:8}}>{cutErr}</div>}
                  <div style={{display:"flex",gap:8}}>
                    <Btn variant="gold" style={{flex:1,padding:"8px"}} onClick={saveCutRecord}>{L.saveCutBtn}</Btn>
                    <Btn variant="ghost" style={{padding:"8px"}} onClick={()=>setAddingCut(false)}>{L.cancel}</Btn>
                  </div>
                </div>
              )}
              {myCuts(c).length===0&&!addingCut?(
                <div style={{color:T.silver,fontSize:"0.78rem",padding:"6px 0"}}>{L.noCutsYet}</div>
              ):(
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
                  {myCuts(c).map(r=>(
                    <div key={r.id} onClick={()=>setViewPhoto(r)} style={{cursor:"pointer",position:"relative"}}>
                      <img src={r.photoUrl} alt="" loading="lazy" style={{width:"100%",aspectRatio:"1",objectFit:"cover",borderRadius:5,border:`1px solid ${T.border}`}}/>
                      <div style={{fontSize:"0.6rem",color:T.silver,marginTop:3,textAlign:"center"}}>{dateLabel(r.date,lang)}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Histórico de compras — visível para todos os barbeiros */}
            <div style={{marginBottom:18}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:8}}>
                <Lbl style={{margin:0}}>{L.purchaseHistoryTitle}</Lbl>
                {!addingPurchase&&<button onClick={()=>{setAddingPurchase(true);setPurchasePhoto(null);setPurchaseText("");setPurchaseErr("");}} style={{background:"none",border:"none",color:T.gold,cursor:"pointer",fontSize:"0.7rem",fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.1em"}}>{L.addPurchaseBtn}</button>}
              </div>
              {addingPurchase&&(
                <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:6,padding:12,marginBottom:10}}>
                  {purchasePhoto&&<img src={purchasePhoto} alt="" style={{width:"100%",maxHeight:160,objectFit:"cover",borderRadius:5,marginBottom:8}}/>}
                  {!purchasePhoto&&(
                    <div style={{display:"flex",gap:8,marginBottom:8}}>
                      <label style={{flex:1}}>
                        <input type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>uploadPurchasePhoto(e.target.files?.[0])}/>
                        <div style={{padding:"14px 8px",textAlign:"center",background:T.surface,border:`1px dashed ${T.border}`,borderRadius:5,color:T.silver,fontSize:"0.72rem",cursor:"pointer"}}>
                          {purchaseBusy?L.uploading:L.tapCamera}
                        </div>
                      </label>
                      <label style={{flex:1}}>
                        <input type="file" accept="image/*" style={{display:"none"}} onChange={e=>uploadPurchasePhoto(e.target.files?.[0])}/>
                        <div style={{padding:"14px 8px",textAlign:"center",background:T.surface,border:`1px dashed ${T.border}`,borderRadius:5,color:T.silver,fontSize:"0.72rem",cursor:"pointer"}}>
                          {purchaseBusy?L.uploading:L.tapGallery}
                        </div>
                      </label>
                    </div>
                  )}
                  <Txta rows={2} placeholder={L.purchaseTextPlaceholder} value={purchaseText} onChange={e=>setPurchaseText(e.target.value)} style={{marginBottom:8}}/>
                  {purchaseErr&&<div style={{color:T.red,fontSize:"0.7rem",marginBottom:8}}>{purchaseErr}</div>}
                  <div style={{display:"flex",gap:8}}>
                    <Btn variant="gold" style={{flex:1,padding:"8px"}} onClick={savePurchaseRecord}>{L.savePurchaseBtn}</Btn>
                    <Btn variant="ghost" style={{padding:"8px"}} onClick={()=>setAddingPurchase(false)}>{L.cancel}</Btn>
                  </div>
                </div>
              )}
              {myPurchases(c).length===0&&!addingPurchase?(
                <div style={{color:T.silver,fontSize:"0.78rem",padding:"6px 0"}}>{L.noPurchasesYet}</div>
              ):(
                myPurchases(c).map(r=>(
                  <div key={r.id} onClick={()=>setViewPurchase(r)} style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",borderBottom:`1px solid ${T.border}`,cursor:"pointer"}}>
                    {r.photoUrl&&<img src={r.photoUrl} alt="" loading="lazy" style={{width:40,height:40,objectFit:"cover",borderRadius:5,border:`1px solid ${T.border}`,flexShrink:0}}/>}
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:"0.82rem",color:T.light,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{r.text||L.purchaseRecordTitle}</div>
                      <div style={{fontSize:"0.62rem",color:T.silver}}>{dateLabel(r.date,lang)}</div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Upcoming */}
            {upcoming.length>0&&(
              <div style={{marginBottom:16}}>
                <Lbl style={{marginBottom:8}}>{L.upcoming}</Lbl>
                {upcoming.map(v=>(
                  <div key={v.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 12px",marginBottom:5,background:T.goldLo,border:`1px solid ${T.gold}44`,borderRadius:5}}>
                    <div>
                      <div style={{fontSize:"0.85rem",color:T.white}}>{svcName(svc(v.serviceId),lang)}</div>
                      <div style={{fontSize:"0.66rem",color:T.silver}}>{dateLabel(v.date,lang)} · {v.time}h</div>
                    </div>
                    <div style={{fontSize:"0.82rem",color:T.gold}}>€{svc(v.serviceId)?.price}</div>
                  </div>
                ))}
              </div>
            )}

            {/* History */}
            <Lbl style={{marginBottom:8}}>{L.history}</Lbl>
            <div style={{maxHeight:220,overflowY:"auto"}}>
              {past.length===0?<div style={{color:T.silver,fontSize:"0.8rem",padding:"10px 0"}}>{L.noHistory}</div>
              :past.map(v=>(
                <div key={v.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 0",borderBottom:`1px solid ${T.border}`}}>
                  <div>
                    <div style={{fontSize:"0.85rem",color:T.light}}>{svcName(svc(v.serviceId),lang)}</div>
                    <div style={{fontSize:"0.65rem",color:T.silver,marginTop:2}}>{dateLabel(v.date,lang)} · {v.time}h {v.paid?`· ${v.payMethod}`:""}</div>
                  </div>
                  <div style={{textAlign:"right"}}>
                    <div style={{fontSize:"0.82rem",color:v.paid?T.green:T.silver}}>€{svc(v.serviceId)?.price}</div>
                    <Tag status={v.status}/>
                  </div>
                </div>
              ))}
            </div>

            <div style={{marginTop:24,paddingTop:16,borderTop:`1px solid ${T.border}`}}>
              <Btn variant="danger" style={{width:"100%"}} onClick={()=>setDelClientOpen(true)}>{L.deleteClientBtn}</Btn>
            </div>

            {delClientOpen&&(
              <Modal onClose={()=>setDelClientOpen(false)} title={L.deleteClientBtn}>
                <div style={{fontSize:"0.8rem",color:T.silver,marginBottom:16,lineHeight:1.5}}>
                  {L.deleteClientWarning.replace("{name}",c.name)}
                </div>
                <div style={{display:"flex",gap:8}}>
                  <Btn variant="danger" style={{flex:1}} onClick={deleteClient}>{L.deletePermanently}</Btn>
                  <Btn variant="ghost" onClick={()=>setDelClientOpen(false)}>{L.cancel}</Btn>
                </div>
              </Modal>
            )}

            <Btn variant="ghost" style={{width:"100%",marginTop:16}} onClick={()=>setOpenClient(null)}>{L.close}</Btn>
          </Modal>
        );
      })()}

      {/* Chat com o cliente */}
      {chatClient&&(
        <Modal onClose={()=>setChatClient(null)} title={`${L.chatTitle} · ${chatClient.name}`}>
          <ChatThread shopId={shopId} barberId={barber.id} clientKey={chatClient.phone||chatClient.name} sender="barber" lang={lang}/>
        </Modal>
      )}

      {/* Ver foto de corte ampliada */}
      {viewPhoto&&(
        <Modal onClose={()=>setViewPhoto(null)} title={L.cutRecordTitle}>
          <img src={viewPhoto.photoUrl} alt="" style={{width:"100%",borderRadius:6,marginBottom:10}}/>
          <div style={{fontSize:"0.7rem",color:T.silver,marginBottom:8}}>{dateLabel(viewPhoto.date,lang)}</div>
          {viewPhoto.notes&&<div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:5,padding:"10px 12px",fontSize:"0.82rem",color:T.mid,fontStyle:"italic",marginBottom:12}}>{viewPhoto.notes}</div>}
          <div style={{display:"flex",gap:8}}>
            <Btn variant="danger" style={{flex:1}} onClick={()=>{deleteCutRecord(viewPhoto.id);setViewPhoto(null);}}>{L.deleteCutBtn}</Btn>
            <Btn variant="ghost" onClick={()=>setViewPhoto(null)}>{L.close}</Btn>
          </div>
        </Modal>
      )}

      {/* Ver / apagar compra */}
      {viewPurchase&&(
        <Modal onClose={()=>setViewPurchase(null)} title={L.purchaseRecordTitle}>
          {viewPurchase.photoUrl&&<img src={viewPurchase.photoUrl} alt="" style={{width:"100%",borderRadius:6,marginBottom:10}}/>}
          <div style={{fontSize:"0.7rem",color:T.silver,marginBottom:8}}>{dateLabel(viewPurchase.date,lang)}</div>
          {viewPurchase.text&&<div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:5,padding:"10px 12px",fontSize:"0.82rem",color:T.mid,marginBottom:12}}>{viewPurchase.text}</div>}
          <div style={{display:"flex",gap:8}}>
            <Btn variant="danger" style={{flex:1}} onClick={()=>{deletePurchaseRecord(viewPurchase.id);setViewPurchase(null);}}>{L.deletePurchaseBtn}</Btn>
            <Btn variant="ghost" onClick={()=>setViewPurchase(null)}>{L.close}</Btn>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// BARBER SCREENS (Dashboard, Agenda, Reports, Schedule, Profile)
// ══════════════════════════════════════════════════════════════════════════════
function BDashboard({bookings,services,barber,lang}){
  const L=LANGS[lang].t;
  const svc=id=>services.find(s=>s.id===id);
  const myBk=bookings.filter(b=>b.barberId===barber.id&&!b.blocked);
  const todayBk=myBk.filter(b=>b.date===TODAY);
  const revenue=todayBk.filter(b=>b.paid).reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);
  const pending=todayBk.filter(b=>b.status==="confirmado"&&!b.paid).reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);
  const upcoming=myBk.filter(b=>b.date>=TODAY&&b.status==="confirmado").sort((a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time)).slice(0,6);
  const weekBk=myBk.filter(b=>{const d=new Date(b.date+"T12:00:00"),t=new Date(TODAY+"T12:00:00");return d>=t&&d<new Date(t.getTime()+7*86400000);});
  return(
    <div style={{padding:"0 20px"}}>
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:18,padding:"13px",background:T.card,border:`1px solid ${T.border}`,borderRadius:8}}>
        <Avatar barber={barber} size={46}/>
        <div>
          <div style={{fontSize:"1.05rem",color:T.white,fontWeight:600}}>{barber.name}</div>
          <div style={{fontSize:"0.68rem",color:T.silver}}>{barber.role}</div>
          <div style={{fontSize:"0.62rem",color:barber.color,marginTop:2,fontFamily:"'Josefin Sans',sans-serif"}}>
            {LANGS[lang].wdaysF.filter((_,i)=>barber.schedule.workDays.includes(i)).map(d=>d.slice(0,3)).join(" · ")} · {barber.schedule.startHour}–{barber.schedule.endHour}
          </div>
        </div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:18}}>
        {[{l:L.revenue,v:`€${revenue}`,s:`€${pending} ${L.pendingRev}`,c:T.gold},{l:L.today,v:todayBk.length,s:`${todayBk.filter(b=>b.status==="concluído").length} ${L.concluded}`,c:T.white},{l:L.toConfirm,v:todayBk.filter(b=>b.status==="confirmado").length,s:L.pendingOpen,c:T.mid},{l:L.week,v:weekBk.length,s:L.bookings,c:T.mid}].map(s=>(
          <div key={s.l} style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"12px 13px"}}>
            <Lbl style={{marginBottom:4}}>{s.l}</Lbl>
            <div style={{fontSize:"1.45rem",color:s.c,fontWeight:600,lineHeight:1}}>{s.v}</div>
            <div style={{fontSize:"0.64rem",color:T.silver,marginTop:4}}>{s.s}</div>
          </div>
        ))}
      </div>
      <Lbl style={{marginBottom:10}}>{L.nextBookings}</Lbl>
      {upcoming.length===0?<div style={{textAlign:"center",padding:"22px 0",color:T.silver,fontSize:"0.88rem"}}>{L.noFuture}</div>
      :upcoming.map(b=>(
        <div key={b.id} style={{display:"flex",alignItems:"center",gap:12,padding:"10px 12px",marginBottom:6,background:T.card,border:`1px solid ${T.border}`,borderRadius:6}}>
          <div style={{textAlign:"center",minWidth:44}}>
            <div style={{fontSize:"0.85rem",color:T.gold,fontFamily:"'Josefin Sans',sans-serif",fontWeight:600}}>{b.time}</div>
            <div style={{fontSize:"0.56rem",color:T.silver}}>{dateLabel(b.date,lang)}</div>
          </div>
          <Hr style={{width:1,height:26,alignSelf:"center"}}/>
          <div style={{flex:1,minWidth:0}}>
            <div style={{fontSize:"0.92rem",color:T.white,fontWeight:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.name}</div>
            <div style={{fontSize:"0.7rem",color:T.silver}}>{svcName(svc(b.serviceId),lang)}</div>
          </div>
          <div style={{fontSize:"0.88rem",color:T.gold}}>€{svc(b.serviceId)?.price}</div>
        </div>
      ))}
    </div>
  );
}

function MiniCalendar({lang,value,bookings,barber,onSelect,onClose}){
  const L=LANGS[lang].t;
  const WD=LANGS[lang].wdays;
  const initial=value?new Date(value+"T12:00:00"):new Date();
  const [viewY,setViewY]=useState(initial.getFullYear());
  const [viewM,setViewM]=useState(initial.getMonth());
  const first=new Date(viewY,viewM,1);
  const startWeekday=first.getDay();
  const daysInMonth=new Date(viewY,viewM+1,0).getDate();
  const prevMonthDays=new Date(viewY,viewM,0).getDate();
  const cells=[];
  for(let i=0;i<startWeekday;i++)cells.push({d:prevMonthDays-startWeekday+1+i,cur:false,dateObj:new Date(viewY,viewM-1,prevMonthDays-startWeekday+1+i)});
  for(let d=1;d<=daysInMonth;d++)cells.push({d,cur:true,dateObj:new Date(viewY,viewM,d)});
  while(cells.length%7!==0){const idx=cells.length-startWeekday-daysInMonth+1;cells.push({d:idx,cur:false,dateObj:new Date(viewY,viewM+1,idx)});}
  const changeMonth=delta=>{let m=viewM+delta,y=viewY;if(m<0){m=11;y--;}if(m>11){m=0;y++;}setViewM(m);setViewY(y);};
  const todayStr=fmt(new Date());
  return(<>
    <div onClick={onClose} style={{position:"fixed",inset:0,zIndex:49}}/>
    <div style={{position:"absolute",top:"calc(100% + 6px)",right:0,zIndex:50,background:T.card,border:`1px solid ${T.border}`,borderRadius:8,padding:14,boxShadow:"0 8px 24px rgba(0,0,0,0.5)",width:266}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
        <button onClick={()=>changeMonth(-1)} style={{background:"none",border:`1px solid ${T.border}`,borderRadius:5,color:T.silver,cursor:"pointer",padding:"3px 9px",fontSize:"0.72rem"}}>‹</button>
        <div style={{fontSize:"0.76rem",color:T.white,fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.05em"}}>{LANGS[lang].months[viewM]} {viewY}</div>
        <button onClick={()=>changeMonth(1)} style={{background:"none",border:`1px solid ${T.border}`,borderRadius:5,color:T.silver,cursor:"pointer",padding:"3px 9px",fontSize:"0.72rem"}}>›</button>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2,marginBottom:4}}>
        {WD.map((w,i)=><div key={i} style={{textAlign:"center",fontSize:"0.48rem",color:T.silver,fontFamily:"'Josefin Sans',sans-serif",textTransform:"uppercase"}}>{w}</div>)}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:2}}>
        {cells.map((cell,i)=>{
          const iso=fmt(cell.dateObj);
          const sel=iso===value;
          const isToday=iso===todayStr;
          const cnt=cell.cur?bookings.filter(b=>b.barberId===barber.id&&b.date===iso&&!b.blocked).length:0;
          return(
            <button key={i} onClick={()=>cell.cur&&onSelect(iso)} disabled={!cell.cur} style={{aspectRatio:"1",border:isToday&&!sel?`1px solid ${T.gold}`:"1px solid transparent",borderRadius:5,background:sel?T.gold:"transparent",color:!cell.cur?T.muted:sel?"#000":T.white,fontSize:"0.72rem",cursor:cell.cur?"pointer":"default",position:"relative",opacity:cell.cur?1:0.28}}>
              {cell.d}
              {cnt>0&&!sel&&<span style={{position:"absolute",bottom:2,left:"50%",transform:"translateX(-50%)",width:3,height:3,borderRadius:"50%",background:T.gold}}/>}
            </button>
          );
        })}
      </div>
      <button onClick={()=>onSelect(todayStr)} style={{marginTop:10,width:"100%",padding:"7px",background:"none",border:`1px solid ${T.gold}`,borderRadius:5,color:T.gold,cursor:"pointer",fontSize:"0.62rem",fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.08em"}}>{L.today.toUpperCase()}</button>
    </div>
  </>);
}

function BAgenda({bookings,setBookings,services,barbers,barber,addNotification,lang}){
  const L=LANGS[lang].t;
  const WD=LANGS[lang].wdays;
  const [selDate,setSelDate]=useState(TODAY);
  const [dayOffset,setDayOffset]=useState(0);
  const [modal,setModal]=useState(null);
  const [blocking,setBlocking]=useState(false);
  const [blockMode,setBlockMode]=useState("slot"); // slot | day | period
  const [blockPeriod,setBlockPeriod]=useState({start:"",end:""});
  const [blockRange,setBlockRange]=useState({start:"",end:""});

  const addBlockDay=()=>{
    setBookings(p=>[...p,{id:mkId(),barberId:barber.id,date:selDate,time:"DIA_INTEIRO",blocked:true,name:L.blockedDayName,status:"bloqueado",serviceId:"s1",phone:"",paid:false,payMethod:"",notes:""}]);
    setBlocking(false);
  };
  const addBlockPeriod=()=>{
    if(!blockPeriod.start||!blockPeriod.end)return;
    const start=new Date(blockPeriod.start+"T12:00:00");
    const end=new Date(blockPeriod.end+"T12:00:00");
    const days=[];
    for(let d=new Date(start);d<=end;d.setDate(d.getDate()+1))days.push(fmt(new Date(d)));
    setBookings(p=>[...p,...days.map(date=>({id:mkId(),barberId:barber.id,date,time:"DIA_INTEIRO",blocked:true,name:L.blockedPeriodName,status:"bloqueado",serviceId:"s1",phone:"",paid:false,payMethod:"",notes:""}))]);
    setBlockPeriod({start:"",end:""});
    setBlocking(false);
  };
  const addBlockRange=()=>{
  if(!blockRange.start||!blockRange.end||blockRange.end<=blockRange.start)return;
  const slots=hours.filter(h=>h>=blockRange.start&&h<blockRange.end&&!dayBk.find(b=>b.time===h));
  setBookings(p=>[...p,...slots.map(time=>({id:mkId(),barberId:barber.id,date:selDate,time,blocked:true,name:L.absenceName,status:"bloqueado",serviceId:"s1",phone:"",paid:false,payMethod:"",notes:""}))]);
  setBlockRange({start:"",end:""});
  setBlocking(false);
};
const isDayFullyBlocked=date=>bookings.some(b=>b.barberId===barber.id&&b.date===date&&b.time==="DIA_INTEIRO"&&b.blocked);
  const unblockDay=date=>setBookings(p=>p.filter(b=>!(b.barberId===barber.id&&b.date===date&&b.time==="DIA_INTEIRO"&&b.blocked)));
  const svc=id=>services.find(s=>s.id===id);
  const hours=getBarberHours(barber);
  const dayBk=useMemo(()=>bookings.filter(b=>b.barberId===barber.id&&b.date===selDate).sort((a,b)=>a.time.localeCompare(b.time)),[bookings,selDate,barber]);
  const strip=Array.from({length:7}).map((_,i)=>{const d=new Date(Date.now()+(dayOffset+i)*86400000);return{str:fmt(d),d};});
  const jumpToDate=iso=>{
    if(!iso)return;
    const picked=new Date(iso+"T00:00:00");
    const diffDays=Math.round((picked-new Date(new Date().toDateString()))/86400000);
    setDayOffset(diffDays);
    setSelDate(fmt(picked));
  };
  const openAdd=(time="")=>setModal({mode:"add",data:{id:null,barberId:barber.id,date:selDate,time,serviceId:"s1",name:"",phone:"",status:"confirmado",paid:false,payMethod:"",notes:"",blocked:false}});
  const openEdit=b=>setModal({mode:"edit",data:{...b}});
  const save=f=>{
    if(f.id){setBookings(p=>p.map(b=>b.id===f.id?f:b));}
    else{
      setBookings(p=>[...p,{...f,id:mkId()}]);
      addNotification(barber.id,"new",L.notifNewBookingTitle,`${f.name} — ${svcName(svc(f.serviceId),lang)} — ${f.date} às ${f.time}h`,{type:"client",key:f.phone||f.name});
    }
    setModal(null);
  };
  const del=id=>{
    const b=bookings.find(b=>b.id===id);
    if(b)addNotification(barber.id,"cancel",L.notifBookingDeletedTitle,L.notifBookingDeletedBody.replace("{name}",b.name).replace("{date}",dateLabel(b.date,lang)).replace("{time}",b.time),{type:"client",key:b.phone||b.name});
    setBookings(p=>p.filter(b=>b.id!==id));setModal(null);
  };
  const qStatus=(id,st)=>{
    setBookings(p=>p.map(b=>b.id===id?{...b,status:st}:b));
    if(st==="cancelado"){const b=bookings.find(b=>b.id===id);if(b)addNotification(barber.id,"cancel",L.notifCancelTitle,L.notifCancelBody.replace("{name}",b.name).replace("{date}",dateLabel(b.date,lang)).replace("{time}",b.time),{type:"client",key:b.phone||b.name});}
  };
  const qPaid=id=>setBookings(p=>p.map(b=>b.id===id?{...b,paid:!b.paid}:b));
  const addBlock=time=>setBookings(p=>[...p,{id:mkId(),barberId:barber.id,date:selDate,time,blocked:true,name:L.blockedSlotLabel,status:"bloqueado",serviceId:"s1",phone:"",paid:false,payMethod:"",notes:""}]);
  const [showCal,setShowCal]=useState(false);
  const worksToday=barberWorksOnDate(barber,selDate);
  return(
    <div style={{padding:"0 20px"}}>
      {/* navegação por semana */}
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:8}}>
        <button onClick={()=>setDayOffset(o=>o-7)} style={{background:"none",border:`1px solid ${T.border}`,borderRadius:5,color:T.silver,cursor:"pointer",padding:"5px 10px",fontSize:"0.8rem"}}>‹</button>
        <div style={{display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontSize:"0.72rem",color:T.silver,fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.05em"}}>
            {LANGS[lang].months[strip[0].d.getMonth()]} {strip[0].d.getFullYear()}
          </span>
          <div style={{position:"relative"}}>
            <button onClick={()=>setShowCal(s=>!s)} style={{background:"none",border:"none",cursor:"pointer",fontSize:"0.9rem",padding:0,lineHeight:1}}>📅</button>
            {showCal&&<MiniCalendar lang={lang} value={selDate} bookings={bookings} barber={barber} onClose={()=>setShowCal(false)} onSelect={iso=>{jumpToDate(iso);setShowCal(false);}}/>}
          </div>
          {dayOffset!==0&&<button onClick={()=>{setDayOffset(0);setSelDate(TODAY);}} style={{background:"none",border:`1px solid ${T.gold}`,borderRadius:5,color:T.gold,cursor:"pointer",padding:"3px 9px",fontSize:"0.62rem",fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.08em"}}>{L.today.toUpperCase()}</button>}
        </div>
        <button onClick={()=>setDayOffset(o=>o+7)} style={{background:"none",border:`1px solid ${T.border}`,borderRadius:5,color:T.silver,cursor:"pointer",padding:"5px 10px",fontSize:"0.8rem"}}>›</button>
      </div>
      {/* strip */}
      <div style={{display:"flex",gap:6,overflowX:"auto",paddingBottom:10,marginBottom:14,scrollbarWidth:"none"}}>
        {strip.map(({str,d})=>{
          const cnt=bookings.filter(b=>b.barberId===barber.id&&b.date===str&&!b.blocked).length;
          const works=barberWorksOnDate(barber,str),sel=str===selDate;
          const fullyBlocked=isDayFullyBlocked(str);
          return(<div key={str} onClick={()=>setSelDate(str)} style={{minWidth:47,borderRadius:6,padding:"8px 4px",textAlign:"center",cursor:"pointer",flexShrink:0,background:sel?T.gold:fullyBlocked?T.redLo:T.card,border:`1px solid ${sel?T.gold:fullyBlocked?T.red:works?T.border:T.muted}`}}>
            <div style={{fontSize:"0.52rem",letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",color:sel?"#000":fullyBlocked?T.red:T.silver,marginBottom:3}}>{WD[d.getDay()]}</div>
            <div style={{fontSize:"0.97rem",fontWeight:600,color:sel?"#000":fullyBlocked?T.red:T.white,lineHeight:1}}>{d.getDate()}</div>
            {fullyBlocked?<div style={{fontSize:"0.45rem",color:sel?"#000":T.red,marginTop:3}}>🔒</div>:!works?<div style={{fontSize:"0.62rem",fontWeight:800,color:sel?"#000":T.red,marginTop:3}}>F</div>:cnt>0&&<div style={{width:4,height:4,borderRadius:"50%",background:sel?"#000":T.gold,margin:"3px auto 0"}}/>}
          </div>);
        })}
      </div>
      {!worksToday?<div style={{textAlign:"center",padding:"40px 0",color:T.silver}}><div style={{fontSize:"1.5rem",opacity:.18,marginBottom:8}}>🔒</div>{L.holiday}</div>:(
        <>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
            <div><span style={{fontSize:"1.08rem",color:T.white,fontWeight:600}}>{dateLabel(selDate,lang)}</span><span style={{fontSize:"0.68rem",color:T.silver,marginLeft:8}}>{dayBk.filter(b=>!b.blocked).length} {L.bookings}</span></div>
            <div style={{display:"flex",gap:6}}>
              <Btn variant="ghost" style={{padding:"5px 9px",fontSize:"0.56rem"}} onClick={()=>setBlocking(b=>!b)}>🔒</Btn>
              <Btn variant="gold" style={{padding:"5px 11px"}} onClick={()=>openAdd()}>{L.newBooking}</Btn>
            </div>
          </div>
          {/* Day fully blocked banner */}
          {isDayFullyBlocked(selDate)&&(
            <div style={{background:T.redLo,border:`1px solid ${T.red}`,borderRadius:7,padding:"12px 14px",marginBottom:12,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <div style={{fontSize:"0.85rem",color:T.red,fontWeight:600}}>🔒 {L.dayBlocked}</div>
              <button onClick={()=>unblockDay(selDate)} style={{padding:"4px 10px",background:"none",border:`1px solid ${T.red}`,borderRadius:4,color:T.red,cursor:"pointer",fontSize:"0.62rem",fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.1em"}}>{L.unblock}</button>
            </div>
          )}

          {blocking&&(
            <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:14,marginBottom:12}}>
              {/* Mode tabs */}
              <div style={{display:"flex",gap:5,marginBottom:12}}>
                {[["slot",L.blockSlot],["hours",L.blockHours],["day",L.blockDay],["period",L.blockPeriod]].map(([id,l])=>(
                  <button key={id} onClick={()=>setBlockMode(id)} style={{flex:1,padding:"6px 4px",borderRadius:4,cursor:"pointer",fontSize:"0.6rem",letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",background:blockMode===id?T.redLo:"transparent",color:blockMode===id?T.red:T.silver,border:`1px solid ${blockMode===id?T.red:T.border}`}}>{l}</button>
                ))}
              </div>

              {blockMode==="slot"&&(<>
                <Lbl style={{marginBottom:8}}>{L.blockSlotTitle}</Lbl>
                <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                  {hours.filter(h=>!dayBk.find(b=>b.time===h)).map(h=>(
                    <button key={h} onClick={()=>{addBlock(h);setBlocking(false);}} style={{padding:"5px 10px",background:T.muted,border:`1px solid ${T.border}`,borderRadius:4,color:T.mid,fontSize:"0.75rem",cursor:"pointer",fontFamily:"'Josefin Sans',sans-serif"}}>{h}</button>
                  ))}
                </div>
              </>)}

              {blockMode==="hours"&&(<>
  <Lbl style={{marginBottom:8}}>{L.blockHoursTitle}</Lbl>
  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
    <div><Lbl>{L.fromDate}</Lbl><Sel value={blockRange.start} onChange={e=>setBlockRange(p=>({...p,start:e.target.value}))}><option value="">--</option>{hours.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
    <div><Lbl>{L.toDate}</Lbl><Sel value={blockRange.end} onChange={e=>setBlockRange(p=>({...p,end:e.target.value}))}><option value="">--</option>{hours.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
  </div>
  <Btn variant="danger" style={{width:"100%"}} onClick={addBlockRange}>🔒 {L.blockHoursTitle}</Btn>
</>)}

              {blockMode==="day"&&(<>
                <Lbl style={{marginBottom:8}}>{L.blockDayTitle} — {dateLabel(selDate,lang)}</Lbl>
                <div style={{fontSize:"0.8rem",color:T.silver,marginBottom:12}}>{L.noBookingCanBeMade}</div>
                <Btn variant="danger" style={{width:"100%"}} onClick={addBlockDay}>🔒 {L.blockDayTitle}</Btn>
              </>)}

              {blockMode==="period"&&(<>
                <Lbl style={{marginBottom:8}}>{L.blockPeriodTitle}</Lbl>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:12}}>
                  <div><Lbl>{L.fromDate}</Lbl><Inp type="date" value={blockPeriod.start} onChange={e=>setBlockPeriod(p=>({...p,start:e.target.value}))}/></div>
                  <div><Lbl>{L.toDate}</Lbl><Inp type="date" value={blockPeriod.end} onChange={e=>setBlockPeriod(p=>({...p,end:e.target.value}))}/></div>
                </div>
                {blockPeriod.start&&blockPeriod.end&&blockPeriod.end>=blockPeriod.start&&(
                  <div style={{fontSize:"0.76rem",color:T.silver,marginBottom:10}}>
                    {Math.round((new Date(blockPeriod.end)-new Date(blockPeriod.start))/86400000)+1} {L.blockDays}
                  </div>
                )}
                <Btn variant="danger" style={{width:"100%"}} onClick={addBlockPeriod}>🔒 {L.blockPeriodTitle}</Btn>
              </>)}

              <Btn variant="ghost" style={{marginTop:10,width:"100%",padding:"6px",fontSize:"0.58rem"}} onClick={()=>setBlocking(false)}>{L.cancel}</Btn>
            </div>
          )}
          {!isDayFullyBlocked(selDate)&&dayBk.length===0?<div style={{textAlign:"center",padding:"36px 0",color:T.silver}}><div style={{fontSize:"1.5rem",opacity:.18,marginBottom:8}}>✂</div>{L.noBookingsShort}</div>
          :dayBk.map(b=>{
            const s=svc(b.serviceId);
            if(b.blocked)return(<div key={b.id} style={{display:"flex",alignItems:"center",marginBottom:7,borderRadius:6,overflow:"hidden",border:`1px solid ${T.border}`}}>
              <div style={{minWidth:52,padding:"11px 8px",background:T.muted,textAlign:"center"}}><div style={{fontSize:"0.82rem",color:T.silver,fontFamily:"'Josefin Sans',sans-serif"}}>{b.time}</div></div>
              <div style={{flex:1,padding:"11px 12px",background:T.card}}><div style={{fontSize:"0.76rem",color:T.silver}}>{L.blockedSlotLabel}</div></div>
              <button onClick={()=>del(b.id)} style={{padding:"0 12px",height:"100%",background:"none",border:"none",borderLeft:`1px solid ${T.border}`,color:T.silver,cursor:"pointer"}}>✕</button>
            </div>);
            return(<div key={b.id} style={{display:"flex",marginBottom:7,borderRadius:6,overflow:"hidden",border:`1px solid ${T.border}`,cursor:"pointer"}} onClick={()=>openEdit(b)}>
              <div style={{minWidth:52,padding:"12px 8px",background:T.card,borderRight:`1px solid ${T.border}`,textAlign:"center",flexShrink:0}}>
                <div style={{fontSize:"0.85rem",color:T.gold,fontFamily:"'Josefin Sans',sans-serif",fontWeight:600}}>{b.time}</div>
                <div style={{fontSize:"0.54rem",color:T.silver,marginTop:2}}>{s?.duration}m</div>
              </div>
              <div style={{flex:1,padding:"10px 11px",background:T.surface,minWidth:0}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:8}}>
                  <div style={{minWidth:0}}>
                    <div style={{fontSize:"0.92rem",color:T.white,fontWeight:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.name}</div>
                    <div style={{fontSize:"0.7rem",color:T.silver,marginTop:2}}>{s?.name}</div>
                    {b.phone&&<div style={{fontSize:"0.64rem",color:T.silver,marginTop:1}}>{b.phone}</div>}
                    {(()=>{const n=bookings.filter(x=>x.status==="falta"&&x.barberId===barber.id&&(b.phone?x.phone===b.phone:x.name===b.name)).length;return n>0?<div style={{fontSize:"0.6rem",color:T.orange,marginTop:3}}>{L.noShowWarning.replace("{n}",n)}</div>:null;})()}
                  </div>
                  <div style={{textAlign:"right",flexShrink:0}}>
                    <div style={{fontSize:"0.88rem",color:T.gold,fontWeight:600,marginBottom:3}}>€{s?.price}</div>
                    <Tag status={b.status}/>
                    {b.paid&&<div style={{fontSize:"0.5rem",color:T.green,marginTop:3,fontFamily:"'Josefin Sans',sans-serif"}}>✓ {L.payment.toUpperCase()}</div>}
                  </div>
                </div>
              </div>
              <div onClick={e=>e.stopPropagation()} style={{display:"flex",flexDirection:"column",background:T.card,borderLeft:`1px solid ${T.border}`,flexShrink:0}}>
                {[{icon:"✓",k:"concluído",c:T.green,a:b.status==="concluído"},{icon:"€",k:"paid",c:T.gold,a:b.paid},{icon:"⊘",k:"falta",c:T.orange,a:b.status==="falta"},{icon:"✕",k:"cancelado",c:T.red,a:b.status==="cancelado"}].map(({icon,k,c,a})=>(
                  <button key={k} onClick={()=>k==="paid"?qPaid(b.id):qStatus(b.id,k)} style={{flex:1,width:29,border:"none",cursor:"pointer",fontSize:"0.74rem",borderBottom:`1px solid ${T.border}`,background:a?`${c}22`:"transparent",color:a?c:T.muted}}>{icon}</button>
                ))}
              </div>
            </div>);
          })}
          {(()=>{const free=hours.filter(h=>!dayBk.find(b=>b.time===h));if(!free.length)return null;return(<div style={{marginTop:14}}><Lbl style={{marginBottom:7}}>{L.freeSlots}</Lbl><div style={{display:"flex",flexWrap:"wrap",gap:6}}>{free.map(h=><button key={h} className="slot-h" onClick={()=>openAdd(h)} style={{padding:"4px 9px",background:"transparent",border:`1px solid ${T.border}`,borderRadius:4,color:T.silver,fontSize:"0.73rem",cursor:"pointer",transition:"all .15s",fontFamily:"'Josefin Sans',sans-serif"}}>{h}</button>)}</div></div>);})()}
        </>
      )}
      {modal&&<Modal onClose={()=>setModal(null)} title={modal.mode==="add"?L.addBooking:L.editBooking}><BookingForm initial={modal.data} services={services} barbers={barbers} bookings={bookings} onSave={save} onDelete={modal.mode==="edit"?()=>del(modal.data.id):null} onClose={()=>setModal(null)} fixedBarberId={barber.id} lang={lang}/></Modal>}
    </div>
  );
}

// ─── CONFIRM PAYMENT MODAL ───────────────────────────────────────────────────
function ConfirmPayModal({booking,svc,onConfirm,onClose,lang}){
  const L=LANGS[lang].t;
  const [method,setMethod]=useState(booking.payMethod||"");
  const s=svc(booking.serviceId);
  return(
    <Modal onClose={onClose} title={L.payConfirm}>
      <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"14px",marginBottom:18}}>
        <div style={{fontSize:"1rem",color:T.white,fontWeight:500,marginBottom:4}}>{booking.name}</div>
        <div style={{fontSize:"0.8rem",color:T.silver,marginBottom:2}}>{s?.name} · {booking.time}h · {dateLabel(booking.date,lang)}</div>
        <div style={{fontSize:"1.3rem",color:T.gold,fontWeight:700,marginTop:10}}>€{s?.price}</div>
      </div>
      <Lbl style={{marginBottom:8}}>{L.paymentMethod}</Lbl>
      <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:20}}>
        {LANGS[lang].pay.map(p=>(
          <button key={p} onClick={()=>setMethod(p)} style={{padding:"9px 14px",borderRadius:4,cursor:"pointer",fontSize:"0.78rem",fontFamily:"'Josefin Sans',sans-serif",background:method===p?T.goldLo:"transparent",color:method===p?T.gold:T.mid,border:`1px solid ${method===p?T.gold:T.border}`,fontWeight:method===p?700:400}}>{p}</button>
        ))}
      </div>
      <Btn variant="gold" style={{width:"100%"}} onClick={()=>method&&onConfirm(booking.id,method)}>{L.confirmAmountBtn} €{s?.price}</Btn>
      <Btn variant="ghost" style={{width:"100%",marginTop:8}} onClick={onClose}>{L.cancel}</Btn>
    </Modal>
  );
}

// ─── PRINT REPORT ─────────────────────────────────────────────────────────────
function PrintReport({bookings,label,barberName,svc,onClose,lang}){
  const L=LANGS[lang].t;
  const confirmed=bookings.filter(b=>b.status==="concluído"&&b.paid);
  const pending=bookings.filter(b=>b.status==="concluído"&&!b.paid);
  const cancelled=bookings.filter(b=>b.status==="cancelado");
  const total=confirmed.reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);
  const pendingTotal=pending.reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);
  const byMethod={};
  confirmed.forEach(b=>{const m=b.payMethod||"Outro";byMethod[m]=(byMethod[m]||0)+(svc(b.serviceId)?.price||0);});
  return(
    <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.9)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:400,padding:"20px"}}>
      <div onClick={e=>e.stopPropagation()} style={{width:"100%",maxWidth:480,background:"#fff",borderRadius:8,padding:"28px",maxHeight:"90vh",overflowY:"auto",color:"#111",fontFamily:"'Josefin Sans',sans-serif"}}>
        <div style={{textAlign:"center",borderBottom:"2px solid #111",paddingBottom:14,marginBottom:18}}>
          <div style={{fontSize:"1.3rem",fontWeight:700,letterSpacing:"0.15em"}}>LC.84 BARBER VISION</div>
          <div style={{fontSize:"0.72rem",color:"#555",marginTop:3,letterSpacing:"0.2em",textTransform:"uppercase"}}>{L.reportLabel} — {label}</div>
          <div style={{fontSize:"0.7rem",color:"#555",marginTop:2}}>{L.barberLabel}: {barberName}</div>
          <div style={{fontSize:"0.66rem",color:"#888",marginTop:2}}>{L.issuedOn} {NOW.getDate()} {LANGS[lang].months[NOW.getMonth()]} {NOW.getFullYear()}</div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:8,marginBottom:18}}>
          {[{l:L.billed,v:`€${total}`,c:"#4a8a5f"},{l:L.services,v:confirmed.length,c:"#111"},{l:L.pendingRev,v:`€${pendingTotal}`,c:"#9e4040"}].map(s=>(
            <div key={s.l} style={{border:"1px solid #ddd",borderRadius:5,padding:"9px",textAlign:"center"}}>
              <div style={{fontSize:"0.58rem",letterSpacing:"0.18em",textTransform:"uppercase",color:"#888",marginBottom:3}}>{s.l}</div>
              <div style={{fontSize:"1.1rem",fontWeight:700,color:s.c}}>{s.v}</div>
            </div>
          ))}
        </div>
        {Object.keys(byMethod).length>0&&(<>
          <div style={{fontSize:"0.62rem",letterSpacing:"0.22em",textTransform:"uppercase",color:"#888",marginBottom:8,borderTop:"1px solid #ddd",paddingTop:12}}>{L.byMethod}</div>
          {Object.entries(byMethod).map(([m,v])=>(
            <div key={m} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:"1px solid #eee",fontSize:"0.82rem"}}><span>{m}</span><span style={{fontWeight:700}}>€{v}</span></div>
          ))}
        </>)}
        <div style={{fontSize:"0.62rem",letterSpacing:"0.22em",textTransform:"uppercase",color:"#888",marginBottom:8,borderTop:"1px solid #ddd",paddingTop:12,marginTop:12}}>{L.paidServices} ({confirmed.length})</div>
        {confirmed.sort((a,b)=>a.date.localeCompare(b.date)||a.time.localeCompare(b.time)).map(b=>(
          <div key={b.id} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:"1px solid #f0f0f0",fontSize:"0.78rem"}}>
            <div><span style={{fontWeight:600}}>{b.name}</span><span style={{color:"#888",marginLeft:6}}>{svcName(svc(b.serviceId),lang)}</span></div>
            <div style={{textAlign:"right"}}><div style={{fontSize:"0.7rem",color:"#888"}}>{b.date} {b.time}</div><div style={{fontWeight:700,color:"#4a8a5f"}}>€{svc(b.serviceId)?.price} <span style={{fontSize:"0.62rem",color:"#888"}}>({b.payMethod})</span></div></div>
          </div>
        ))}
        {pending.length>0&&(<>
          <div style={{fontSize:"0.62rem",letterSpacing:"0.22em",textTransform:"uppercase",color:"#9e4040",marginBottom:8,borderTop:"1px solid #ddd",paddingTop:12,marginTop:12}}>⚠ {L.unconfirmedPayment} ({pending.length})</div>
          {pending.map(b=>(
            <div key={b.id} style={{display:"flex",justifyContent:"space-between",padding:"5px 0",borderBottom:"1px solid #f0f0f0",fontSize:"0.78rem"}}>
              <div><span style={{fontWeight:600}}>{b.name}</span><span style={{color:"#888",marginLeft:6}}>{svcName(svc(b.serviceId),lang)}</span></div>
              <div style={{textAlign:"right"}}><div style={{fontSize:"0.7rem",color:"#888"}}>{b.date} {b.time}</div><div style={{fontWeight:700,color:"#9e4040"}}>€{svc(b.serviceId)?.price} — {L.unconfirmedPayment}</div></div>
            </div>
          ))}
        </>)}
        {cancelled.length>0&&(<>
          <div style={{fontSize:"0.62rem",letterSpacing:"0.22em",textTransform:"uppercase",color:"#888",marginBottom:8,borderTop:"1px solid #ddd",paddingTop:12,marginTop:12}}>{L.cancelled} ({cancelled.length})</div>
          {cancelled.map(b=>(
            <div key={b.id} style={{display:"flex",justifyContent:"space-between",padding:"4px 0",fontSize:"0.75rem",color:"#999"}}><span>{b.name} · {svcName(svc(b.serviceId),lang)}</span><span>{b.date} {b.time}</span></div>
          ))}
        </>)}
        <div style={{marginTop:18,paddingTop:12,borderTop:"2px solid #111",textAlign:"center",fontSize:"0.66rem",color:"#888"}}>LC.84 BARBER VISION · {NOW.getDate()} {LANGS[lang].months[NOW.getMonth()]} {NOW.getFullYear()}</div>
        <div style={{display:"flex",gap:8,marginTop:16}}>
          <button onClick={()=>window.print()} style={{flex:1,padding:"11px",background:"#111",color:"#fff",border:"none",borderRadius:4,cursor:"pointer",fontSize:"0.68rem",letterSpacing:"0.2em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",fontWeight:700}}>🖨 {L.printBtn}</button>
          <button onClick={onClose} style={{padding:"11px 14px",background:"transparent",color:"#666",border:"1px solid #ddd",borderRadius:4,cursor:"pointer",fontSize:"0.68rem",fontFamily:"'Josefin Sans',sans-serif"}}>{L.close}</button>
        </div>
      </div>
    </div>
  );
}

function BReports({bookings,setBookings,services,barber,lang}){
  const L=LANGS[lang].t;
  const svc=id=>services.find(s=>s.id===id);
  const [period,setPeriod]=useState("today");
  const [confirmModal,setConfirmModal]=useState(null);
  const [printModal,setPrintModal]=useState(null);
  const [alertsOpen,setAlertsOpen]=useState(true);

  const myBk=useMemo(()=>bookings.filter(b=>b.barberId===barber.id&&!b.blocked),[bookings,barber]);

  const periodBk=useMemo(()=>{
    const t=new Date(TODAY+"T12:00:00");
    return myBk.filter(b=>{
      const d=new Date(b.date+"T12:00:00");
      if(period==="today") return b.date===TODAY;
      if(period==="week")  return d>=new Date(t.getTime()-6*86400000)&&d<=t;
      if(period==="month") return d.getMonth()===t.getMonth()&&d.getFullYear()===t.getFullYear();
      return true;
    });
  },[myBk,period]);

  const confirmed=useMemo(()=>periodBk.filter(b=>b.status==="concluído"&&b.paid),[periodBk]);
  const pending  =useMemo(()=>periodBk.filter(b=>b.status==="concluído"&&!b.paid),[periodBk]);
  const scheduled=useMemo(()=>periodBk.filter(b=>b.status==="confirmado"&&b.date>=TODAY),[periodBk]);
  const cancelled=useMemo(()=>periodBk.filter(b=>b.status==="cancelado"),[periodBk]);

  // all unconfirmed payments across all time for this barber (not just period)
  const allPending=useMemo(()=>myBk.filter(b=>b.status==="concluído"&&!b.paid),[myBk]);

  const totalConfirmed=confirmed.reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);
  const totalPending  =pending.reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);
  const totalScheduled=scheduled.reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);

  const byMethod=useMemo(()=>{
    const m={};confirmed.forEach(b=>{const pm=b.payMethod||"Outro";m[pm]=(m[pm]||0)+(svc(b.serviceId)?.price||0);});
    return Object.entries(m).sort((a,b)=>b[1]-a[1]);
  },[confirmed]);

  const chartDays=useMemo(()=>Array.from({length:7}).map((_,i)=>{
    const d=new Date(Date.now()-(6-i)*86400000),str=fmt(d);
    const rev=myBk.filter(b=>b.date===str&&b.status==="concluído"&&b.paid).reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);
    return{label:LANGS[lang].wdays[d.getDay()],str,rev};
  }),[myBk,lang]);
  const maxRev=Math.max(...chartDays.map(d=>d.rev),1);

  const svcBreakdown=useMemo(()=>{
    const m={};confirmed.forEach(b=>{const s=svc(b.serviceId);if(!s)return;if(!m[s.id])m[s.id]={name:svcName(s,lang),count:0,total:0};m[s.id].count++;m[s.id].total+=s.price;});
    return Object.values(m).sort((a,b)=>b.total-a.total);
  },[confirmed]);
  const maxSvc=Math.max(...svcBreakdown.map(s=>s.total),1);

  const confirmPayment=(id,method)=>{
    setBookings(p=>p.map(b=>b.id===id?{...b,paid:true,payMethod:method}:b));
    setConfirmModal(null);
  };

  const PERIODS=[{id:"today",l:L.today},{id:"week",l:L.week},{id:"month",l:LANGS[lang].months[NOW.getMonth()].slice(0,3)},{id:"all",l:L.all}];

  const printBk=(type)=>myBk.filter(b=>{
    const d=new Date(b.date+"T12:00:00"),t=new Date(TODAY+"T12:00:00");
    if(type==="today")return b.date===TODAY;
    return d.getMonth()===t.getMonth()&&d.getFullYear()===t.getFullYear();
  });

  return(
    <div style={{padding:"0 20px"}}>

      {/* ⚠️ GLOBAL ALERT — all unconfirmed payments */}
      {allPending.length>0&&(
        <div style={{background:T.redLo,border:`1px solid ${T.red}`,borderRadius:8,marginBottom:16,overflow:"hidden"}}>
          <div onClick={()=>setAlertsOpen(a=>!a)} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px 14px",cursor:"pointer"}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <span>⚠</span>
              <div>
                <div style={{fontSize:"0.85rem",color:T.red,fontWeight:600}}>{allPending.length} {L.servicesUnconfirmed}</div>
                <div style={{fontSize:"0.68rem",color:T.red,opacity:0.8,marginTop:1}}>€{allPending.reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0)} {L.pendingRev}</div>
              </div>
            </div>
            <span style={{color:T.red,fontSize:"0.8rem"}}>{alertsOpen?"▲":"▼"}</span>
          </div>
          {alertsOpen&&(
            <div style={{borderTop:`1px solid ${T.red}44`}}>
              {allPending.sort((a,b)=>b.date.localeCompare(a.date)).map(b=>(
                <div key={b.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 14px",borderBottom:`1px solid ${T.red}22`}}>
                  <div>
                    <div style={{fontSize:"0.88rem",color:T.light,fontWeight:500}}>{b.name}</div>
                    <div style={{fontSize:"0.68rem",color:T.silver,marginTop:2}}>{svcName(svc(b.serviceId),lang)} · {dateLabel(b.date,lang)} {b.time}h</div>
                  </div>
                  <div style={{textAlign:"right",flexShrink:0,marginLeft:12}}>
                    <div style={{fontSize:"0.9rem",color:T.red,fontWeight:700,marginBottom:4}}>€{svc(b.serviceId)?.price}</div>
                    <button onClick={()=>setConfirmModal(b)} style={{padding:"4px 10px",background:T.gold,color:"#000",border:"none",borderRadius:3,cursor:"pointer",fontSize:"0.6rem",letterSpacing:"0.12em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",fontWeight:700}}>{L.toConfirm}</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Period tabs */}
      <div style={{display:"flex",gap:4,marginBottom:16}}>
        {PERIODS.map(p=>(
          <button key={p.id} onClick={()=>setPeriod(p.id)} style={{flex:1,padding:"8px 4px",borderRadius:4,cursor:"pointer",fontSize:"0.62rem",letterSpacing:"0.12em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",fontWeight:period===p.id?700:400,background:period===p.id?T.gold:"transparent",color:period===p.id?"#000":T.silver,border:`1px solid ${period===p.id?T.gold:T.border}`}}>{p.l}</button>
        ))}
      </div>

      {/* Summary */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:16}}>
        <div style={{background:T.card,border:`1px solid ${T.green}44`,borderRadius:7,padding:"13px 14px",gridColumn:"1/-1"}}>
          <Lbl style={{marginBottom:4,color:T.green}}>{L.confirmedRev}</Lbl>
          <div style={{fontSize:"2rem",color:T.green,fontWeight:700,lineHeight:1}}>€{totalConfirmed}</div>
          <div style={{fontSize:"0.68rem",color:T.silver,marginTop:4}}>{confirmed.length} {L.paidConfirmedCount}</div>
        </div>
        <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"12px 13px"}}>
          <Lbl style={{marginBottom:3,color:T.red}}>{L.pendingPayment}</Lbl>
          <div style={{fontSize:"1.4rem",color:T.red,fontWeight:700,lineHeight:1}}>€{totalPending}</div>
          <div style={{fontSize:"0.64rem",color:T.silver,marginTop:3}}>{pending.length} {L.unconfirmedCount}</div>
        </div>
        <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"12px 13px"}}>
          <Lbl style={{marginBottom:3}}>{L.scheduledLabel}</Lbl>
          <div style={{fontSize:"1.4rem",color:T.gold,fontWeight:700,lineHeight:1}}>€{totalScheduled}</div>
          <div style={{fontSize:"0.64rem",color:T.silver,marginTop:3}}>{scheduled.length} {L.futureCount}</div>
        </div>
      </div>

      {/* Print buttons */}
      <div style={{display:"flex",gap:8,marginBottom:16}}>
        <Btn variant="ghost" style={{flex:1,padding:"8px 6px",fontSize:"0.58rem"}} onClick={()=>setPrintModal("today")}>🖨 {L.printToday} 🖨</Btn>
        <Btn variant="ghost" style={{flex:1,padding:"8px 6px",fontSize:"0.58rem"}} onClick={()=>setPrintModal("month")}>🖨 {L.printMonth} 🖨</Btn>
      </div>

      {/* Payment method breakdown */}
      {byMethod.length>0&&(<>
        <Lbl style={{marginBottom:9}}>{L.byMethod}</Lbl>
        <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"13px",marginBottom:16}}>
          {byMethod.map(([m,v])=>{const pct=Math.round((v/totalConfirmed)*100);return(
            <div key={m} style={{marginBottom:9}}>
              <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:"0.84rem",color:T.light}}>{m}</span><span style={{fontSize:"0.8rem",color:T.gold}}>€{v} <span style={{color:T.silver,fontSize:"0.7rem"}}>({pct}%)</span></span></div>
              <div style={{height:5,background:T.muted,borderRadius:3,overflow:"hidden"}}><div style={{height:"100%",background:T.gold,borderRadius:3,width:`${pct}%`}}/></div>
            </div>
          );})}
        </div>
      </>)}

      {/* 7-day chart */}
      <Lbl style={{marginBottom:9}}>{L.last7}</Lbl>
      <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"14px",marginBottom:16}}>
        <div style={{display:"flex",alignItems:"flex-end",gap:6,height:90}}>
          {chartDays.map(d=>(
            <div key={d.str} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
              <div style={{fontSize:"0.6rem",color:d.rev>0?T.green:T.silver,fontFamily:"'Josefin Sans',sans-serif",fontWeight:700}}>{d.rev>0?`€${d.rev}`:""}</div>
              <div style={{flex:1,width:"100%",display:"flex",alignItems:"flex-end"}}>
                <div style={{width:"100%",background:d.str===TODAY?T.green:T.greenLo,borderRadius:"3px 3px 0 0",height:`${Math.max((d.rev/maxRev)*100,2)}%`,minHeight:d.rev>0?8:2,border:d.str===TODAY?`1px solid ${T.green}`:`1px solid ${T.green}44`}}/>
              </div>
              <div style={{fontSize:"0.54rem",color:d.str===TODAY?T.green:T.silver,fontFamily:"'Josefin Sans',sans-serif"}}>{d.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Service breakdown */}
      {svcBreakdown.length>0&&(<>
        <Lbl style={{marginBottom:9}}>{L.byService}</Lbl>
        {svcBreakdown.map(s=>(
          <div key={s.name} style={{marginBottom:9}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}><span style={{fontSize:"0.84rem",color:T.light}}>{s.name}</span><span style={{fontSize:"0.78rem",color:T.gold}}>€{s.total} · {s.count}×</span></div>
            <div style={{height:5,background:T.muted,borderRadius:3,overflow:"hidden"}}><div style={{height:"100%",background:T.gold,borderRadius:3,width:`${(s.total/maxSvc)*100}%`}}/></div>
          </div>
        ))}
      </>)}

      {/* Full register */}
      <div style={{marginTop:18}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <Lbl style={{margin:0}}>{L.records} — {PERIODS.find(p=>p.id===period)?.l}</Lbl>
          <span style={{fontSize:"0.66rem",color:T.silver,fontFamily:"'Josefin Sans',sans-serif"}}>{periodBk.length} {L.total}</span>
        </div>

        {confirmed.length>0&&(<div style={{marginBottom:14}}>
          <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:8}}><div style={{width:7,height:7,borderRadius:"50%",background:T.green}}/><Lbl style={{margin:0,color:T.green}}>{L.paidAndConfirmed} ({confirmed.length})</Lbl></div>
          {confirmed.sort((a,b)=>b.date.localeCompare(a.date)).map(b=>(
            <div key={b.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 12px",marginBottom:5,background:T.card,border:`1px solid ${T.green}33`,borderRadius:5}}>
              <div style={{minWidth:0}}><div style={{fontSize:"0.86rem",color:T.white,fontWeight:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.name}</div><div style={{fontSize:"0.66rem",color:T.silver,marginTop:2}}>{svcName(svc(b.serviceId),lang)} · {dateLabel(b.date,lang)} {b.time}h</div></div>
              <div style={{textAlign:"right",flexShrink:0,marginLeft:10}}><div style={{fontSize:"0.88rem",color:T.green,fontWeight:700}}>€{svc(b.serviceId)?.price}</div><div style={{fontSize:"0.58rem",color:T.silver,marginTop:2,fontFamily:"'Josefin Sans',sans-serif"}}>{b.payMethod}</div></div>
            </div>
          ))}
        </div>)}

        {pending.length>0&&(<div style={{marginBottom:14}}>
          <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:8}}><div style={{width:7,height:7,borderRadius:"50%",background:T.red}}/><Lbl style={{margin:0,color:T.red}}>{L.serviceDonePaymentPending} ({pending.length})</Lbl></div>
          {pending.map(b=>(
            <div key={b.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 12px",marginBottom:5,background:T.redLo,border:`1px solid ${T.red}44`,borderRadius:5}}>
              <div style={{minWidth:0}}><div style={{fontSize:"0.86rem",color:T.white,fontWeight:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.name}</div><div style={{fontSize:"0.66rem",color:T.silver,marginTop:2}}>{svcName(svc(b.serviceId),lang)} · {dateLabel(b.date,lang)} {b.time}h</div></div>
              <div style={{textAlign:"right",flexShrink:0,marginLeft:10}}><div style={{fontSize:"0.88rem",color:T.red,fontWeight:700}}>€{svc(b.serviceId)?.price}</div><button onClick={()=>setConfirmModal(b)} style={{marginTop:4,padding:"3px 9px",background:T.gold,color:"#000",border:"none",borderRadius:3,cursor:"pointer",fontSize:"0.56rem",letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",fontWeight:700}}>{L.toConfirm}</button></div>
            </div>
          ))}
        </div>)}

        {scheduled.length>0&&(<div style={{marginBottom:14}}>
          <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:8}}><div style={{width:7,height:7,borderRadius:"50%",background:T.gold}}/><Lbl style={{margin:0}}>{L.scheduledCount} ({scheduled.length})</Lbl></div>
          {scheduled.sort((a,b)=>a.date.localeCompare(b.date)).map(b=>(
            <div key={b.id} style={{display:"flex",justifyContent:"space-between",padding:"8px 12px",marginBottom:5,background:T.card,border:`1px solid ${T.border}`,borderRadius:5,opacity:0.7}}>
              <div style={{minWidth:0}}><div style={{fontSize:"0.84rem",color:T.white,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{b.name}</div><div style={{fontSize:"0.64rem",color:T.silver,marginTop:2}}>{svcName(svc(b.serviceId),lang)} · {dateLabel(b.date,lang)} {b.time}h</div></div>
              <div style={{fontSize:"0.86rem",color:T.gold,flexShrink:0,marginLeft:10}}>€{svc(b.serviceId)?.price}</div>
            </div>
          ))}
        </div>)}

        {cancelled.length>0&&(<div style={{marginBottom:14}}>
          <div style={{display:"flex",alignItems:"center",gap:7,marginBottom:8}}><div style={{width:7,height:7,borderRadius:"50%",background:T.silver}}/><Lbl style={{margin:0}}>{L.cancelled} ({cancelled.length})</Lbl></div>
          {cancelled.map(b=>(
            <div key={b.id} style={{display:"flex",justifyContent:"space-between",padding:"7px 12px",marginBottom:5,background:T.card,border:`1px solid ${T.border}`,borderRadius:5,opacity:0.45}}>
              <div><div style={{fontSize:"0.82rem",color:T.mid,textDecoration:"line-through"}}>{b.name}</div><div style={{fontSize:"0.64rem",color:T.silver}}>{svcName(svc(b.serviceId),lang)} · {dateLabel(b.date,lang)} {b.time}h</div></div>
              <div style={{fontSize:"0.8rem",color:T.silver,textDecoration:"line-through",flexShrink:0,marginLeft:10}}>€{svc(b.serviceId)?.price}</div>
            </div>
          ))}
        </div>)}

        {periodBk.length===0&&<div style={{textAlign:"center",padding:"32px 0",color:T.silver,fontSize:"0.86rem"}}>{L.noRecordsPeriod}</div>}
      </div>

      {confirmModal&&<ConfirmPayModal booking={confirmModal} svc={svc} onConfirm={confirmPayment} onClose={()=>setConfirmModal(null)} lang={lang}/>}
      {printModal&&<PrintReport bookings={printBk(printModal)} label={printModal==="today"?L.today:LANGS[lang].months[NOW.getMonth()]} barberName={barber.name} svc={svc} onClose={()=>setPrintModal(null)} lang={lang}/>}
    </div>
  );
}

function BSchedule({barber,setBarbers,lang}){
  const L=LANGS[lang].t;
  const [f,setF]=useState({...barber.schedule});
  const toggleDay=d=>setF(p=>({...p,workDays:p.workDays.includes(d)?p.workDays.filter(x=>x!==d):[...p.workDays,d].sort()}));
  const save=()=>setBarbers(p=>p.map(b=>b.id===barber.id?{...b,schedule:f}:b));
  return(
    <div style={{padding:"0 20px"}}>
      <Lbl style={{marginBottom:10}}>{L.workDays}</Lbl>
      <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:18}}>
        {LANGS[lang].wdaysF.map((d,i)=>{const on=f.workDays.includes(i);return(<button key={i} onClick={()=>toggleDay(i)} style={{padding:"7px 11px",borderRadius:4,cursor:"pointer",fontSize:"0.66rem",letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",background:on?T.goldLo:"transparent",color:on?T.gold:T.silver,border:`1px solid ${on?T.gold:T.border}`}}>{d.slice(0,3)}</button>);})}
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:18}}>
        <div><Lbl>{L.startHour}</Lbl><Sel value={f.startHour} onChange={e=>setF(p=>({...p,startHour:e.target.value}))}>{ALL_HOURS.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
        <div><Lbl>{L.endHour}</Lbl><Sel value={f.endHour} onChange={e=>setF(p=>({...p,endHour:e.target.value}))}>{ALL_HOURS.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:18}}>
        <div><Lbl>{L.breakStartLabel}</Lbl><Sel value={f.breakStart||""} onChange={e=>setF(p=>({...p,breakStart:e.target.value}))}><option value="">{L.noBreakOption}</option>{ALL_HOURS.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
        <div><Lbl>{L.breakEndLabel}</Lbl><Sel value={f.breakEnd||""} onChange={e=>setF(p=>({...p,breakEnd:e.target.value}))}><option value="">{L.noBreakOption}</option>{ALL_HOURS.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
      </div>
      <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"12px 13px",marginBottom:16}}>
        <Lbl style={{marginBottom:7}}>{L.generatedSlots}</Lbl>
        <div style={{display:"flex",flexWrap:"wrap",gap:5}}>{getBarberHours({schedule:f}).map(h=><span key={h} style={{fontSize:"0.7rem",color:T.mid,padding:"3px 7px",background:T.muted,borderRadius:3,fontFamily:"'Josefin Sans',sans-serif"}}>{h}</span>)}</div>
      </div>
      <Btn variant="gold" style={{width:"100%"}} onClick={save}>{L.saveSchedule}</Btn>
    </div>
  );
}

function BProfile({barber,setBarbers,shopId,onLogout,lang}){
  const L=LANGS[lang].t;
  const [edit,setEdit]=useState(false);
  const [f,setF]=useState({...barber});
  const [photoBusy,setPhotoBusy]=useState(false);
  const [photoErr,setPhotoErr]=useState("");
  const u=k=>e=>setF(p=>({...p,[k]:e.target.value}));
  const save=()=>{if(f.pinNew){f.pin=f.pinNew;delete f.pinNew;}setBarbers(p=>p.map(b=>b.id===barber.id?f:b));setEdit(false);};
  const uploadPhoto=async(file)=>{
    if(!file||!shopId)return;
    if(file.size>5*1024*1024){setPhotoErr(L.photoTooLarge);return;}
    setPhotoBusy(true);setPhotoErr("");
    const ext=file.name.split(".").pop();
    const path=`${shopId}/barbeiro-${barber.id}-${Date.now()}.${ext}`;
    const{error}=await supabase.storage.from("salon-photos").upload(path,file,{upsert:true});
    if(error){setPhotoBusy(false);setPhotoErr(L.uploadFailed);return;}
    const{data}=supabase.storage.from("salon-photos").getPublicUrl(path);
    setBarbers(p=>p.map(b=>b.id===barber.id?{...b,photoUrl:data.publicUrl}:b));
    setF(p=>({...p,photoUrl:data.publicUrl}));
    setPhotoBusy(false);
  };
  return(
    <div style={{padding:"0 20px"}}>
      <div style={{textAlign:"center",marginBottom:22}}>
        <Avatar barber={barber} size={62}/>
        <div style={{fontSize:"1.15rem",color:T.white,fontWeight:600,marginTop:11}}>{barber.name}</div>
        <div style={{fontSize:"0.7rem",color:T.silver,marginTop:2}}>{barber.role}</div>
        {edit&&(
          <label style={{display:"inline-block",marginTop:10}}>
            <input type="file" accept="image/*" style={{display:"none"}} onChange={e=>uploadPhoto(e.target.files?.[0])}/>
            <div style={{padding:"6px 14px",background:T.card,border:`1px dashed ${T.border}`,borderRadius:6,color:T.silver,fontSize:"0.72rem",cursor:"pointer"}}>
              {photoBusy?L.uploading:L.changeProfilePhoto}
            </div>
          </label>
        )}
        {photoErr&&<div style={{color:T.red,fontSize:"0.72rem",marginTop:6}}>{photoErr}</div>}
      </div>
      {!edit?(
        <>
          {[[L.nameLabel,barber.name],[L.role,barber.role],[L.phone,barber.phone],[L.bio,barber.bio]].map(([l,v])=>(
            <div key={l} style={{padding:"9px 0",borderBottom:`1px solid ${T.border}`}}><Lbl style={{marginBottom:3}}>{l}</Lbl><div style={{fontSize:"0.88rem",color:T.light,lineHeight:1.5}}>{v}</div></div>
          ))}
          <div style={{marginTop:16,display:"flex",gap:8}}>
            <Btn variant="ghost" style={{flex:1}} onClick={()=>{setF({...barber});setEdit(true);}}>{L.edit}</Btn>
            <Btn variant="danger" onClick={onLogout}>{L.logout}</Btn>
          </div>
        </>
      ):(
        <>
          {[[L.nameLabel,"name","text"],[L.role,"role","text"],[L.phone,"phone","tel"]].map(([l,k,t])=>(
            <div key={k} style={{marginBottom:11}}><Lbl>{l}</Lbl><Inp type={t} value={f[k]} onChange={u(k)}/></div>
          ))}
          <div style={{marginBottom:11}}><Lbl>{L.bio}</Lbl><Txta rows={2} value={f.bio} onChange={u("bio")}/></div>
          <div style={{marginBottom:14}}><Lbl>{L.newPin}</Lbl><Inp type="password" placeholder={L.keepPin} value={f.pinNew||""} onChange={e=>setF(p=>({...p,pinNew:e.target.value}))}/></div>
          <div style={{display:"flex",gap:8}}><Btn variant="gold" style={{flex:1}} onClick={save}>{L.save}</Btn><Btn variant="ghost" onClick={()=>setEdit(false)}>{L.cancel}</Btn></div>
        </>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// ADMIN + CLIENT (simplified but complete)
// ══════════════════════════════════════════════════════════════════════════════
function AdminPanel({bookings,barbers,setBarbers,services,setServices,shop,setShop,shopId,mySlug,onLogout,lang,embedded,barber}){
  const L=LANGS[lang].t;
  const [tab,setTab]=useState("overview");
  const [modal,setModal]=useState(null);
  const [bf,setBf]=useState({});
  const shopLink=mySlug?`${window.location.origin}${window.location.pathname}?loja=${mySlug}`:"";
  const [linkCopied,setLinkCopied]=useState(false);
  const copyShopLink=async()=>{
    if(!shopLink)return;
    try{await navigator.clipboard.writeText(shopLink);}catch(e){/* alguns browsers antigos podem bloquear, o link já fica visível para copiar à mão */}
    setLinkCopied(true);setTimeout(()=>setLinkCopied(false),2000);
  };
  const svc=id=>services.find(s=>s.id===id);
  const totalRev=bookings.filter(b=>b.paid).reduce((s,b)=>s+(svc(b.serviceId)?.price||0),0);
  const todayAll=bookings.filter(b=>b.date===TODAY&&!b.blocked);
  const openAddBarber=()=>{setBf({id:null,name:"",role:"Barbeiro",pin:"",phone:"",bio:"",avatar:"",color:T.gold,photoUrl:"",schedule:{workDays:[1,2,3,4,5],startHour:"09:00",endHour:"18:00",breakStart:"",breakEnd:""},active:true});setModal("barber");};
  const saveBarber=()=>{if(!bf.name.trim()||!bf.pin.trim())return;if(bf.id)setBarbers(p=>p.map(b=>b.id===bf.id?bf:b));else setBarbers(p=>[...p,{...bf,id:mkId(),avatar:bf.name.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase()}]);setModal(null);};
  const [barberPhotoBusy,setBarberPhotoBusy]=useState(false);
  const [barberPhotoErr,setBarberPhotoErr]=useState("");
  const uploadBarberPhoto=async(file)=>{
    if(!file||!shopId)return;
    if(file.size>5*1024*1024){setBarberPhotoErr(L.photoTooLarge);return;}
    setBarberPhotoBusy(true);setBarberPhotoErr("");
    const ext=file.name.split(".").pop();
    const path=`${shopId}/barbeiro-${bf.id||"novo"}-${Date.now()}.${ext}`;
    const{error}=await supabase.storage.from("salon-photos").upload(path,file,{upsert:true});
    if(error){setBarberPhotoBusy(false);setBarberPhotoErr(L.uploadFailed);return;}
    const{data}=supabase.storage.from("salon-photos").getPublicUrl(path);
    setBf(p=>({...p,photoUrl:data.publicUrl}));
    setBarberPhotoBusy(false);
  };
  const TABS=[{id:"overview",l:L.adminOverview},{id:"barbers",l:L.adminBarbersTab},{id:"services",l:L.services},{id:"shop",l:L.barbershop},{id:"orders",l:L.ordersTabLabel},{id:"catalog",l:L.catalogTabLabel}];
  const [products,setProducts]=useState([]);
  const [productsLoading,setProductsLoading]=useState(true);
  const [viewProduct,setViewProduct]=useState(null);
  const [prodName,setProdName]=useState("");
  const [prodPrice,setProdPrice]=useState("");
  const [prodPhotoFile,setProdPhotoFile]=useState(null);
  const [prodPhotoPreview,setProdPhotoPreview]=useState("");
  const [prodBusy,setProdBusy]=useState(false);
  const [prodErr,setProdErr]=useState("");
  useEffect(()=>{
    if(!shopId)return;
    let active=true;
    (async()=>{
      const{data}=await supabase.from("products").select("*").eq("shop_id",shopId).order("created_at",{ascending:false});
      if(active){setProducts(data||[]);setProductsLoading(false);}
    })();
    return()=>{active=false;};
  },[shopId]);
  const stageProdPhoto=file=>{
    if(!file)return;
    if(file.size>5*1024*1024){setProdErr(L.photoTooLarge);return;}
    setProdErr("");
    setProdPhotoFile(file);
    setProdPhotoPreview(URL.createObjectURL(file));
  };
  const addProduct=async()=>{
    const cleanName=prodName.trim();
    if(!cleanName)return;
    setProdErr("");
    let photo_url=null;
    if(prodPhotoFile){
      setProdBusy(true);
      const ext=prodPhotoFile.name.split(".").pop();
      const path=`${shopId}/produto-${Date.now()}.${ext}`;
      const{error:upErr}=await supabase.storage.from("salon-photos").upload(path,prodPhotoFile,{upsert:true});
      if(upErr){setProdErr(L.uploadFailed);setProdBusy(false);return;}
      photo_url=supabase.storage.from("salon-photos").getPublicUrl(path).data.publicUrl;
      setProdBusy(false);
    }
    const priceNum=prodPrice.trim()?parseFloat(prodPrice.replace(",","."))||null:null;
    const{data,error}=await supabase.from("products").insert({shop_id:shopId,name:cleanName,price:priceNum,photo_url}).select().single();
    if(!error&&data){
      setProducts(p=>[data,...p]);setProdName("");setProdPrice("");setProdPhotoFile(null);setProdPhotoPreview("");
    } else if(error){setProdErr(L.uploadFailed);}
  };
  const updateProductPrice=async(id,val)=>{
    setProducts(p=>p.map(x=>x.id===id?{...x,price:val}:x));
    const priceNum=String(val).trim()?parseFloat(String(val).replace(",","."))||null:null;
    await supabase.from("products").update({price:priceNum}).eq("id",id);
  };
  const toggleProductAvailable=async(prod)=>{
    const{error}=await supabase.from("products").update({available:!prod.available}).eq("id",prod.id);
    if(!error)setProducts(p=>p.map(x=>x.id===prod.id?{...x,available:!prod.available}:x));
  };
  const deleteProduct=async(id)=>{
    const{error}=await supabase.from("products").delete().eq("id",id);
    if(!error)setProducts(p=>p.filter(x=>x.id!==id));
  };
  const [orders,setOrders]=useState([]);
  const [ordersLoading,setOrdersLoading]=useState(true);
  const [orderText,setOrderText]=useState("");
  const [orderPhotoFile,setOrderPhotoFile]=useState(null);
  const [orderPhotoPreview,setOrderPhotoPreview]=useState("");
  const [orderPhotoBusy,setOrderPhotoBusy]=useState(false);
  const [orderErr,setOrderErr]=useState("");
  useEffect(()=>{
    if(!shopId)return;
    let active=true;
    (async()=>{
      const{data}=await supabase.from("product_orders").select("*").eq("shop_id",shopId).order("created_at",{ascending:false});
      if(active){setOrders(data||[]);setOrdersLoading(false);}
    })();
    return()=>{active=false;};
  },[shopId]);
  const stageOrderPhoto=file=>{
    if(!file)return;
    if(file.size>5*1024*1024){setOrderErr(L.photoTooLarge);return;}
    setOrderErr("");
    setOrderPhotoFile(file);
    setOrderPhotoPreview(URL.createObjectURL(file));
  };
  const addOrder=async()=>{
    const clean=orderText.trim();
    if(!clean&&!orderPhotoFile)return;
    setOrderErr("");
    let photo_url=null;
    if(orderPhotoFile){
      setOrderPhotoBusy(true);
      const ext=orderPhotoFile.name.split(".").pop();
      const path=`${shopId}/encomenda-${Date.now()}.${ext}`;
      const{error:upErr}=await supabase.storage.from("salon-photos").upload(path,orderPhotoFile,{upsert:true});
      if(upErr){setOrderErr(L.uploadFailed);setOrderPhotoBusy(false);return;}
      photo_url=supabase.storage.from("salon-photos").getPublicUrl(path).data.publicUrl;
      setOrderPhotoBusy(false);
    }
    const{data,error}=await supabase.from("product_orders").insert({shop_id:shopId,text:clean||null,photo_url}).select().single();
    if(!error&&data){
      setOrders(p=>[data,...p]);setOrderText("");setOrderPhotoFile(null);setOrderPhotoPreview("");
    } else if(error){setOrderErr(L.uploadFailed);}
  };
  const toggleOrderDone=async(o)=>{
    const{error}=await supabase.from("product_orders").update({done:!o.done}).eq("id",o.id);
    if(!error)setOrders(p=>p.map(x=>x.id===o.id?{...x,done:!o.done}:x));
  };
  const deleteOrder=async(id)=>{
    const{error}=await supabase.from("product_orders").delete().eq("id",id);
    if(!error)setOrders(p=>p.filter(x=>x.id!==id));
  };
  const [photoBusy,setPhotoBusy]=useState(false);
  const [photoErr,setPhotoErr]=useState("");
  const uploadPhoto=async(file)=>{
    if(!file||!shopId)return;
    if(file.size>5*1024*1024){setPhotoErr(L.photoTooLarge);return;}
    setPhotoBusy(true);setPhotoErr("");
    const ext=file.name.split(".").pop();
    const path=`${shopId}/foto-${Date.now()}.${ext}`;
    const{error}=await supabase.storage.from("salon-photos").upload(path,file,{upsert:true});
    if(error){setPhotoBusy(false);setPhotoErr(L.uploadFailed);return;}
    const{data}=supabase.storage.from("salon-photos").getPublicUrl(path);
    setShop(p=>({...p,photoUrl:data.publicUrl}));
    setPhotoBusy(false);
  };
  const [delOpen,setDelOpen]=useState(false);
  const [shopSaved,setShopSaved]=useState(false);
  const [delName,setDelName]=useState("");
  const [delPass,setDelPass]=useState("");
  const [delErr,setDelErr]=useState("");
  const [delBusy,setDelBusy]=useState(false);
  const doDeleteShop=async()=>{
    setDelErr("");
    if(delName.trim()!==(shop.name||"").trim()){setDelErr("O nome não corresponde ao nome da barbearia.");return;}
    if(!delPass){setDelErr("Introduz a password para confirmar.");return;}
    setDelBusy(true);
    const{data,error}=await supabase.rpc("delete_owner_shop",{p_shop_id:shopId,p_password:delPass});
    setDelBusy(false);
    if(error||!data){setDelErr("Password incorreta ou não foi possível apagar.");return;}
    const url=new URL(window.location.href);
    url.searchParams.delete("loja");
    window.location.href=url.toString();
  };
  return(
    <div style={embedded?{width:"100%"}:{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",fontFamily:"'Cormorant Garamond',Georgia,serif",color:T.light}}>
      {!embedded&&<style>{GS}</style>}
      <header className="app-shell" style={embedded?{width:"100%"}:{width:"100%",maxWidth:520,padding:"14px 20px 0",borderBottom:`1px solid ${T.border}`,background:T.surface,position:"sticky",top:0,zIndex:10}}>
        {!embedded&&(<div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
          <div><div style={{fontFamily:"'Josefin Sans',sans-serif",fontSize:"0.88rem",letterSpacing:"0.15em",fontWeight:700,color:T.white}}>LC<span style={{color:T.gold}}>.</span>84 <span style={{color:T.silver,fontSize:"0.68rem"}}>Admin</span></div></div>
          <Btn variant="danger" style={{padding:"5px 10px",fontSize:"0.56rem"}} onClick={onLogout}>{L.logout}</Btn>
        </div>)}
        <div style={{display:"flex",overflowX:"auto",scrollbarWidth:"none"}}>{TABS.map(t=><button key={t.id} onClick={()=>setTab(t.id)} style={{padding:"8px 14px",background:"none",border:"none",borderBottom:`2px solid ${tab===t.id?T.gold:"transparent"}`,cursor:"pointer",color:tab===t.id?T.gold:T.silver,fontSize:"0.6rem",letterSpacing:"0.16em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",fontWeight:tab===t.id?700:400,whiteSpace:"nowrap"}}>{t.l}</button>)}</div>
      </header>
      <main className="app-shell" style={embedded?{width:"100%",padding:"14px 0 0"}:{width:"100%",maxWidth:520,flex:1,padding:"18px 20px 60px"}}>
        {tab==="overview"&&(<>
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:18}}>
            {[{l:L.totalBilled,v:`€${totalRev}`,c:T.gold},{l:L.barbersLabel,v:barbers.filter(b=>b.active).length,c:T.white},{l:L.todayAllLabel,v:todayAll.length,c:T.mid},{l:L.totalBookingsLabel,v:bookings.filter(b=>!b.blocked).length,c:T.mid}].map(s=>(
              <div key={s.l} style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"12px 13px"}}><Lbl style={{marginBottom:4}}>{s.l}</Lbl><div style={{fontSize:"1.45rem",color:s.c,fontWeight:600}}>{s.v}</div></div>
            ))}
          </div>
          <Lbl style={{marginBottom:10}}>{L.teamToday}</Lbl>
          {barbers.filter(b=>b.active).map(b=>{const bBk=bookings.filter(bk=>bk.barberId===b.id&&bk.date===TODAY&&!bk.blocked);const rev=bBk.filter(bk=>bk.paid).reduce((s,bk)=>s+(svc(bk.serviceId)?.price||0),0);return(
            <div key={b.id} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 13px",marginBottom:6,background:T.card,border:`1px solid ${T.border}`,borderRadius:6}}>
              <Avatar barber={b} size={36}/><div style={{flex:1}}><div style={{fontSize:"0.92rem",color:T.white,fontWeight:500}}>{b.name}</div><div style={{fontSize:"0.68rem",color:T.silver}}>{bBk.length} {L.bookingsTodayCount}</div></div>
              <div style={{textAlign:"right"}}><div style={{fontSize:"0.92rem",color:T.gold,fontWeight:600}}>€{rev}</div></div>
            </div>
          );})}
        </>)}
        {tab==="barbers"&&(<>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14}}><Lbl style={{margin:0}}>{barbers.length} {L.barbersCountSuffix}</Lbl><Btn variant="gold" style={{padding:"6px 13px"}} onClick={openAddBarber}>{L.addNew}</Btn></div>
          {barbers.map(b=>(
            <div key={b.id} onClick={()=>{setBf({...b});setModal("barber");}} style={{display:"flex",alignItems:"center",gap:11,padding:"12px 13px",marginBottom:7,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,opacity:b.active?1:0.45,cursor:"pointer"}}>
              <Avatar barber={b} size={36}/>
              <div style={{flex:1,minWidth:0}}><div style={{fontSize:"0.92rem",color:T.white,fontWeight:500}}>{b.name}</div><div style={{fontSize:"0.68rem",color:T.silver}}>{b.role}</div></div>
              <div style={{display:"flex",flexDirection:"column",gap:4,alignItems:"flex-end"}}>
                <button onClick={e=>{e.stopPropagation();setBarbers(p=>p.map(bb=>bb.id===b.id?{...bb,active:!bb.active}:bb));}} style={{background:b.active?T.greenLo:T.muted,border:`1px solid ${b.active?T.green:T.border}`,borderRadius:10,padding:"2px 8px",color:b.active?T.green:T.silver,fontSize:"0.54rem",cursor:"pointer",fontFamily:"'Josefin Sans',sans-serif"}}>{b.active?L.activeLabel:L.offLabel}</button>
                <button onClick={e=>{e.stopPropagation();setBf({...b});setModal("barber");}} style={{background:"none",border:"none",color:T.silver,cursor:"pointer",fontSize:"0.82rem"}}>✏</button>
              </div>
            </div>
          ))}
          {modal==="barber"&&<Modal onClose={()=>setModal(null)} title={bf.id?L.editBarberTitle:L.newBarberTitle}>
            <div style={{textAlign:"center",marginBottom:16}}>
              <Avatar barber={bf} size={64}/>
              <label style={{display:"inline-block",marginTop:9}}>
                <input type="file" accept="image/*" style={{display:"none"}} onChange={e=>uploadBarberPhoto(e.target.files?.[0])}/>
                <div style={{padding:"6px 14px",background:T.card,border:`1px dashed ${T.border}`,borderRadius:6,color:T.silver,fontSize:"0.72rem",cursor:"pointer"}}>
                  {barberPhotoBusy?L.uploading:bf.photoUrl?L.changePhoto:L.choosePhoto}
                </div>
              </label>
              {barberPhotoErr&&<div style={{color:T.red,fontSize:"0.7rem",marginTop:6}}>{barberPhotoErr}</div>}
            </div>
            {[[L.nameLabel,"name","text"],[L.role,"role","text"],[L.phone,"phone","tel"],[L.pinLabel,"pin","text"]].map(([l,k,t])=>(
              <div key={k} style={{marginBottom:10}}><Lbl>{l}</Lbl><Inp type={t} value={bf[k]||""} onChange={e=>setBf(p=>({...p,[k]:e.target.value}))}/></div>
            ))}
            <div style={{marginBottom:10}}><Lbl>{L.bio}</Lbl><Txta rows={2} value={bf.bio||""} onChange={e=>setBf(p=>({...p,bio:e.target.value}))}/></div>
            <Lbl style={{marginBottom:7}}>{L.colorLabel}</Lbl>
            <div style={{display:"flex",gap:8,marginBottom:12}}>{["#b8955a","#6a9eb8","#9e6a4a","#7a9e6a","#9a6a9e","#9e4a4a"].map(c=><div key={c} onClick={()=>setBf(p=>({...p,color:c}))} style={{width:26,height:26,borderRadius:"50%",background:c,cursor:"pointer",border:`2px solid ${bf.color===c?"#fff":"transparent"}`}}/>)}</div>
            <Lbl style={{marginBottom:7}}>{L.workDays}</Lbl>
            <div style={{display:"flex",gap:5,flexWrap:"wrap",marginBottom:11}}>{LANGS[lang].wdaysF.map((d,i)=>{const on=(bf.schedule?.workDays||[]).includes(i);return(<button key={i} onClick={()=>setBf(p=>({...p,schedule:{...p.schedule,workDays:on?p.schedule.workDays.filter(x=>x!==i):[...(p.schedule?.workDays||[]),i].sort()}}))} style={{padding:"5px 9px",borderRadius:4,cursor:"pointer",fontSize:"0.58rem",letterSpacing:"0.1em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",background:on?T.goldLo:"transparent",color:on?T.gold:T.silver,border:`1px solid ${on?T.gold:T.border}`}}>{d.slice(0,3)}</button>);})}</div>
            <div style={{display:"flex",gap:8,marginBottom:14}}>
              <div style={{flex:1}}><Lbl>{L.startHour}</Lbl><Sel value={bf.schedule?.startHour||"09:00"} onChange={e=>setBf(p=>({...p,schedule:{...p.schedule,startHour:e.target.value}}))}>{ALL_HOURS.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
              <div style={{flex:1}}><Lbl>{L.endHour}</Lbl><Sel value={bf.schedule?.endHour||"18:00"} onChange={e=>setBf(p=>({...p,schedule:{...p.schedule,endHour:e.target.value}}))}>{ALL_HOURS.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
            </div>
            <div style={{display:"flex",gap:8,marginBottom:14}}>
              <div style={{flex:1}}><Lbl>{L.breakStartLabel}</Lbl><Sel value={bf.schedule?.breakStart||""} onChange={e=>setBf(p=>({...p,schedule:{...p.schedule,breakStart:e.target.value}}))}><option value="">{L.noBreakOption}</option>{ALL_HOURS.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
              <div style={{flex:1}}><Lbl>{L.breakEndLabel}</Lbl><Sel value={bf.schedule?.breakEnd||""} onChange={e=>setBf(p=>({...p,schedule:{...p.schedule,breakEnd:e.target.value}}))}><option value="">{L.noBreakOption}</option>{ALL_HOURS.map(h=><option key={h} value={h}>{h}</option>)}</Sel></div>
            </div>
            <div style={{display:"flex",gap:8}}><Btn variant="gold" style={{flex:1}} onClick={saveBarber}>{L.save}</Btn>{bf.id&&<Btn variant="danger" onClick={()=>{
              const isLastOwner=bf.isOwner&&barbers.filter(b=>b.isOwner&&b.active!==false).length<=1;
              if(isLastOwner){setBf(p=>({...p,__lastOwnerErr:true}));return;}
              setBarbers(p=>p.filter(b=>b.id!==bf.id));setModal(null);
            }}>{L.delete}</Btn>}<Btn variant="ghost" onClick={()=>setModal(null)}>{L.close}</Btn></div>
          </Modal>}
        </>)}
        {tab==="services"&&(<>
          <ServicesAdmin services={services} setServices={setServices} lang={lang}/>
        </>)}
        {tab==="shop"&&(<>
          <div style={{marginBottom:18}}>
            <Lbl style={{marginBottom:8}}>{L.shopPhoto}</Lbl>
            {shop.photoUrl&&(
              <img src={shop.photoUrl} style={{width:"100%",height:150,objectFit:"contain",background:T.card,borderRadius:6,marginBottom:10,border:`1px solid ${T.border}`}}/>
            )}
            <label style={{display:"block"}}>
              <input type="file" accept="image/*" style={{display:"none"}} onChange={e=>uploadPhoto(e.target.files?.[0])}/>
              <div style={{padding:"10px",textAlign:"center",background:T.card,border:`1px dashed ${T.border}`,borderRadius:6,color:T.silver,fontSize:"0.78rem",cursor:"pointer"}}>
                {photoBusy?L.uploading:shop.photoUrl?L.changePhoto:L.choosePhoto}
              </div>
            </label>
            {photoErr&&<div style={{color:T.red,fontSize:"0.74rem",marginTop:6}}>{photoErr}</div>}
          </div>
          {[[L.nameLabel,"name","text"],[L.address,"address","text"],[L.phone,"phone","tel"],[L.adminPinLabel,"adminPin","text"]].map(([l,k,t])=>(
            <div key={k} style={{marginBottom:11}}><Lbl>{l}</Lbl><Inp type={t} value={shop[k]||""} onChange={e=>setShop(p=>({...p,[k]:e.target.value}))}/></div>
          ))}
          <div style={{marginBottom:14}}><Lbl>{L.bio}</Lbl><Txta rows={3} value={shop.bio||""} onChange={e=>setShop(p=>({...p,bio:e.target.value}))}/></div>
          <Btn variant="gold" style={{width:"100%"}} onClick={()=>{setShopSaved(true);setTimeout(()=>setShopSaved(false),2000);}}>{shopSaved?`✓ ${L.save}`:L.save}</Btn>

          {shopLink&&(
            <div style={{marginTop:32,paddingTop:18,borderTop:`1px solid ${T.border}`}}>
              <Lbl style={{marginBottom:8}}>Partilhar a loja</Lbl>
              <div style={{fontSize:"0.72rem",color:T.silver,marginBottom:12,lineHeight:1.5}}>
                Dá este link ou este código QR aos teus clientes para eles chegarem diretamente à tua loja.
              </div>
              <div style={{display:"flex",gap:8,marginBottom:14}}>
                <Inp value={shopLink} readOnly style={{flex:1,fontSize:"0.7rem"}}/>
                <Btn variant="ghost" style={{padding:"10px 13px",whiteSpace:"nowrap"}} onClick={copyShopLink}>{linkCopied?"✓ Copiado":"Copiar"}</Btn>
              </div>
              <div style={{display:"flex",justifyContent:"center",background:"#fff",padding:12,borderRadius:6,width:"fit-content",margin:"0 auto"}}>
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(shopLink)}`}
                  alt="QR code da loja"
                  width={220}
                  height={220}
                  style={{display:"block"}}
                />
              </div>
            </div>
          )}

          {barber?.id&&(
            <div style={{marginTop:32,paddingTop:18,borderTop:`1px solid ${T.border}`}}>
              <Lbl style={{marginBottom:8}}>Suporte LC.84</Lbl>
              <div style={{fontSize:"0.72rem",color:T.silver,marginBottom:12,lineHeight:1.5}}>
                Tens um problema ou uma dúvida sobre a app? Escreve aqui diretamente.
              </div>
              <Btn variant="ghost" style={{width:"100%"}} onClick={()=>setModal("support")}>💬 Falar com o Suporte</Btn>
              {modal==="support"&&<Modal onClose={()=>setModal(null)} title="Suporte LC.84">
                <ChatThread shopId={shopId} barberId={barber.id} clientKey="SUPORTE_LC84" sender="barber" lang={lang}/>
              </Modal>}
            </div>
          )}

          <div style={{marginTop:32,paddingTop:18,borderTop:`1px solid ${T.border}`}}>
            <Lbl style={{marginBottom:8,color:T.red}}>{L.dangerZone}</Lbl>
            <div style={{fontSize:"0.72rem",color:T.silver,marginBottom:10,lineHeight:1.5}}>
              {L.deleteShopWarning}
            </div>
            <Btn variant="danger" style={{width:"100%"}} onClick={()=>{setDelOpen(true);setDelName("");setDelPass("");setDelErr("");}}>{L.deleteShopBtn}</Btn>
          </div>

          {delOpen&&(
            <Modal onClose={()=>setDelOpen(false)} title={L.deleteShopBtn}>
              <div style={{fontSize:"0.76rem",color:T.silver,marginBottom:14,lineHeight:1.5}}>
                {L.deleteShopConfirmPre}<b style={{color:T.white}}>{shop.name}</b>{L.deleteShopConfirmPost}
              </div>
              <div style={{marginBottom:10}}><Lbl>{L.shopNameLabel}</Lbl><Inp value={delName} onChange={e=>setDelName(e.target.value)}/></div>
              <div style={{marginBottom:10}}><Lbl>{L.passwordLabel}</Lbl><Inp type="password" value={delPass} onChange={e=>setDelPass(e.target.value)}/></div>
              {delErr&&<div style={{color:T.red,fontSize:"0.72rem",marginBottom:10}}>{delErr}</div>}
              <div style={{display:"flex",gap:8}}>
                <Btn variant="danger" style={{flex:1}} onClick={doDeleteShop} disabled={delBusy}>{delBusy?L.deleting:L.deletePermanently}</Btn>
                <Btn variant="ghost" onClick={()=>setDelOpen(false)}>{L.cancel}</Btn>
              </div>
            </Modal>
          )}
        </>)}
        {tab==="orders"&&(<>
          {orderPhotoPreview&&(
            <div style={{display:"flex",alignItems:"center",gap:9,marginBottom:9,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,padding:"7px 10px"}}>
              <img src={orderPhotoPreview} style={{width:34,height:34,objectFit:"cover",borderRadius:5}}/>
              <div style={{flex:1,fontSize:"0.72rem",color:T.silver}}>{L.ordersPhotoAttached}</div>
              <button onClick={()=>{setOrderPhotoFile(null);setOrderPhotoPreview("");}} style={{background:"none",border:"none",color:T.silver,cursor:"pointer",fontSize:"1rem"}}>×</button>
            </div>
          )}
          <div style={{display:"flex",gap:8,marginBottom:9}}>
            <Inp value={orderText} onChange={e=>setOrderText(e.target.value)} placeholder={L.ordersAddPlaceholder} style={{flex:1}} onKeyDown={e=>{if(e.key==="Enter"){e.preventDefault();addOrder();}}}/>
            <label>
              <input type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>stageOrderPhoto(e.target.files?.[0])}/>
              <div style={{padding:"9px 12px",background:orderPhotoPreview?T.goldLo:T.card,border:`1px solid ${orderPhotoPreview?T.gold:T.border}`,borderRadius:6,color:orderPhotoPreview?T.gold:T.silver,fontSize:"0.9rem",cursor:"pointer"}}>📷</div>
            </label>
          </div>
          {orderErr&&<div style={{color:T.red,fontSize:"0.72rem",marginBottom:9}}>{orderErr}</div>}
          <Btn variant="gold" style={{width:"100%",marginBottom:16}} onClick={addOrder} disabled={orderPhotoBusy}>{orderPhotoBusy?L.uploading:L.ordersAddBtn}</Btn>
          {ordersLoading?(
            <div style={{textAlign:"center",padding:"24px 0",color:T.silver,fontSize:"0.78rem"}}>{L.loadingText}</div>
          ):orders.length===0?(
            <div style={{textAlign:"center",padding:"24px 0",color:T.silver,fontSize:"0.78rem"}}>{L.ordersEmpty}</div>
          ):orders.map(o=>(
            <div key={o.id} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",marginBottom:7,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,opacity:o.done?0.5:1}}>
              <button onClick={()=>toggleOrderDone(o)} style={{width:20,height:20,flexShrink:0,borderRadius:4,border:`1px solid ${o.done?T.green:T.border}`,background:o.done?T.greenLo:"transparent",color:T.green,cursor:"pointer",fontSize:"0.7rem",lineHeight:1}}>{o.done?"✓":""}</button>
              {o.photo_url&&<img src={o.photo_url} style={{width:38,height:38,objectFit:"cover",borderRadius:5,flexShrink:0}}/>}
              {o.text&&<div style={{flex:1,fontSize:"0.85rem",color:T.white,textDecoration:o.done?"line-through":"none"}}>{o.text}</div>}
              <button onClick={()=>deleteOrder(o.id)} style={{background:"none",border:"none",color:T.silver,cursor:"pointer",fontSize:"1rem",flexShrink:0}}>×</button>
            </div>
          ))}
        </>)}
        {tab==="catalog"&&(<>
          {prodPhotoPreview&&(
            <div style={{display:"flex",alignItems:"center",gap:9,marginBottom:9,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,padding:"7px 10px"}}>
              <img src={prodPhotoPreview} style={{width:34,height:34,objectFit:"cover",borderRadius:5}}/>
              <div style={{flex:1,fontSize:"0.72rem",color:T.silver}}>{L.ordersPhotoAttached}</div>
              <button onClick={()=>{setProdPhotoFile(null);setProdPhotoPreview("");}} style={{background:"none",border:"none",color:T.silver,cursor:"pointer",fontSize:"1rem"}}>×</button>
            </div>
          )}
          <div style={{display:"flex",gap:8,marginBottom:9}}>
            <Inp value={prodName} onChange={e=>setProdName(e.target.value)} placeholder={L.catalogNamePlaceholder} style={{flex:1}}/>
            <Inp value={prodPrice} onChange={e=>setProdPrice(e.target.value)} placeholder={L.catalogPricePlaceholder} style={{width:90}}/>
            <label>
              <input type="file" accept="image/*" capture="environment" style={{display:"none"}} onChange={e=>stageProdPhoto(e.target.files?.[0])}/>
              <div style={{padding:"9px 12px",background:prodPhotoPreview?T.goldLo:T.card,border:`1px solid ${prodPhotoPreview?T.gold:T.border}`,borderRadius:6,color:prodPhotoPreview?T.gold:T.silver,fontSize:"0.9rem",cursor:"pointer"}}>📷</div>
            </label>
          </div>
          {prodErr&&<div style={{color:T.red,fontSize:"0.72rem",marginBottom:9}}>{prodErr}</div>}
          <Btn variant="gold" style={{width:"100%",marginBottom:16}} onClick={addProduct} disabled={prodBusy}>{prodBusy?L.uploading:L.catalogAddBtn}</Btn>
          {productsLoading?(
            <div style={{textAlign:"center",padding:"24px 0",color:T.silver,fontSize:"0.78rem"}}>{L.loadingText}</div>
          ):products.length===0?(
            <div style={{textAlign:"center",padding:"24px 0",color:T.silver,fontSize:"0.78rem"}}>{L.catalogEmpty}</div>
          ):products.map(p=>(
            <div key={p.id} style={{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",marginBottom:7,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,opacity:p.available?1:0.5}}>
              {p.photo_url&&<img src={p.photo_url} onClick={()=>setViewProduct(p)} style={{width:44,height:44,objectFit:"cover",borderRadius:5,flexShrink:0,cursor:"pointer"}}/>}
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:"0.88rem",color:T.white,fontWeight:500,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.name}</div>
                {!p.available&&<div style={{fontSize:"0.6rem",color:T.red,letterSpacing:"0.08em",textTransform:"uppercase"}}>{L.catalogUnavailable}</div>}
              </div>
              <div style={{display:"flex",alignItems:"center",gap:2,flexShrink:0}}>
                <span style={{color:T.gold,fontSize:"0.82rem"}}>€</span>
                <input value={p.price??""} onChange={e=>updateProductPrice(p.id,e.target.value)} style={{width:52,background:"transparent",border:"none",borderBottom:`1px solid ${T.border}`,color:T.gold,fontSize:"0.82rem",padding:"2px 3px",fontFamily:"inherit"}}/>
              </div>
              <button onClick={()=>toggleProductAvailable(p)} style={{padding:"5px 9px",background:p.available?T.greenLo:T.redLo,border:`1px solid ${p.available?T.green:T.red}`,borderRadius:5,color:p.available?T.green:T.red,fontSize:"0.58rem",cursor:"pointer",flexShrink:0,whiteSpace:"nowrap"}}>{p.available?L.catalogMarkUnavailable:L.catalogMarkAvailable}</button>
              <button onClick={()=>deleteProduct(p.id)} style={{background:"none",border:"none",color:T.silver,cursor:"pointer",fontSize:"1rem",flexShrink:0}}>×</button>
            </div>
          ))}
        </>)}
        {viewProduct&&(
          <Modal onClose={()=>setViewProduct(null)} title={viewProduct.name}>
            <img src={viewProduct.photo_url} alt="" style={{width:"100%",borderRadius:6,marginBottom:10}}/>
            {!viewProduct.available&&<div style={{fontSize:"0.65rem",color:T.red,letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:8}}>{L.catalogUnavailable}</div>}
            {viewProduct.price!=null&&<div style={{color:T.gold,fontWeight:600,fontSize:"1.2rem"}}>€{Number(viewProduct.price).toFixed(2)}</div>}
          </Modal>
        )}
      </main>
    </div>
  );
}

function ServicesAdmin({services,setServices,lang}){
  const L=LANGS[lang].t;
  const [modal,setModal]=useState(false);const [f,setF]=useState({});
  const openAdd=()=>{setF({id:null,name:"",duration:30,price:0,active:true});setModal(true);};
  const openEdit=s=>{setF({...s});setModal(true);};
  const save=()=>{if(!f.name.trim())return;if(f.id)setServices(p=>p.map(s=>s.id===f.id?f:s));else setServices(p=>[...p,{...f,id:mkId()}]);setModal(false);};
  return(<>
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}><Lbl style={{margin:0}}>{services.length} {L.servicesCountSuffix}</Lbl><Btn variant="gold" style={{padding:"6px 13px"}} onClick={openAdd}>{L.addNew}</Btn></div>
    {services.map(s=>(
      <div key={s.id} style={{display:"flex",alignItems:"center",gap:9,padding:"11px 13px",marginBottom:6,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,opacity:s.active?1:0.45}}>
        <div style={{flex:1}}><div style={{fontSize:"0.95rem",color:T.white,fontWeight:500}}>{s.name}</div><div style={{fontSize:"0.68rem",color:T.silver}}>{s.duration} min</div></div>
        <div style={{fontSize:"0.95rem",color:T.gold,fontWeight:600}}>€{s.price}</div>
        <button onClick={()=>setServices(p=>p.map(sv=>sv.id===s.id?{...sv,active:!sv.active}:sv))} style={{background:s.active?T.greenLo:T.muted,border:`1px solid ${s.active?T.green:T.border}`,borderRadius:10,padding:"2px 8px",color:s.active?T.green:T.silver,fontSize:"0.54rem",cursor:"pointer",fontFamily:"'Josefin Sans',sans-serif"}}>{s.active?L.activeLabel:L.offLabel}</button>
        <button onClick={()=>openEdit(s)} style={{background:"none",border:"none",color:T.silver,cursor:"pointer",fontSize:"0.82rem"}}>✏</button>
      </div>
    ))}
    {modal&&<Modal onClose={()=>setModal(false)} title={f.id?L.editServiceTitle:L.newServiceTitle}>
      <div style={{marginBottom:11}}><Lbl>{L.nameLabel}</Lbl><Inp value={f.name} onChange={e=>setF(p=>({...p,name:e.target.value}))}/></div>
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:14}}>
        <div><Lbl>{L.durationLabel}</Lbl><Inp type="number" value={f.duration} onChange={e=>setF(p=>({...p,duration:Number(e.target.value)}))}/></div>
        <div><Lbl>{L.servicePriceLabel}</Lbl><Inp type="number" value={f.price} onChange={e=>setF(p=>({...p,price:Number(e.target.value)}))}/></div>
      </div>
      <div style={{display:"flex",gap:8}}><Btn variant="gold" style={{flex:1}} onClick={save}>{L.save}</Btn>{f.id&&<Btn variant="danger" onClick={()=>{setServices(p=>p.filter(s=>s.id!==f.id));setModal(false);}}>{L.delete}</Btn>}<Btn variant="ghost" onClick={()=>setModal(false)}>{L.close}</Btn></div>
    </Modal>}
  </>);
}

function BookingCalendarStep({sel,setSel,barber,bookings,freeSlots,worksOnDate,onNext,onBack,lang,serviceDuration,services}){
  const L=LANGS[lang].t;
  const [calY,setCalY]=useState(NOW.getFullYear());
  const [calM,setCalM]=useState(NOW.getMonth());
  const dim=new Date(calY,calM+1,0).getDate();
  const fd=new Date(calY,calM,1).getDay();
  const durOf=id=>services?.find(s=>s.id===id)?.duration||30;
  const prevM=()=>{if(calM===0){setCalM(11);setCalY(y=>y-1);}else setCalM(m=>m-1);};
  const nextM=()=>{if(calM===11){setCalM(0);setCalY(y=>y+1);}else setCalM(m=>m+1);};
  const isDayBlocked=ds=>{
    const hours=barber?getBarberHours(barber):[];
    const dayBks=bookings.filter(b=>b.barberId===sel.barberId&&b.date===ds&&!b.blocked);
    const free=hours.filter(h=>!dayBks.find(b=>slotsOverlap(h,serviceDuration||30,b.time,durOf(b.serviceId))));
    return free.length===0&&hours.length>0;
  };
  return(<>
    <Lbl style={{marginBottom:10}}>{L.chooseDate}</Lbl>
    <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:12}}>
      <button onClick={prevM} disabled={calY===NOW.getFullYear()&&calM===NOW.getMonth()} style={{background:"none",border:`1px solid ${T.border}`,color:T.mid,width:32,height:32,borderRadius:4,cursor:"pointer",fontSize:"1rem",opacity:calY===NOW.getFullYear()&&calM===NOW.getMonth()?0.3:1}}>‹</button>
      <span style={{fontSize:"0.95rem",color:T.white,letterSpacing:"0.06em"}}>{LANGS[lang].months[calM]} {calY}</span>
      <button onClick={nextM} style={{background:"none",border:`1px solid ${T.border}`,color:T.mid,width:32,height:32,borderRadius:4,cursor:"pointer",fontSize:"1rem"}}>›</button>
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:3,marginBottom:4}}>
      {LANGS[lang].wdays.map(d=><div key={d} style={{textAlign:"center",fontSize:"0.58rem",color:T.silver,padding:"2px 0",fontFamily:"'Josefin Sans',sans-serif"}}>{d}</div>)}
    </div>
    <div style={{display:"grid",gridTemplateColumns:"repeat(7,1fr)",gap:3,marginBottom:16}}>
      {Array(fd).fill(null).map((_,i)=><div key={"e"+i}/>)}
      {Array(dim).fill(null).map((_,i)=>{
        const day=i+1;
        const ds=`${calY}-${String(calM+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
        const isPast=ds<TODAY;
        const isSelected=ds===sel.date;
        const isFolga=barber&&!barberWorksOnDate(barber,ds);
        const isFullyBooked=!isPast&&!isFolga&&isDayBlocked(ds);
        const isToday=ds===TODAY;
        let bg="transparent", color=T.light, border=`1px solid ${T.border}`, cursor="pointer", opacity=1;
        if(isPast){color=T.muted;border=`1px solid ${T.border}`;cursor="default";opacity=0.4;}
        else if(isFolga){bg=T.redLo;color=T.red;border=`1px solid ${T.red}44`;cursor="not-allowed";opacity=0.6;}
        else if(isFullyBooked){bg=T.muted;color=T.silver;cursor="not-allowed";}
        else if(isSelected){bg=T.gold;color="#000";border=`1px solid ${T.gold}`;}
        else if(isToday){bg=T.goldLo;color=T.gold;border=`1px solid ${T.gold}66`;}
        return(
          <div key={day} onClick={()=>!isPast&&!isFolga&&!isFullyBooked&&setSel(p=>({...p,date:ds,time:""}))} style={{aspectRatio:"1",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",borderRadius:5,cursor,background:bg,border,color,fontSize:"0.82rem",opacity,position:"relative"}}>
            {day}
            {!isPast&&!isFolga&&!isFullyBooked&&!isSelected&&(()=>{
              const hours=barber?getBarberHours(barber):[];
              const dayBks=bookings.filter(b=>b.barberId===sel.barberId&&b.date===ds&&!b.blocked);
              const free=hours.filter(h=>!dayBks.find(b=>slotsOverlap(h,serviceDuration||30,b.time,durOf(b.serviceId)))).length;
              if(free>0)return<div style={{width:4,height:4,borderRadius:"50%",background:T.green,position:"absolute",bottom:3}}/>;
            })()}
          </div>
        );
      })}
    </div>
    <div style={{display:"flex",gap:14,marginBottom:14,flexWrap:"wrap"}}>
      {[[T.green,L.confirmed],[T.gold,L.selected],[T.silver,L.blocked],[T.red,L.holiday]].map(([c,l])=>(
        <div key={l} style={{display:"flex",alignItems:"center",gap:5}}>
          <div style={{width:8,height:8,borderRadius:"50%",background:c}}/>
          <span style={{fontSize:"0.62rem",color:T.silver,fontFamily:"'Josefin Sans',sans-serif"}}>{l}</span>
        </div>
      ))}
    </div>
    {sel.date&&worksOnDate&&(<>
      <Lbl style={{marginBottom:8}}>{L.freeSlots} — {dateLabel(sel.date,lang)}</Lbl>
      {freeSlots.length===0
        ?<div style={{color:T.silver,fontSize:"0.83rem",padding:"8px 0",marginBottom:12}}>{L.noBookings}</div>
        :<div style={{display:"flex",flexWrap:"wrap",gap:7,marginBottom:14}}>
          {freeSlots.map(h=><button key={h} onClick={()=>setSel(p=>({...p,time:h}))} style={{padding:"8px 12px",borderRadius:4,cursor:"pointer",fontSize:"0.78rem",fontFamily:"'Josefin Sans',sans-serif",background:sel.time===h?T.gold:"transparent",color:sel.time===h?"#000":T.mid,border:`1px solid ${sel.time===h?T.gold:T.border}`}}>{h}</button>)}
        </div>
      }
    </>)}
    {sel.date&&!worksOnDate&&<div style={{background:T.redLo,border:`1px solid ${T.red}`,borderRadius:6,padding:"9px 13px",marginBottom:12,fontSize:"0.8rem",color:T.red}}>{barber?.name} — {L.holiday}</div>}
    <Btn variant="gold" style={{width:"100%",marginTop:4}} onClick={onNext}>{L.next}</Btn>
    <Btn variant="ghost" style={{width:"100%",marginTop:7}} onClick={onBack}>{L.back}</Btn>
  </>);
}
function ClientArea({bookings,setBookings,services,barbers,shop,shopId,addNotification,lang,onBack}){
  const L=LANGS[lang].t;
  const [screen,setScreen]=useState("home");
  const [step,setStep]=useState(1);
  const [sel,setSel]=useState(()=>{let p={name:"",phone:""};try{p=JSON.parse(localStorage.getItem(`lc84_client_${shopId}`))||p;}catch{}return {barberId:"",serviceId:"",date:"",time:"",name:p.name||"",phone:p.phone||""};});
  const [done,setDone]=useState(null);
  const [clientPhone,setClientPhone]=useState("");
  const [myBk,setMyBk]=useState([]);
  const [chatPhone,setChatPhone]=useState("");
  const [chatBarbers,setChatBarbers]=useState([]);
  const [chatBarber,setChatBarber]=useState(null);
  const [clientProfile,setClientProfile]=useState(()=>{
    try{return JSON.parse(localStorage.getItem(`lc84_client_${shopId}`)||"null");}catch{return null;}
  });
  const [profilePromptBarber,setProfilePromptBarber]=useState(null);
  const [profileForm,setProfileForm]=useState({name:"",phone:""});
  const clientUnread=useClientUnreadMap(shopId,chatPhone.trim());
  const [catalogProds,setCatalogProds]=useState([]);
  const [catalogLoading,setCatalogLoading]=useState(true);
  const [viewProduct,setViewProduct]=useState(null);
  useEffect(()=>{
    if(!shopId)return;
    let active=true;
    (async()=>{
      const{data}=await supabase.from("products").select("*").eq("shop_id",shopId).order("created_at",{ascending:false});
      if(active){setCatalogProds(data||[]);setCatalogLoading(false);}
    })();
    return()=>{active=false;};
  },[shopId]);
  const openChatList=()=>{
    if(chatPhone.trim().length<5)return;
    const ids=[...new Set(bookings.filter(b=>b.phone===chatPhone.trim()).map(b=>b.barberId))];
    setChatBarbers(barbers.filter(b=>ids.includes(b.id)));
    setScreen("chatlist");
  };
  const openChatWithBarber=b=>{
    if(clientProfile&&clientProfile.phone){
      setChatPhone(clientProfile.phone);
      setChatBarber(b);
            registerPushForClient(shopId,clientProfile.phone);
    }else{
      setProfileForm({name:"",phone:""});
      setProfilePromptBarber(b);
    }
  };
  const saveProfileAndOpenChat=()=>{
    const name=profileForm.name.trim(),phone=profileForm.phone.trim();
    if(!name||phone.length<5)return;
    const profile={name,phone};
    try{localStorage.setItem(`lc84_client_${shopId}`,JSON.stringify(profile));}catch{}
    setClientProfile(profile);
    setChatPhone(phone);
    setChatBarber(profilePromptBarber);
    setProfilePromptBarber(null);
        registerPushForClient(shopId,phone);
  };
  const svc=id=>services.find(s=>s.id===id);
  const barber=barbers.find(b=>b.id===sel.barberId);
  const selSvc=svc(sel.serviceId);
  const hours=barber?getBarberHours(barber):[];
  const dayBk=sel.date&&sel.barberId?bookings.filter(b=>b.barberId===sel.barberId&&b.date===sel.date):[];
  const selDuration=selSvc?.duration||30;
  const freeSlots=hours.filter(h=>!dayBk.find(b=>slotsOverlap(h,selDuration,b.time,svc(b.serviceId)?.duration||30)));
  const worksOnDate=barber&&sel.date?barberWorksOnDate(barber,sel.date):true;
  const confirm=()=>{
    const b={id:mkId(),barberId:sel.barberId,date:sel.date,time:sel.time,serviceId:sel.serviceId,name:sel.name,phone:sel.phone.trim(),status:"confirmado",paid:false,payMethod:"",notes:"",blocked:false};
    setBookings(p=>[...p,b]);setMyBk(p=>[...p,b]);setDone(b);
    addNotification(sel.barberId,"new","Nova marcação",`${sel.name} marcou ${svcName(selSvc,lang)} para ${dateLabel(sel.date,lang)} às ${sel.time}h.`,{type:"client",key:sel.phone.trim()||sel.name});
    setScreen("success");supabase.functions.invoke("send-push",{body:{sender:"client",shop_id:shopId,barber_id:sel.barberId,client_key:sel.phone.trim()||sel.name,title:"Nova marcação",text:`${sel.name} marcou ${svcName(selSvc,lang)} para ${dateLabel(sel.date,lang)} às ${sel.time}h.`,type:"booking"}}).catch(()=>{});
  };
  const cancel=id=>{
    const b=bookings.find(b=>b.id===id);
    setBookings(p=>p.map(b=>b.id===id?{...b,status:"cancelado"}:b));
    setMyBk(p=>p.map(b=>b.id===id?{...b,status:"cancelado"}:b));
    if(b)addNotification(b.barberId,"cancel",L.notifCancelTitle,L.notifCancelBody.replace("{name}",b.name).replace("{date}",dateLabel(b.date,lang)).replace("{time}",b.time),{type:"client",key:b.phone||b.name});
  };
  const lookup=()=>{if(clientPhone.trim().length<5)return;setMyBk(bookings.filter(b=>b.phone===clientPhone.trim()));setScreen("mybookings");};
  const reset=()=>{setSel({barberId:"",serviceId:"",date:"",time:"",name:"",phone:""});setStep(1);setDone(null);setScreen("home");};
  return(
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",fontFamily:"'Cormorant Garamond',Georgia,serif",color:T.light}}>
      <style>{GS}</style>
      <header className="app-shell" style={{width:"100%",maxWidth:520,padding:"14px 20px",borderBottom:`1px solid ${T.border}`,background:T.surface,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div style={{display:"flex",alignItems:"center",gap:9}}>
          <div><div style={{fontFamily:"'Josefin Sans',sans-serif",fontSize:"0.85rem",letterSpacing:"0.15em",fontWeight:700,color:T.white}}>LC<span style={{color:T.gold}}>.</span>84</div><div style={{fontSize:"0.48rem",letterSpacing:"0.28em",color:T.silver,textTransform:"uppercase"}}>{L.clientArea}</div></div>
        </div>
        <button onClick={onBack} style={{background:"none",border:`1px solid ${T.border}`,color:T.silver,padding:"5px 9px",borderRadius:4,cursor:"pointer",fontSize:"0.56rem",letterSpacing:"0.12em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif"}}>{L.back}</button>
      </header>
      <main className="app-shell" style={{width:"100%",maxWidth:520,flex:1,padding:"20px 20px 80px"}}>
        {screen==="home"&&(<>
          <div style={{textAlign:"center",marginBottom:24}}><div style={{fontSize:"1.4rem",color:T.white,fontWeight:600,marginBottom:4}}>{shop.name}</div><div style={{fontSize:"0.78rem",color:T.gold}}>{shop.phone}</div></div>
          <Btn variant="gold" style={{width:"100%",marginBottom:10,padding:"14px"}} onClick={()=>setScreen("book")}>⚔ {L.bookCta}</Btn>
          
          <Btn variant="ghost" style={{width:"100%",marginBottom:16,padding:"12px"}} onClick={()=>setScreen("catalog")}>🛍️ {L.catalogClientCta}</Btn>
          <div style={{marginBottom:16}}><Lbl style={{marginBottom:7}}>{L.myBookingsLabel}</Lbl><div style={{display:"flex",gap:8}}><Inp placeholder={L.phonePlaceholder} value={clientPhone} onChange={e=>setClientPhone(e.target.value)} style={{flex:1}}/><Btn variant="ghost" style={{padding:"10px 13px"}} onClick={lookup}>{L.show}</Btn></div></div>
          <Lbl style={{marginBottom:9}}>{L.ourTeam}</Lbl>
          {barbers.filter(b=>b.active).map(b=>(
            <div key={b.id} onClick={()=>openChatWithBarber(b)} style={{display:"flex",alignItems:"center",gap:11,padding:"11px 13px",marginBottom:6,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,cursor:"pointer"}}>
              <Avatar barber={b} size={38}/>
              <div style={{flex:1}}><div style={{fontSize:"0.92rem",color:T.white,fontWeight:500}}>{b.name}</div><div style={{fontSize:"0.68rem",color:T.silver}}>{b.role}</div><div style={{fontSize:"0.6rem",color:b.color,marginTop:2,fontFamily:"'Josefin Sans',sans-serif"}}>{LANGS[lang].wdaysF.filter((_,i)=>b.schedule.workDays.includes(i)).map(d=>d.slice(0,3)).join(" · ")} · {b.schedule.startHour}–{b.schedule.endHour}</div></div>
              <span style={{fontSize:"1.1rem",color:T.gold}}>💬</span>
            </div>
          ))}
        </>)}
        {screen==="book"&&(<>
          <div style={{display:"flex",gap:5,marginBottom:20}}>{[1,2,3,4].map(s=><div key={s} style={{flex:1,height:3,borderRadius:2,background:s<=step?T.gold:T.border,transition:"background .3s"}}/>)}</div>
          {step===1&&(<>
            <Lbl style={{marginBottom:10}}>{L.chooseBarber}</Lbl>
            {barbers.filter(b=>b.active).map(b=>(
              <div key={b.id} onClick={()=>setSel(p=>({...p,barberId:b.id,time:""}))} style={{display:"flex",alignItems:"center",gap:11,padding:"13px",marginBottom:7,background:sel.barberId===b.id?T.goldLo:T.card,border:`1px solid ${sel.barberId===b.id?T.gold:T.border}`,borderRadius:6,cursor:"pointer"}}>
                <Avatar barber={b} size={42}/><div><div style={{fontSize:"0.97rem",color:T.white,fontWeight:500}}>{b.name}</div><div style={{fontSize:"0.7rem",color:T.silver}}>{b.role}</div><div style={{fontSize:"0.6rem",color:b.color,marginTop:2,fontFamily:"'Josefin Sans',sans-serif"}}>{LANGS[lang].wdaysF.filter((_,i)=>b.schedule.workDays.includes(i)).map(d=>d.slice(0,3)).join(" · ")}</div></div>
              </div>
            ))}
            <Btn variant="gold" style={{width:"100%",marginTop:7}} onClick={()=>sel.barberId&&setStep(2)}>{L.next}</Btn>
            <Btn variant="ghost" style={{width:"100%",marginTop:7}} onClick={()=>setScreen("home")}>{L.back}</Btn>
          </>)}
          {step===2&&(<>
            <Lbl style={{marginBottom:10}}>{L.chooseService}</Lbl>
            {services.filter(s=>s.active).map(s=>(
              <div key={s.id} onClick={()=>setSel(p=>({...p,serviceId:s.id}))} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px 14px",marginBottom:6,background:sel.serviceId===s.id?T.goldLo:T.card,border:`1px solid ${sel.serviceId===s.id?T.gold:T.border}`,borderRadius:6,cursor:"pointer"}}>
                <div><div style={{fontSize:"0.97rem",color:T.white,fontWeight:500}}>{svcName(s,lang)}</div><div style={{fontSize:"0.7rem",color:T.silver,marginTop:2}}>{s.duration} min</div></div>
                <div style={{fontSize:"0.97rem",color:T.gold,fontWeight:600}}>€{s.price}</div>
              </div>
            ))}
            <Btn variant="gold" style={{width:"100%",marginTop:7}} onClick={()=>sel.serviceId&&setStep(3)}>{L.next}</Btn>
            <Btn variant="ghost" style={{width:"100%",marginTop:7}} onClick={()=>setStep(1)}>{L.back}</Btn>
          </>)}
    {step===3&&<BookingCalendarStep sel={sel} setSel={setSel} barber={barber} lang={lang} bookings={bookings} freeSlots={freeSlots} worksOnDate={worksOnDate} serviceDuration={selDuration} services={services} onNext={()=>sel.date&&sel.time&&worksOnDate&&setStep(4)} onBack={()=>setStep(2)}/>}
          {step===4&&(<>
            <Lbl style={{marginBottom:10}}>{L.yourData}</Lbl>
            <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:7,padding:"13px",marginBottom:14}}>
              {[[L.barberLabel,barber?.name],[L.service,svcName(selSvc,lang)],[L.date,dateLabel(sel.date,lang)],[L.time,sel.time],[L.priceLabel,`€${selSvc?.price}`]].map(([l,v])=>(
                <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${T.border}`}}><Lbl style={{marginBottom:0}}>{l}</Lbl><span style={{fontSize:"0.86rem",color:l===L.priceLabel?T.gold:T.white}}>{v}</span></div>
              ))}
            </div>
            <div style={{marginBottom:10}}><Lbl>{L.nameLabel}</Lbl><Inp placeholder={L.namePlaceholder} value={sel.name} onChange={e=>setSel(p=>({...p,name:e.target.value}))}/></div>
            <div style={{marginBottom:16}}><Lbl>{L.phone}</Lbl><Inp placeholder="+351 9XX XXX XXX" value={sel.phone} onChange={e=>setSel(p=>({...p,phone:e.target.value}))}/></div>
            <Btn variant="gold" style={{width:"100%"}} onClick={()=>sel.name.trim()&&sel.phone.trim()&&confirm()}>{L.confirm}</Btn>
            <Btn variant="ghost" style={{width:"100%",marginTop:7}} onClick={()=>setStep(3)}>{L.back}</Btn>
          </>)}
        </>)}
        {screen==="success"&&done&&(<div style={{textAlign:"center",paddingTop:36}}>
          <div style={{width:58,height:58,borderRadius:"50%",background:T.greenLo,border:`2px solid ${T.green}`,display:"flex",alignItems:"center",justifyContent:"center",margin:"0 auto 18px",fontSize:"1.3rem",color:T.green}}>✓</div>
          <div style={{fontSize:"1.4rem",color:T.white,fontWeight:600,marginBottom:7}}>{L.bookingConfirmed}</div>
          <div style={{fontSize:"0.86rem",color:T.silver,lineHeight:1.8,marginBottom:24}}>{done.name}<br/><span style={{color:T.gold}}>{barbers.find(b=>b.id===done.barberId)?.name}</span> · {svcName(selSvc,lang)}<br/>{done.time}h · {dateLabel(done.date,lang)}</div>
          <Btn variant="gold" style={{width:"100%",marginBottom:9}} onClick={reset}>{L.newBookingBtn}</Btn>
          <Btn variant="ghost" style={{width:"100%"}} onClick={()=>setScreen("mybookings")}>{L.myBookings}</Btn>
        </div>)}
        {screen==="chat"&&(<>
          <Lbl style={{marginBottom:10}}>{L.myBookingsLabel}</Lbl>
          <div style={{display:"flex",gap:8,marginBottom:16}}><Inp placeholder={L.phonePlaceholder} value={chatPhone} onChange={e=>setChatPhone(e.target.value)} style={{flex:1}}/><Btn variant="ghost" style={{padding:"10px 13px"}} onClick={openChatList}>{L.show}</Btn></div>
          <Btn variant="ghost" style={{width:"100%"}} onClick={()=>setScreen("home")}>{L.back}</Btn>
        </>)}
        {screen==="chatlist"&&(<>
          <Lbl style={{marginBottom:10}}>{L.chatPickBarber}</Lbl>
          {chatBarbers.length===0?<div style={{textAlign:"center",padding:"32px 0",color:T.silver}}>{L.chatNoBarbers}</div>
          :chatBarbers.map(b=>(
            <div key={b.id} onClick={()=>setChatBarber(b)} style={{display:"flex",alignItems:"center",gap:11,padding:"12px 14px",marginBottom:7,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,cursor:"pointer"}}>
              <Avatar barber={b} size={40}/>
              <div style={{flex:1}}><div style={{fontSize:"0.95rem",color:T.white,fontWeight:500}}>{b.name}</div><div style={{fontSize:"0.68rem",color:T.silver}}>{b.role}</div></div>
              {clientUnread[b.id]>0&&<span style={{fontSize:"0.6rem",background:T.red,color:"#fff",borderRadius:"50%",width:18,height:18,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Josefin Sans',sans-serif"}}>{clientUnread[b.id]>9?"9+":clientUnread[b.id]}</span>}
            </div>
          ))}
          <Btn variant="ghost" style={{width:"100%",marginTop:7}} onClick={()=>setScreen("chat")}>{L.back}</Btn>
        </>)}
        {screen==="catalog"&&(<>
          <Lbl style={{marginBottom:10}}>{L.catalogClientCta}</Lbl>
          {catalogLoading?(
            <div style={{textAlign:"center",padding:"32px 0",color:T.silver}}>{L.loadingText}</div>
          ):catalogProds.length===0?(
            <div style={{textAlign:"center",padding:"32px 0",color:T.silver}}>{L.catalogEmpty}</div>
          ):catalogProds.map(p=>(
            <div key={p.id} onClick={()=>p.photo_url&&setViewProduct(p)} style={{display:"flex",alignItems:"center",gap:11,padding:"11px 13px",marginBottom:7,background:T.card,border:`1px solid ${T.border}`,borderRadius:6,opacity:p.available?1:0.55,cursor:p.photo_url?"pointer":"default"}}>
              {p.photo_url&&<img src={p.photo_url} style={{width:48,height:48,objectFit:"cover",borderRadius:6,flexShrink:0}}/>}
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:"0.9rem",color:T.white,fontWeight:500}}>{p.name}</div>
                {!p.available&&<div style={{fontSize:"0.6rem",color:T.red,letterSpacing:"0.08em",textTransform:"uppercase",marginTop:2}}>{L.catalogUnavailable}</div>}
              </div>
              {p.price!=null&&<div style={{color:T.gold,fontWeight:600,fontSize:"0.95rem",flexShrink:0}}>€{Number(p.price).toFixed(2)}</div>}
            </div>
          ))}
          <Btn variant="ghost" style={{width:"100%",marginTop:7}} onClick={()=>setScreen("home")}>{L.back}</Btn>
        </>)}
        {viewProduct&&(
          <Modal onClose={()=>setViewProduct(null)} title={viewProduct.name}>
            <img src={viewProduct.photo_url} alt="" style={{width:"100%",borderRadius:6,marginBottom:10}}/>
            {!viewProduct.available&&<div style={{fontSize:"0.65rem",color:T.red,letterSpacing:"0.08em",textTransform:"uppercase",marginBottom:8}}>{L.catalogUnavailable}</div>}
            {viewProduct.price!=null&&<div style={{color:T.gold,fontWeight:600,fontSize:"1.2rem"}}>€{Number(viewProduct.price).toFixed(2)}</div>}
          </Modal>
        )}
        {screen==="mybookings"&&(<>
          <Lbl style={{marginBottom:10}}>{myBk.length} {L.bookings}</Lbl>
          {myBk.length===0?<div style={{textAlign:"center",padding:"32px 0",color:T.silver}}>{L.noBookingsFound}</div>
          :myBk.sort((a,b)=>b.date.localeCompare(a.date)).map(b=>(
            <div key={b.id} style={{padding:"11px 13px",marginBottom:6,background:T.card,border:`1px solid ${T.border}`,borderRadius:6}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:5}}>
                <div><div style={{fontSize:"0.92rem",color:T.white,fontWeight:500}}>{svcName(svc(b.serviceId),lang)}</div><div style={{fontSize:"0.68rem",color:T.silver,marginTop:2}}>{barbers.find(br=>br.id===b.barberId)?.name} · {b.time}h · {dateLabel(b.date,lang)}</div></div>
                <Tag status={b.status}/>
              </div>
              {b.status==="confirmado"&&b.date>=TODAY&&<Btn variant="danger" style={{padding:"4px 11px",fontSize:"0.56rem"}} onClick={()=>cancel(b.id)}>{L.cancelBooking}</Btn>}
            </div>
          ))}
          <Btn variant="ghost" style={{width:"100%",marginTop:7}} onClick={()=>setScreen("home")}>{L.back}</Btn>
        </>)}
      </main>
      {chatBarber&&(
        <Modal onClose={()=>setChatBarber(null)} title={`${L.chatTitle} · ${chatBarber.name}`}>
          <ChatThread shopId={shopId} barberId={chatBarber.id} clientKey={chatPhone.trim()} sender="client" lang={lang}
            onSent={msg=>addNotification(chatBarber.id,"message",L.notifNewMsgTitle,L.notifNewMsgBody.replace("{name}",clientProfile?.name||bookings.find(b=>b.phone===chatPhone.trim())?.name||chatPhone.trim()),{type:"chat",key:chatPhone.trim()})}/>
        </Modal>
      )}
      {profilePromptBarber&&(
        <Modal onClose={()=>setProfilePromptBarber(null)} title={`${L.chatTitle} · ${profilePromptBarber.name}`}>
          <div style={{marginBottom:10}}><Lbl>{L.nameLabel}</Lbl><Inp placeholder={L.namePlaceholder} value={profileForm.name} onChange={e=>setProfileForm(p=>({...p,name:e.target.value}))}/></div>
          <div style={{marginBottom:16}}><Lbl>{L.phone}</Lbl><Inp placeholder="+351 9XX XXX XXX" value={profileForm.phone} onChange={e=>setProfileForm(p=>({...p,phone:e.target.value}))}/></div>
          <Btn variant="gold" style={{width:"100%"}} onClick={saveProfileAndOpenChat}>{L.chatWithBarberCta}</Btn>
        </Modal>
      )}
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// LOGIN + ENTRY
// ══════════════════════════════════════════════════════════════════════════════
function LoginScreen({barbers,setBarbers,shop,onBarberLogin,onAdminLogin,onBack,lang}){
  const L=LANGS[lang].t;
  const [pin,setPin]=useState(""),[ err,setErr]=useState(false),[show,setShow]=useState(false);
  const [joinMode,setJoinMode]=useState(false);
  const [jName,setJName]=useState(""),[jPin,setJPin]=useState(""),[jPhone,setJPhone]=useState(""),[jErr,setJErr]=useState("");
  const attempt=()=>{if(shop.adminPin&&pin===shop.adminPin){onAdminLogin();return;}const b=barbers.find(b=>b.pin===pin&&b.active);if(b)onBarberLogin(b);else{setErr(true);setPin("");setTimeout(()=>setErr(false),1500);}};
  const join=()=>{
    setJErr("");
    if(!jName.trim()){setJErr(L.writeYourName);return;}
    if(!/^\d{4,6}$/.test(jPin)){setJErr(L.codeLength);return;}
    if(jPin===shop.adminPin||barbers.find(b=>b.pin===jPin)){setJErr(L.codeInUse);return;}
    const nb={id:mkId(),name:jName.trim(),role:"Barbeiro",pin:jPin,phone:jPhone||"",bio:"",avatar:jName.trim().split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase(),color:"#b8955a",schedule:{workDays:[1,2,3,4,5,6],startHour:"09:00",endHour:"19:00",breakStart:"",breakEnd:""},active:true};
    setBarbers(p=>[...p,nb]);
    onBarberLogin(nb);
  };
  return(
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,fontFamily:"'Cormorant Garamond',Georgia,serif"}}>
      <style>{GS}</style>
      <div style={{width:"100%",maxWidth:290,marginBottom:16}}>
        <button onClick={onBack} style={{background:"none",border:`1px solid ${T.border}`,color:T.silver,padding:"5px 9px",borderRadius:4,cursor:"pointer",fontSize:"0.56rem",letterSpacing:"0.12em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif"}}>{L.back}</button>
      </div>
      <div style={{textAlign:"center",marginBottom:40}}>
        <div style={{fontFamily:"'Josefin Sans',sans-serif",fontSize:"1.7rem",letterSpacing:"0.12em",fontWeight:700,color:T.white}}>LC<span style={{color:T.gold}}>_</span>84<span style={{color:T.gold,fontSize:"1.25rem"}}>barbervision</span></div>
        <div style={{fontSize:"0.58rem",letterSpacing:"0.38em",color:T.silver,textTransform:"uppercase",marginTop:5}}>{L.barberArea}</div>
      </div>
      {!joinMode?(
        <div style={{width:"100%",maxWidth:290}}>
          <Lbl style={{textAlign:"center",marginBottom:12}}>{L.accessCode}</Lbl>
          <div style={{position:"relative",marginBottom:12}}>
            <Inp type={show?"text":"password"} placeholder="••••" value={pin} onChange={e=>setPin(e.target.value)} onKeyDown={e=>e.key==="Enter"&&attempt()} style={{textAlign:"center",fontSize:"1.35rem",letterSpacing:"0.4em",borderColor:err?T.red:T.border}}/>
            <button onClick={()=>setShow(s=>!s)} style={{position:"absolute",right:9,top:"50%",transform:"translateY(-50%)",background:"none",border:"none",color:T.silver,cursor:"pointer",fontSize:"0.7rem"}}>{show?L.hide:L.show}</button>
          </div>
          {err&&<div style={{textAlign:"center",color:T.red,fontSize:"0.76rem",marginBottom:9}}>{L.wrongPin}</div>}
          <Btn variant="gold" style={{width:"100%",marginBottom:13}} onClick={attempt}>{L.enter}</Btn>
          <div style={{textAlign:"center"}}>
            <button onClick={()=>setJoinMode(true)} style={{background:"none",border:"none",color:T.silver,fontSize:"0.72rem",cursor:"pointer",textDecoration:"underline"}}>{L.joinAsNew}</button>
          </div>
          <div style={{textAlign:"center",marginTop:18}}>
            <button onClick={()=>{window.location.href=`${window.location.origin}${window.location.pathname}?dono=1`;}} style={{background:"none",border:"none",color:T.silver,fontSize:"0.68rem",cursor:"pointer",textDecoration:"underline",opacity:0.7}}>{L.goToOwnerPortal}</button>
          </div>
        </div>
      ):(
        <div style={{width:"100%",maxWidth:290}}>
          <Lbl style={{marginBottom:6}}>{L.yourNameShort}</Lbl>
          <Inp value={jName} onChange={e=>setJName(e.target.value)} placeholder={L.fullNamePlaceholder} style={{marginBottom:12}}/>
          <Lbl style={{marginBottom:6}}>{L.createAccessCode}</Lbl>
          <Inp value={jPin} onChange={e=>setJPin(e.target.value.replace(/\D/g,""))} placeholder="••••" style={{marginBottom:12,textAlign:"center",letterSpacing:"0.3em"}}/>
          <Lbl style={{marginBottom:6}}>{L.phoneOptional}</Lbl>
          <Inp value={jPhone} onChange={e=>setJPhone(e.target.value)} placeholder="+351 9xx xxx xxx" style={{marginBottom:12}}/>
          {jErr&&<div style={{textAlign:"center",color:T.red,fontSize:"0.76rem",marginBottom:12}}>{jErr}</div>}
          <Btn variant="gold" style={{width:"100%",marginBottom:9}} onClick={join}>{L.joinTeamBtn}</Btn>
          <div style={{textAlign:"center"}}>
            <button onClick={()=>{setJoinMode(false);setJErr("");}} style={{background:"none",border:"none",color:T.silver,fontSize:"0.72rem",cursor:"pointer",textDecoration:"underline"}}>{L.alreadyHaveCode}</button>
          </div>
        </div>
      )}
    </div>
  );
}

function EntryScreen({shop,onBarber,onClient,lang,setLang}){
  const L=LANGS[lang].t;
  return(
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,fontFamily:"'Cormorant Garamond',Georgia,serif",position:"relative"}}>
      <style>{GS}</style>
      <div style={{position:"absolute",top:16,right:16,display:"flex",gap:6,zIndex:10}}>
        {Object.entries(LANGS).map(([code,l])=>(
          <button key={code} onClick={()=>setLang(code)} style={{padding:"4px 8px",borderRadius:4,cursor:"pointer",display:"flex",alignItems:"center",background:lang===code?T.goldLo:"transparent",border:`1px solid ${lang===code?T.gold:T.border}`}} title={l.name}>
            <img src={`https://flagcdn.com/w40/${FLAG_CC[code]}.png`} alt={l.name} style={{width:22,height:16,objectFit:"cover",borderRadius:2,display:"block"}}/>
          </button>
        ))}
      </div>
      <div style={{textAlign:"center",marginBottom:40}}>
        <img src={logoIcon} style={{width:220,marginBottom:8,display:"block",marginLeft:"auto",marginRight:"auto"}}/>
        <div style={{fontSize:"0.6rem",letterSpacing:"0.38em",color:T.silver,textTransform:"uppercase",marginTop:5,marginBottom:5}}>{L.platform}</div>
      </div>
      <div style={{width:"100%",maxWidth:290,display:"flex",flexDirection:"column",gap:9}}>
        <button onClick={onClient} style={{padding:"17px",background:T.goldLo,border:`1px solid ${T.gold}`,borderRadius:8,cursor:"pointer",color:T.white,fontFamily:"'Cormorant Garamond',Georgia,serif",textAlign:"center"}}>
          <div style={{fontSize:"1.3rem",marginBottom:5}}>✂</div><div style={{fontSize:"1rem",fontWeight:600,marginBottom:3}}>{L.client}</div><div style={{fontSize:"0.73rem",color:T.silver}}>{L.clientSub}</div>
        </button>
        <button onClick={onBarber} style={{padding:"17px",background:T.surface,border:`1px solid ${T.border}`,borderRadius:8,cursor:"pointer",color:T.white,fontFamily:"'Cormorant Garamond',Georgia,serif",textAlign:"center"}}>
          <div style={{fontSize:"1.3rem",marginBottom:5}}>◉</div><div style={{fontSize:"1rem",fontWeight:600,marginBottom:3}}>{L.barber}</div><div style={{fontSize:"0.73rem",color:T.silver}}>{L.barberSub}</div>
        </button>
        <button onClick={()=>{window.location.href=`${window.location.origin}${window.location.pathname}?dono=1`;}} style={{padding:"17px",background:T.surface,border:`1px solid ${T.border}`,borderRadius:8,cursor:"pointer",color:T.white,fontFamily:"'Cormorant Garamond',Georgia,serif",textAlign:"center"}}>
          <div style={{fontSize:"1.3rem",marginBottom:5}}>♛</div><div style={{fontSize:"1rem",fontWeight:600,marginBottom:3}}>{L.portalTitle}</div><div style={{fontSize:"0.73rem",color:T.silver}}>{L.ownerBtnSub}</div>
        </button>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// SUBSCRIPTION SYSTEM
// ══════════════════════════════════════════════════════════════════════════════

// Trial: 15 days from first open. Demo starts with 3 days left to show urgency.
const TRIAL_START = new Date(Date.now() - 12*24*3600000); // 12 days ago = 3 days left
const TRIAL_DAYS  = 15;
const PRICE_SOLO  = 9.99;
const PRICE_TEAM  = 7.99; // per collaborator

function daysLeft(trialStart){
  const end = new Date(trialStart.getTime() + TRIAL_DAYS*24*3600000);
  return Math.max(0, Math.ceil((end - Date.now()) / 86400000));
}

function TrialBanner({days, onSubscribe, lang}){
  const L=LANGS[lang].t;
  if(days > 5) return null; // only show when close to expiry
  const urgent = days <= 1;
  return(
    <div onClick={onSubscribe} style={{margin:"0 20px 14px",padding:"11px 14px",background:urgent?T.redLo:T.goldLo,border:`1px solid ${urgent?T.red:T.gold}`,borderRadius:7,cursor:"pointer",display:"flex",justifyContent:"space-between",alignItems:"center"}}>
      <div>
        <div style={{fontSize:"0.82rem",color:urgent?T.red:T.gold,fontWeight:600}}>
          {days===0?`${L.trialExpiredShort} `:"⏳ "}{days===0?L.subscribeToContinue:L.trialDaysRemaining.replace("{n}",days)}
        </div>
        <div style={{fontSize:"0.66rem",color:T.silver,marginTop:2}}>{L.tapSeePlans.replace("{price}",PRICE_SOLO)}</div>
      </div>
      <div style={{fontSize:"0.7rem",color:urgent?T.red:T.gold,fontWeight:700,fontFamily:"'Josefin Sans',sans-serif",letterSpacing:"0.1em",flexShrink:0,marginLeft:10}}>{L.seeArrow}</div>
    </div>
  );
}

function SubscriptionScreen({barbers, subscription, onSubscribe, onBack, lang}){
  const L=LANGS[lang].t;
  const [plan,setPlan]=useState(subscription?.plan||"solo");
  const [collabs,setCollabs]=useState(Math.max(0,(barbers.filter(b=>b.active).length-1)));
  const soloPrice=PRICE_SOLO;
  const teamTotal=barbers.filter(b=>b.active).length * PRICE_TEAM;
  const isTeam=barbers.filter(b=>b.active).length>1;

  const totalPrice=plan==="solo"?soloPrice:teamTotal;

  return(
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",fontFamily:"'Cormorant Garamond',Georgia,serif",color:T.light}}>
      <style>{GS}</style>
      <header className="app-shell" style={{width:"100%",maxWidth:520,padding:"16px 20px 14px",borderBottom:`1px solid ${T.border}`,background:T.surface,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
        <div>
          <div style={{fontFamily:"'Josefin Sans',sans-serif",fontSize:"0.95rem",letterSpacing:"0.12em",fontWeight:700,color:T.white}}>LC<span style={{color:T.gold}}>_</span>84<span style={{color:T.gold,fontSize:"0.82rem"}}>barbervision</span></div>
          <div style={{fontSize:"0.55rem",letterSpacing:"0.25em",color:T.silver,textTransform:"uppercase",marginTop:2}}>{L.subscriptionLabel}</div>
        </div>
        <button onClick={onBack} style={{background:"none",border:`1px solid ${T.border}`,color:T.silver,padding:"5px 10px",borderRadius:4,cursor:"pointer",fontSize:"0.58rem",letterSpacing:"0.12em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif"}}>{L.back}</button>
      </header>

      <main className="app-shell" style={{width:"100%",maxWidth:520,padding:"24px 20px 60px"}}>

        {/* Hero */}
        <div style={{textAlign:"center",marginBottom:28}}>
          <div style={{fontSize:"2.2rem",marginBottom:8}}>💈</div>
          <div style={{fontSize:"1.4rem",color:T.white,fontWeight:600,marginBottom:6}}>{L.subscribeTitle}</div>
          <div style={{fontSize:"0.82rem",color:T.silver}}>{L.subscribeSubtitle}</div>
        </div>

        {/* Trial status */}
        <div style={{background:T.card,border:`1px solid ${T.border}`,borderRadius:8,padding:"14px",marginBottom:20,textAlign:"center"}}>
          <Lbl style={{marginBottom:6}}>{L.trialStatus}</Lbl>
          <div style={{fontSize:"1.5rem",color:daysLeft(TRIAL_START)>0?T.gold:T.red,fontWeight:700}}>
            {daysLeft(TRIAL_START)>0?`${daysLeft(TRIAL_START)} ${L.daysLeft}`:L.trialExpired}
          </div>
          <div style={{fontSize:"0.7rem",color:T.silver,marginTop:4}}>{L.freeTrialOfDays.replace("{days}",TRIAL_DAYS)}</div>
          {/* progress bar */}
          <div style={{height:4,background:T.muted,borderRadius:2,marginTop:10,overflow:"hidden"}}>
            <div style={{height:"100%",background:daysLeft(TRIAL_START)>3?T.gold:T.red,borderRadius:2,width:`${Math.min(100,((TRIAL_DAYS-daysLeft(TRIAL_START))/TRIAL_DAYS)*100)}%`,transition:"width .5s"}}/>
          </div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:"0.58rem",color:T.silver,marginTop:4,fontFamily:"'Josefin Sans',sans-serif"}}>
            <span>{L.dayWord} 1</span><span>{L.dayWord} {TRIAL_DAYS}</span>
          </div>
        </div>

        {/* Plans */}
        <Lbl style={{marginBottom:12}}>{L.availablePlans}</Lbl>

        {/* Solo */}
        <div onClick={()=>setPlan("solo")} style={{padding:"16px",marginBottom:10,background:plan==="solo"?T.goldLo:T.card,border:`2px solid ${plan==="solo"?T.gold:T.border}`,borderRadius:8,cursor:"pointer"}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
            <div>
              <div style={{fontSize:"1.1rem",color:T.white,fontWeight:600}}>✂ {L.solo}</div>
              <div style={{fontSize:"0.72rem",color:T.silver,marginTop:2}}>{L.soloDesc}</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:"1.5rem",color:T.gold,fontWeight:700,lineHeight:1}}>€{soloPrice}</div>
              <div style={{fontSize:"0.62rem",color:T.silver}}>{L.perMonth}</div>
            </div>
          </div>
          {L.soloFeatures.map(f=>(
            <div key={f} style={{fontSize:"0.76rem",color:T.mid,marginBottom:3}}>✓ {f}</div>
          ))}
        </div>

        {/* Team */}
        <div onClick={()=>setPlan("team")} style={{padding:"16px",marginBottom:20,background:plan==="team"?T.goldLo:T.card,border:`2px solid ${plan==="team"?T.gold:T.border}`,borderRadius:8,cursor:"pointer",position:"relative"}}>
          <div style={{position:"absolute",top:-10,right:14,background:T.gold,color:"#000",fontSize:"0.58rem",letterSpacing:"0.15em",textTransform:"uppercase",padding:"3px 10px",borderRadius:10,fontFamily:"'Josefin Sans',sans-serif",fontWeight:700}}>{L.popularBadge}</div>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:8}}>
            <div>
              <div style={{fontSize:"1.1rem",color:T.white,fontWeight:600}}>💈 {L.team}</div>
              <div style={{fontSize:"0.72rem",color:T.silver,marginTop:2}}>{L.teamDesc}</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:"1.5rem",color:T.gold,fontWeight:700,lineHeight:1}}>€{PRICE_TEAM}</div>
              <div style={{fontSize:"0.62rem",color:T.silver}}>{L.perBarberMonth}</div>
            </div>
          </div>
          {L.teamFeatures.map(f=>(
            <div key={f} style={{fontSize:"0.76rem",color:T.mid,marginBottom:3}}>✓ {f}</div>
          ))}
          {/* Team calculator */}
          <div style={{marginTop:12,padding:"12px",background:T.surface,borderRadius:6,border:`1px solid ${T.border}`}}>
            <Lbl style={{marginBottom:8}}>{L.teamCalcLabel}</Lbl>
            <div style={{display:"flex",alignItems:"center",justifyContent:"space-between"}}>
              <div style={{fontSize:"0.82rem",color:T.mid}}>{L.activeBarbersCount.replace("{n}",barbers.filter(b=>b.active).length)}</div>
              <div style={{fontSize:"1.1rem",color:T.gold,fontWeight:700}}>€{teamTotal.toFixed(2)}{L.perMonth}</div>
            </div>
            <div style={{fontSize:"0.66rem",color:T.silver,marginTop:4}}>
              {L.teamCalcFormula.replace("{n}",barbers.filter(b=>b.active).length).replace("{price}",PRICE_TEAM).replace("{total}",teamTotal.toFixed(2))}
              {barbers.filter(b=>b.active).length>1&&<span style={{color:T.green,marginLeft:6}}>{L.savingsVsSolo.replace("{amount}",((soloPrice*barbers.filter(b=>b.active).length)-teamTotal).toFixed(2))}</span>}
            </div>
          </div>
        </div>

        {/* Total */}
        <div style={{background:T.card,border:`1px solid ${T.gold}`,borderRadius:8,padding:"14px",marginBottom:20}}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
            <div>
              <div style={{fontSize:"0.9rem",color:T.white,fontWeight:500}}>{L.planWord} {plan==="solo"?L.solo:L.team}</div>
              <div style={{fontSize:"0.68rem",color:T.silver,marginTop:2}}>{L.monthlyRenewal}</div>
            </div>
            <div style={{textAlign:"right"}}>
              <div style={{fontSize:"1.6rem",color:T.gold,fontWeight:700,lineHeight:1}}>€{plan==="solo"?soloPrice.toFixed(2):teamTotal.toFixed(2)}</div>
              <div style={{fontSize:"0.6rem",color:T.silver}}>{L.perMonth}</div>
            </div>
          </div>
        </div>

        <Btn variant="gold" style={{width:"100%",padding:"15px",fontSize:"0.75rem"}} onClick={()=>onSubscribe(plan)}>
          {L.subscribeNow} — €{plan==="solo"?soloPrice.toFixed(2):teamTotal.toFixed(2)}{L.perMonth}
        </Btn>
        <div style={{textAlign:"center",marginTop:10,fontSize:"0.68rem",color:T.silver}}>
          {L.securePayment}<br/>
          <span style={{color:T.gold}}>{L.demoNote}</span>
        </div>

        {/* FAQ */}
        <div style={{marginTop:24}}>
          <Lbl style={{marginBottom:12}}>{L.faqTitle}</Lbl>
          {L.faqItems.map(([q,a])=>(
            <div key={q} style={{marginBottom:12,padding:"12px",background:T.card,border:`1px solid ${T.border}`,borderRadius:6}}>
              <div style={{fontSize:"0.85rem",color:T.white,fontWeight:500,marginBottom:4}}>{q}</div>
              <div style={{fontSize:"0.76rem",color:T.silver,lineHeight:1.5}}>{a}</div>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

function ExpiredScreen({onSubscribe, lang}){
  const L=LANGS[lang].t;
  return(
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,fontFamily:"'Cormorant Garamond',Georgia,serif",color:T.light}}>
      <style>{GS}</style>
      <div style={{textAlign:"center",maxWidth:300}}>
        <div style={{fontSize:"2.5rem",marginBottom:16}}>🔒</div>
        <div style={{fontSize:"1.4rem",color:T.white,fontWeight:600,marginBottom:8}}>{L.expiredTitle}</div>
        <div style={{fontSize:"0.84rem",color:T.silver,lineHeight:1.7,marginBottom:28,whiteSpace:"pre-line"}}>
          {L.expiredFull}
        </div>
        <Btn variant="gold" style={{width:"100%",padding:"15px",marginBottom:12}} onClick={onSubscribe}>
          {L.seePlans}
        </Btn>
        <div style={{fontSize:"0.68rem",color:T.silver}}>{L.noCommitmentFooter}</div>
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// OWNER PORTAL — login/registo de barbearias (multi-tenant)
// ══════════════════════════════════════════════════════════════════════════════
function OwnerPortal({lang,setLang}){
  const L=LANGS[lang].t;
  const [mode,setMode]     = useState("login"); // login | signup
  const [busy,setBusy]     = useState(false);
  const [err,setErr]       = useState("");

  // login fields
  const [email,setEmail]   = useState("");
  const [pass,setPass]     = useState("");

  // signup fields
  const [ownerName,setOwnerName] = useState("");
  const [salonName,setSalonName] = useState("");
  const [suEmail,setSuEmail]     = useState("");
  const [suPass,setSuPass]       = useState("");
  const [suPin,setSuPin]         = useState("");
  const [phone,setPhone]         = useState("");

  const goToShop=(slug)=>{
    const url=new URL(window.location.href);
    url.searchParams.set("loja",slug);
    window.location.href=url.toString();
  };

  const doLogin=async()=>{
    setErr("");
    if(!email||!pass){setErr(L.fillEmailPass);return;}
    setBusy(true);
    const{data,error}=await supabase.rpc("verify_owner_login",{p_email:email.trim(),p_password:pass});
    const row=Array.isArray(data)?data[0]:data;
    if(error||!row){setBusy(false);setErr(L.wrongCredentials);return;}
    // A password já prova quem é o proprietário: deixa a sessão dele
    // guardada neste aparelho para entrar direto na loja, sem PIN.
    const{data:sd}=await supabase.from("shops").select("data").eq("id",row.id).maybeSingle();
    const list=sd?.data?.barbers||[];
    const ownerB=list.find(b=>b.isOwner&&b.active!==false);
    if(ownerB)localStorage.setItem(`lc84_barber_session_${row.id}`,String(ownerB.id));
    setBusy(false);
    goToShop(row.slug);
  };

  const doSignup=async()=>{
    setErr("");
    if(!ownerName||!salonName||!suEmail||!suPass||!suPin){setErr(L.fillAllFields);return;}
    if(!/^\d{4,6}$/.test(suPin)){setErr(L.codeLength);return;}
    setBusy(true);
    const{data:existing}=await supabase.from("shops").select("id").eq("owner_email",suEmail.trim().toLowerCase()).maybeSingle();
    if(existing){setBusy(false);setErr(L.shopAlreadyExists);return;}
    const slug=await generateUniqueSlug(salonName);
    const ownerBarberId=mkId();
    const initData={
      shop:{name:salonName,address:"",phone:phone||"",bio:"",adminPin:""},
      barbers:[{id:ownerBarberId,name:ownerName,role:"Proprietário",pin:suPin,phone:phone||"",bio:"",avatar:ownerName.split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase(),color:"#b8955a",isOwner:true,schedule:{workDays:[1,2,3,4,5,6],startHour:"09:00",endHour:"19:00",breakStart:"",breakEnd:""},active:true}],
      services:INIT_SERVICES,
      bookings:[],
      notifications:[],
      clientNotes:{},
    };
    const{data:created,error}=await supabase.from("shops").insert({
      owner_email:suEmail.trim().toLowerCase(),
      owner_password:suPass,
      slug,
      data:initData,
    }).select("id").single();
    setBusy(false);
    if(error){setErr(L.createShopFailed);return;}
    if(created?.id)localStorage.setItem(`lc84_barber_session_${created.id}`,ownerBarberId);
    goToShop(slug);
  };

  return(
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,fontFamily:"'Josefin Sans',sans-serif",position:"relative"}}>
      <div style={{position:"absolute",top:16,right:16,display:"flex",gap:6}}>
        {Object.entries(LANGS).map(([code,l])=>(
          <button key={code} onClick={()=>setLang(code)} style={{padding:"4px 8px",borderRadius:4,cursor:"pointer",display:"flex",alignItems:"center",background:lang===code?T.goldLo:"transparent",border:`1px solid ${lang===code?T.gold:T.border}`}} title={l.name}>
            <img src={`https://flagcdn.com/w40/${FLAG_CC[code]}.png`} alt={l.name} style={{width:22,height:16,objectFit:"cover",borderRadius:2,display:"block"}}/>
          </button>
        ))}
      </div>
      <div style={{textAlign:"center",marginBottom:28}}>
        <img src={logoIcon} style={{width:130,marginBottom:10,display:"block",marginLeft:"auto",marginRight:"auto"}}/>
        <div style={{fontSize:"1.5rem",color:T.white,fontWeight:600,letterSpacing:"0.08em"}}>{L.portalTitle}</div>
        <div style={{fontSize:"0.75rem",color:T.silver,marginTop:4}}>{L.portalSubtitle}</div>
      </div>

      <div style={{display:"flex",gap:6,marginBottom:20,background:T.card,borderRadius:6,padding:4}}>
        <button onClick={()=>{setMode("login");setErr("");}} style={{padding:"8px 18px",borderRadius:4,border:"none",cursor:"pointer",background:mode==="login"?T.gold:"transparent",color:mode==="login"?"#0a0a0a":T.silver,fontWeight:600,fontSize:"0.8rem"}}>{L.haveAccountTab}</button>
        <button onClick={()=>{setMode("signup");setErr("");}} style={{padding:"8px 18px",borderRadius:4,border:"none",cursor:"pointer",background:mode==="signup"?T.gold:"transparent",color:mode==="signup"?"#0a0a0a":T.silver,fontWeight:600,fontSize:"0.8rem"}}>{L.createShopTab}</button>
      </div>

      <div style={{width:"100%",maxWidth:340,background:T.card,border:`1px solid ${T.border}`,borderRadius:8,padding:22}}>
        {mode==="login"?(
          <>
            <div style={{marginBottom:12}}>
              <Lbl style={{marginBottom:6}}>{L.emailLabel}</Lbl>
              <Inp value={email} onChange={e=>setEmail(e.target.value)} placeholder={L.placeholderEmail}/>
            </div>
            <div style={{marginBottom:16}}>
              <Lbl style={{marginBottom:6}}>{L.passwordLabel}</Lbl>
              <Inp type="password" value={pass} onChange={e=>setPass(e.target.value)} placeholder={L.placeholderPass}/>
            </div>
            {err&&<div style={{color:T.red,fontSize:"0.76rem",marginBottom:12,textAlign:"center"}}>{err}</div>}
            <Btn variant="gold" style={{width:"100%",padding:13}} onClick={doLogin} disabled={busy}>{busy?L.loggingIn:L.loginBtn}</Btn>
          </>
        ):(
          <>
            <div style={{marginBottom:12}}>
              <Lbl style={{marginBottom:6}}>{L.yourNameLabel}</Lbl>
              <Inp value={ownerName} onChange={e=>setOwnerName(e.target.value)} placeholder={L.placeholderFullName}/>
            </div>
            <div style={{marginBottom:12}}>
              <Lbl style={{marginBottom:6}}>{L.shopNameLabel}</Lbl>
              <Inp value={salonName} onChange={e=>setSalonName(e.target.value)} placeholder={L.placeholderShopName}/>
            </div>
            <div style={{marginBottom:12}}>
              <Lbl style={{marginBottom:6}}>{L.phoneOptionalLabel}</Lbl>
              <Inp value={phone} onChange={e=>setPhone(e.target.value)} placeholder={L.placeholderPhone}/>
            </div>
            <div style={{marginBottom:12}}>
              <Lbl style={{marginBottom:6}}>{L.emailLabel}</Lbl>
              <Inp value={suEmail} onChange={e=>setSuEmail(e.target.value)} placeholder={L.placeholderEmail}/>
            </div>
            <div style={{marginBottom:16}}>
              <Lbl style={{marginBottom:6}}>{L.passwordLabel}</Lbl>
              <Inp type="password" value={suPass} onChange={e=>setSuPass(e.target.value)} placeholder={L.placeholderCreatePass}/>
            </div>
            <div style={{marginBottom:16}}>
              <Lbl style={{marginBottom:6}}>{L.createAccessCode}</Lbl>
              <Inp value={suPin} onChange={e=>setSuPin(e.target.value.replace(/\D/g,"").slice(0,6))} placeholder="••••" style={{textAlign:"center",letterSpacing:"0.3em"}}/>
            </div>
            {err&&<div style={{color:T.red,fontSize:"0.76rem",marginBottom:12,textAlign:"center"}}>{err}</div>}
            <Btn variant="gold" style={{width:"100%",padding:13}} onClick={doSignup} disabled={busy}>{busy?L.creatingBtn:L.createShopBtn}</Btn>
          </>
        )}
      </div>
    </div>
  );
}

// ── Biometria (WebAuthn) ────────────────────────────────────────────────────
// Usa o que o telemóvel tiver (dedo, cara, etc.) para confirmar a sessão
// persistente do barbeiro em vez de pedir sempre o PIN. Guardado só neste
// aparelho (localStorage) — não depende de servidor, é só um "portão" local.
function b64uToBuf(b64u){
  const b64=b64u.replace(/-/g,"+").replace(/_/g,"/");
  const pad=b64.length%4===0?"":"=".repeat(4-(b64.length%4));
  const str=atob(b64+pad);
  const buf=new Uint8Array(str.length);
  for(let i=0;i<str.length;i++)buf[i]=str.charCodeAt(i);
  return buf;
}
function bufToB64u(buf){
  const bytes=new Uint8Array(buf);
  let str="";
  for(let i=0;i<bytes.length;i++)str+=String.fromCharCode(bytes[i]);
  return btoa(str).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
async function registerBiometric(shopId,barberId){
  if(!shopId||!window.PublicKeyCredential)return;
  const key=`lc84_biometric_${shopId}_${barberId}`;
  if(localStorage.getItem(key))return; // já registado neste aparelho
  try{
    const available=await PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable?.();
    if(!available)return; // este telemóvel não tem biometria
    const cred=await navigator.credentials.create({publicKey:{
      challenge:crypto.getRandomValues(new Uint8Array(32)),
      rp:{name:"LC.84 Barber Vision"},
      user:{id:new TextEncoder().encode(String(barberId)),name:`barbeiro-${barberId}`,displayName:`barbeiro-${barberId}`},
      pubKeyCredParams:[{type:"public-key",alg:-7},{type:"public-key",alg:-257}],
      authenticatorSelection:{authenticatorAttachment:"platform",userVerification:"required"},
      timeout:60000,
    }});
    if(cred)localStorage.setItem(key,bufToB64u(cred.rawId));
  }catch(e){console.log("Biometria: registo não disponível/cancelado",e);}
}
async function verifyBiometric(shopId,barberId){
  const key=`lc84_biometric_${shopId}_${barberId}`;
  const credId=localStorage.getItem(key);
  if(!credId)return false;
  try{
    const assertion=await navigator.credentials.get({publicKey:{
      challenge:crypto.getRandomValues(new Uint8Array(32)),
      allowCredentials:[{type:"public-key",id:b64uToBuf(credId)}],
      userVerification:"required",
      timeout:60000,
    }});
    return!!assertion;
  }catch(e){console.log("Biometria: verificação falhou/cancelada",e);return false;}
}

// ══════════════════════════════════════════════════════════════════════════════
// ROOT
// ══════════════════════════════════════════════════════════════════════════════
export default function App(){
  const [lang,setLang]                   = useState("pt");
  const [barbers,setBarbers]             = useState(INIT_BARBERS);
  const [services,setServices]           = useState(INIT_SERVICES);
  const [shop,setShop]                   = useState(INIT_SHOP);
  const [bookings,setBookings]           = useState([]);
const [notifications,setNotifications] = useState([]);
  const [clientNotes,setClientNotes]     = useState(INIT_CLIENT_NOTES);
  const [cutRecords,setCutRecords]       = useState({});
  const [purchaseHistory,setPurchaseHistory] = useState({});
  const [manualClients,setManualClients] = useState({});
  const [role,setRole]                   = useState("entry");
  const [activeBarber,setActiveBarber]   = useState(null);
  const [bScreen,setBScreen]             = useState("dashboard");
  const [dataLoaded,setDataLoaded]       = useState(false);
  const [shopId,setShopId]               = useState(null);
  const [mySlug,setMySlug] = useState("");
  const [ownerMode,setOwnerMode]         = useState(false);
  const [shopNotFound,setShopNotFound]   = useState(false);
  const [biometricPending,setBiometricPending] = useState(null); // barbeiro à espera de toque para pedir biometria
  const [pendingChat,setPendingChat]     = useState(()=>{
    const raw=new URLSearchParams(window.location.search).get("openChat");
    if(!raw)return null;
    const[barberId,clientKey]=raw.split("__");
    return barberId?{barberId,clientKey:clientKey||""}:null;
  });

  useEffect(()=>{
    (async()=>{
      const params=new URLSearchParams(window.location.search);
      let slug=params.get("loja");
      setMySlug(slug||"");
      // Atalho: ?dono=1 força sempre a Área do Dono (criar/entrar em loja),
      // ignorando "a última loja visitada" — útil para testar várias lojas
      // no mesmo telemóvel sem ter de limpar dados do site cada vez.
      if(!slug&&params.get("dono")==="1"){
        setOwnerMode(true);
        setDataLoaded(true);
        return;
      }
      if(!slug){
        const lastShop=localStorage.getItem("lc84_last_shop");
        if(lastShop){
          // Mantém quaisquer outros parâmetros já no link (ex: openChat=
          // vindo de uma notificação) e só acrescenta o loja= — antes isto
          // substituía o link inteiro e perdia o openChat.
          const newParams=new URLSearchParams(window.location.search);
          newParams.set("loja",lastShop);
          window.location.replace(`${window.location.pathname}?${newParams.toString()}`);
          return;
        }
        setOwnerMode(true);
        setDataLoaded(true);
        return;
      }
      localStorage.setItem("lc84_last_shop",slug);
      const{data,error}=await supabase.from("shops").select("id,data").eq("slug",slug).maybeSingle();
      if(error||!data){
        if(error)console.error("Erro a carregar:",error);
        setShopNotFound(true);
        setDataLoaded(true);
        return;
      }
      const d=data.data||{};
      setShopId(data.id);
      if(!d||Object.keys(d).length===0){
        setBarbers(ensureOwner(INIT_BARBERS));setServices(INIT_SERVICES);setShop(INIT_SHOP);
        setBookings(seedBookings(INIT_BARBERS));setNotifications(seedNotifications(INIT_BARBERS,lang));
        setClientNotes(INIT_CLIENT_NOTES);setCutRecords({});setPurchaseHistory({});
      } else {
        setBarbers(ensureOwner(d.barbers||INIT_BARBERS));
        setServices(d.services||INIT_SERVICES);
        setShop(d.shop||INIT_SHOP);
        setBookings(d.bookings||[]);
        setNotifications(d.notifications||[]);
        setClientNotes(d.clientNotes||{});
        setCutRecords(d.cutRecords||{});
        setPurchaseHistory(d.purchaseHistory||{});
        setManualClients(d.manualClients||{});
      }
      setDataLoaded(true);
    })();
  },[]);

  // Com a app aberta, o Firebase não mostra sozinho a notificação do sistema —
  // agarramos aqui e metemos no sino de notificações da app.
  useEffect(()=>{
    const unsub=listenForegroundPush((payload)=>{
      const data=payload?.data||{};
      if(data.type==="chat"&&data.barberId){
        setNotifications(p=>[{id:mkId(),barberId:data.barberId,type:"message",title:data.title||"Nova mensagem",body:data.body||"",ts:Date.now(),read:false,link:{type:"chat",key:data.clientKey||""}},...p]);
      }
    });
    return()=>unsub&&unsub();
  },[]);

  useEffect(()=>{
    if(!dataLoaded||!shopId)return;
    const t=setTimeout(()=>{
      supabase.from("shops").update({
        data:{barbers,services,shop,bookings,notifications,clientNotes,cutRecords,purchaseHistory,manualClients},
        updated_at:new Date().toISOString(),
      }).eq("id",shopId).then(({error})=>{if(error)console.error("Erro a guardar:",error);});
    },800);
    return()=>clearTimeout(t);
  },[barbers,services,shop,bookings,notifications,clientNotes,cutRecords,purchaseHistory,manualClients,dataLoaded,shopId]);

  const onBarberLogin=(b)=>{
    setActiveBarber(b);setRole("barber");
    if(shopId)localStorage.setItem(`lc84_barber_session_${shopId}`,b.id);
    registerBiometric(shopId,b.id);
    registerPushForBarber(shopId,b.id);
    if(pendingChat&&String(pendingChat.barberId)===String(b.id)){
      setBScreen("clients");
    }else{
      setBScreen("dashboard");
    }
    const todayCount=bookings.filter(bk=>bk.barberId===b.id&&bk.date===TODAY&&!bk.blocked).length;
    if(todayCount>0){
      const first=bookings.filter(bk=>bk.barberId===b.id&&bk.date===TODAY&&!bk.blocked).sort((a,bb)=>a.time.localeCompare(bb.time))[0];
      setNotifications(p=>[{id:mkId(),barberId:b.id,type:"reminder",title:LANGS[lang].t.notifGoodMorning.replace("{name}",b.name.split(" ")[0]),body:LANGS[lang].t.notifTodaySummary.replace("{n}",todayCount).replace("{time}",first?.time),ts:Date.now(),read:false},...p]);
    }
  };

  // Sessão persistente: se este aparelho já tinha um barbeiro autenticado
  // nesta loja, entra direto ao abrir a app, sem pedir o PIN outra vez.
  // (Tem de ficar aqui, antes de qualquer "return" condicional da função,
  // para não violar a ordem fixa dos hooks do React.)
  useEffect(()=>{
    if(!dataLoaded||!shopId||role!=="entry")return;
    const savedId=localStorage.getItem(`lc84_barber_session_${shopId}`);
    if(!savedId)return;
    const b=barbers.find(bb=>String(bb.id)===String(savedId)&&bb.active);
    if(!b)return;
    const hasBiometric=!!localStorage.getItem(`lc84_biometric_${shopId}_${b.id}`);
    if(hasBiometric){
      // O browser exige um toque real para poder pedir biometria — não dá
      // para chamar sozinho aqui. Mostra o ecrã de toque (ver biometricPending).
      setBiometricPending(b);
      return;
    }
    const t=setTimeout(()=>onBarberLogin(b),0);
    return()=>clearTimeout(t);
  },[dataLoaded,shopId,barbers,role]);

  // Chamado pelo toque no ecrã de biometria — este clique é que dá ao
  // browser a "autorização" para mostrar o popup nativo.
  const unlockWithBiometric=async()=>{
    const b=biometricPending;
    if(!b)return;
    const ok=await verifyBiometric(shopId,b.id);
    if(ok){
      setBiometricPending(null);
      onBarberLogin(b);
    }else{
      setBiometricPending(null);
      setRole("login"); // falhou/cancelou -> ecrã de PIN normal, como reserva
    }
  };
 

  // Subscription state
  const [subscription,setSubscription]   = useState(null); // null=trial, {plan,date}=active
  const [showSub,setShowSub]             = useState(false);
  const trialDays = daysLeft(TRIAL_START);
  const trialExpired = mySlug!=="lc84" && trialDays === 0 && !subscription;
  if(!dataLoaded){
    return(
      <div style={{minHeight:"100vh",background:T.bg,display:"flex",alignItems:"center",justifyContent:"center",color:T.gold,fontFamily:"'Josefin Sans',sans-serif",fontSize:"0.8rem",letterSpacing:"0.2em"}}>
        {LANGS[lang].t.loadingText}
      </div>
    );
  }

  if(ownerMode) return <OwnerPortal lang={lang} setLang={setLang}/>;

  if(shopNotFound){
    return(
      <div style={{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:24,textAlign:"center",fontFamily:"'Josefin Sans',sans-serif"}}>
        <div style={{fontSize:"2rem",marginBottom:16}}>🔍</div>
        <div style={{color:T.white,fontSize:"1.1rem",marginBottom:8}}>{LANGS[lang].t.shopNotFoundTitle}</div>
        <div style={{color:T.silver,fontSize:"0.8rem",marginBottom:20}}>{LANGS[lang].t.shopNotFoundBody}</div>
        <Btn variant="gold" onClick={()=>{window.location.href=window.location.origin+window.location.pathname;}}>{LANGS[lang].t.goToOwnerPortal}</Btn>
      </div>
    );
  }

  const addNotification=(barberId,type,title,body,link=null)=>{
    setNotifications(p=>[{id:mkId(),barberId,type,title,body,link,ts:Date.now(),read:false},...p]);
  };

  const handleSubscribe=(plan)=>{
    setSubscription({plan,date:TODAY,barbersCount:barbers.filter(b=>b.active).length});
    setShowSub(false);
    addNotification(activeBarber?.id||"b1","info",LANGS[lang].t.notifSubActivatedTitle,LANGS[lang].t.notifSubActivatedBody.replace("{plan}",plan==="solo"?LANGS[lang].t.solo:LANGS[lang].t.team).replace("{owner}","Luis"));
  };

  if(showSub) return <SubscriptionScreen barbers={barbers} subscription={subscription} onSubscribe={handleSubscribe} onBack={()=>setShowSub(false)} lang={lang}/>;

  if(biometricPending){
    return (
      <div onClick={unlockWithBiometric} style={{minHeight:"100vh",width:"100%",display:"flex",alignItems:"center",justifyContent:"center",background:T.bg,cursor:"pointer"}}>
        <style>{`
          @keyframes lc84BioPulse{
            0%{transform:scale(1);opacity:.5;}
            70%{transform:scale(1.6);opacity:0;}
            100%{transform:scale(1.6);opacity:0;}
          }
        `}</style>
        <div style={{position:"relative",width:96,height:96,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <div style={{position:"absolute",inset:0,borderRadius:"50%",border:`2px solid ${T.gold}`,animation:"lc84BioPulse 1.8s ease-out infinite"}}/>
          <div style={{position:"absolute",inset:0,borderRadius:"50%",border:`2px solid ${T.gold}`,animation:"lc84BioPulse 1.8s ease-out .9s infinite"}}/>
          <div style={{position:"relative",width:88,height:88,borderRadius:"50%",border:`2px solid ${T.gold}`,background:T.bg,display:"flex",alignItems:"center",justifyContent:"center"}}>
            <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke={T.gold} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"/>
              <path d="M14 13.12c0 2.38 0 6.38-1 8.88"/>
              <path d="M17.29 21.02c.12-.6.43-2.3.5-3.02"/>
              <path d="M2 12a10 10 0 0 1 18-6"/>
              <path d="M2 16h.01"/>
              <path d="M21.8 16c.2-2 .131-5.354 0-6"/>
              <path d="M5 19.5C5.5 18 6 15 6 12a6 6 0 0 1 .34-2"/>
              <path d="M8.65 22c.21-.66.45-1.32.57-2"/>
              <path d="M9 6.8a6 6 0 0 1 9 5.2v2"/>
            </svg>
          </div>
        </div>
      </div>
    );
  }

  if(role==="entry")  return <EntryScreen shop={shop} onClient={()=>setRole("client")} onBarber={()=>setRole("login")} lang={lang} setLang={setLang}/>;
  if(role==="login")  return <LoginScreen barbers={barbers} setBarbers={setBarbers} shop={shop} onBarberLogin={onBarberLogin} onAdminLogin={()=>setRole("admin")} onBack={()=>setRole("entry")} lang={lang}/>;
  if(role==="client") return <ClientArea bookings={bookings} setBookings={setBookings} services={services} barbers={barbers} shop={shop} shopId={shopId} addNotification={addNotification} onBack={()=>setRole("entry")} lang={lang}/>;
  if(role==="admin")  return <AdminPanel bookings={bookings} barbers={barbers} setBarbers={setBarbers} services={services} setServices={setServices} shop={shop} setShop={setShop} shopId={shopId} mySlug={mySlug} onLogout={()=>setRole("entry")} lang={lang}/>;

  // Trial expired — block barber access
  if(role==="barber" && trialExpired) return <ExpiredScreen onSubscribe={()=>setShowSub(true)} lang={lang}/>;

  // BARBER APP
  const barber=barbers.find(b=>b.id===activeBarber?.id)||activeBarber;
  const myUnread=notifications.filter(n=>n.barberId===barber.id&&!n.read).length;
  const NAV=[{id:"dashboard",l:LANGS[lang].t.navHome},{id:"agenda",l:LANGS[lang].t.navAgenda},{id:"notifs",l:LANGS[lang].t.navAlerts,badge:myUnread},{id:"clients",l:LANGS[lang].t.navClients},{id:"reports",l:LANGS[lang].t.navReports},{id:"schedule",l:LANGS[lang].t.navSchedule},{id:"profile",l:LANGS[lang].t.navProfile},...(barber.isOwner?[{id:"shop",l:LANGS[lang].t.navShop}]:[])];

  return(
    <div style={{minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",fontFamily:"'Cormorant Garamond',Georgia,serif",color:T.light}}>
      <style>{GS}</style>
      <header className="app-shell" style={{width:"100%",maxWidth:520,borderBottom:`1px solid ${T.border}`,background:T.surface,position:"sticky",top:0,zIndex:10}}>
        {/* MARCA — sempre visível */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"10px 20px",borderBottom:`1px solid ${T.border}`}}>
          <span style={{fontFamily:"'Josefin Sans',sans-serif",fontSize:"1.05rem",fontWeight:700,letterSpacing:"0.08em",color:T.white}}>
            LC<span style={{color:T.gold}}>_</span>84<span style={{color:T.gold}}>barbervision</span>
          </span>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            {mySlug!=="lc84" && (subscription
              ?<span style={{fontSize:"0.54rem",background:T.greenLo,color:T.green,border:`1px solid ${T.green}`,padding:"2px 8px",borderRadius:10,fontFamily:"'Josefin Sans',sans-serif"}}>✓ {LANGS[lang].t.activeSubBadge}</span>
              :<button onClick={()=>setShowSub(true)} style={{fontSize:"0.54rem",background:trialDays<=3?T.redLo:T.goldLo,color:trialDays<=3?T.red:T.gold,border:`1px solid ${trialDays<=3?T.red:T.gold}`,padding:"2px 8px",borderRadius:10,fontFamily:"'Josefin Sans',sans-serif",cursor:"pointer"}}>⏳ {trialDays}d</button>
            )}
            <button onClick={()=>{if(shopId)localStorage.removeItem(`lc84_barber_session_${shopId}`);setActiveBarber(null);setRole("entry");}} title={LANGS[lang].t.logout} style={{background:"none",border:`1px solid ${T.border}`,color:T.silver,width:24,height:24,borderRadius:4,cursor:"pointer",fontSize:"0.7rem",display:"flex",alignItems:"center",justifyContent:"center"}}>⏻</button>
          </div>
        </div>
        {/* Barbeiro + data */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 20px",borderBottom:`1px solid ${T.border}`}}>
          <div style={{display:"flex",alignItems:"center",gap:7}}>
            <Avatar barber={barber} size={22}/>
            <span style={{fontSize:"0.68rem",color:T.mid}}>{barber.name}</span>
          </div>
          <div style={{display:"flex",gap:10,alignItems:"center"}}>
            <span style={{fontSize:"0.6rem",color:T.gold,fontFamily:"'Josefin Sans',sans-serif"}}>{bookings.filter(b=>b.barberId===barber.id&&b.date===TODAY&&!b.blocked).length} {LANGS[lang].t.todaySuffix}</span>
            <span style={{fontSize:"0.6rem",color:T.silver,fontFamily:"'Josefin Sans',sans-serif"}}>{LANGS[lang].wdays[NOW.getDay()]} {NOW.getDate()} {LANGS[lang].months[NOW.getMonth()].slice(0,3)}</span>
          </div>
        </div>
        {/* Nav */}
        <div style={{display:"flex",overflowX:"auto",scrollbarWidth:"none"}}>
          {NAV.map(n=>(
            <button key={n.id} onClick={()=>setBScreen(n.id)} style={{padding:"8px 11px",background:"none",border:"none",borderBottom:`2px solid ${bScreen===n.id?barber.color:"transparent"}`,cursor:"pointer",color:bScreen===n.id?barber.color:T.silver,fontSize:"0.58rem",letterSpacing:"0.14em",textTransform:"uppercase",fontFamily:"'Josefin Sans',sans-serif",fontWeight:bScreen===n.id?700:400,whiteSpace:"nowrap",position:"relative"}}>
              {n.l}
              {n.badge>0&&<span style={{position:"absolute",top:4,right:2,background:T.red,color:"#fff",borderRadius:"50%",width:14,height:14,fontSize:"0.5rem",display:"flex",alignItems:"center",justifyContent:"center",fontFamily:"'Josefin Sans',sans-serif"}}>{n.badge>9?"9+":n.badge}</span>}
            </button>
          ))}
        </div>
      </header>

      {/* Trial banner inside app */}
      {mySlug!=="lc84"&&!subscription&&<div className="app-shell" style={{width:"100%",maxWidth:520,paddingTop:14}}><TrialBanner days={trialDays} onSubscribe={()=>setShowSub(true)} lang={lang}/></div>}

      <main className="app-shell" style={{width:"100%",maxWidth:520,flex:1,paddingTop:mySlug!=="lc84"&&!subscription&&trialDays<=5?0:18,paddingBottom:40}}>
        {bScreen==="dashboard"&&<BDashboard bookings={bookings} services={services} barber={barber} lang={lang}/>}
        {bScreen==="agenda"   &&<BAgenda    bookings={bookings} setBookings={setBookings} services={services} barbers={barbers} barber={barber} addNotification={addNotification} lang={lang}/>}
        {bScreen==="notifs"   &&<BNotifications notifications={notifications} setNotifications={setNotifications} barber={barber} lang={lang} onOpenLink={link=>{if(!link)return;setPendingChat({barberId:barber.id,clientKey:link.key,mode:link.type==="chat"?"chat":"profile"});setBScreen("clients");}}/>}
        {bScreen==="clients"  &&<BClients   bookings={bookings} setBookings={setBookings} services={services} barber={barber} clientNotes={clientNotes} setClientNotes={setClientNotes} cutRecords={cutRecords} setCutRecords={setCutRecords} purchaseHistory={purchaseHistory} setPurchaseHistory={setPurchaseHistory} manualClients={manualClients} setManualClients={setManualClients} shopId={shopId} lang={lang} autoOpenChatKey={pendingChat&&pendingChat.mode!=="profile"&&String(pendingChat.barberId)===String(barber.id)?pendingChat.clientKey:null} onAutoOpenChatDone={()=>setPendingChat(null)} autoOpenProfileKey={pendingChat&&pendingChat.mode==="profile"&&String(pendingChat.barberId)===String(barber.id)?pendingChat.clientKey:null} onAutoOpenProfileDone={()=>setPendingChat(null)}/>}
        {bScreen==="reports"  &&<BReports   bookings={bookings} setBookings={setBookings} services={services} barber={barber} lang={lang}/>}
        {bScreen==="schedule" &&<BSchedule  barber={barber} setBarbers={setBarbers} lang={lang}/>}
        {bScreen==="profile"  &&<BProfile   barber={barber} setBarbers={setBarbers} shopId={shopId} onLogout={()=>setRole("entry")} lang={lang}/>}
        {bScreen==="shop"&&barber.isOwner&&<AdminPanel bookings={bookings} barbers={barbers} setBarbers={setBarbers} services={services} setServices={setServices} shop={shop} setShop={setShop} shopId={shopId} mySlug={mySlug} onLogout={()=>setRole("entry")} lang={lang} embedded barber={barber}/>}
      </main>
    </div>
  );
}